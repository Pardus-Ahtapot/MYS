#!/bin/bash
#Suricata Signature Downloader
#Fatih USTA / fatihusta@labrisnetworks.com 


source /etc/suricata-sign-downloader.conf

hash_tmp=$(mktemp)

_wget=$(which wget)
_rm=/bin/rm
_cat=/bin/cat
_mkdir=/bin/mkdir
_logger=/usr/bin/logger


if ! [ -d $download_path ] ; then
    $_mkdir -p $download_path
fi

get_files () {
    $_wget $url/$hash_file -O $download_path/$hash_file
    $_wget $url/$file_name -O $download_path/$file_name
    if [ $? != 0 ]; then
        echo "$url/$file_name download failed!!!" | $_logger -t $(basename $0)
    fi
}

$_wget $url/$hash_file -O $hash_tmp

if [ $? != 0 ]; then
     $_rm -f $hash_tmp
     exit 1
fi

newhash=$($_cat $hash_tmp)
oldhash=$($_cat $download_path/$hash_file)

if [[ $newhash != $oldhash ]]; then
    get_files
fi

$_rm -f $hash_tmp
