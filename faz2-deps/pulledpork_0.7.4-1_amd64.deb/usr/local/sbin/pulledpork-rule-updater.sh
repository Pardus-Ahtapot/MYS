#!/bin/bash
#Pulledpork Rule Updater
#Fatih USTA / fatihusta@labrisnetworks.com

export LC_ALL=C

pulledpork=/usr/local/sbin/pulledpork.pl
ppconfig=/etc/pulledpork/pulledpork.conf
ids=suricata-3.2.1
logfile=/var/log/pulledpork/pulledpork.log
createsidmap=/usr/share/oinkmaster/create-sidmap.pl
sidmsg=/etc/suricata/rules/sid-msg.map
rules=/etc/suricata/rules/

_grep=/bin/grep
_awk=/usr/bin/awk
_cat=/bin/cat

if [[ $1 == "debug" ]]; then
    set -x
fi

#Run PulledPork
#Do Not Change Log ReDirection !!!
echo "Fetching Suricata rules" > $logfile
$pulledpork -c $ppconfig -k -S $ids -l  >> $logfile 


# If the rules have changed, restart Suricata and barnyard2
if ! ($_grep "No Rule Changes" $logfile &> /dev/null) ; then
        echo "The rules have changed, reloading" >> $logfile

        #ReGenerate sid-msg.map
        if [ -f $sidmsg ]; then
            $createsidmap $rules > $sidmsg
        fi

        if [ -f /usr/bin/barnyard2 ] ; then
            systemctl stop barnyard2
        fi

        /usr/bin/suricatasc reload-rules

        if [ -f /usr/bin/barnyard2 ] ; then
            systemctl start barnyard2
        fi
fi
