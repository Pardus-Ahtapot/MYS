#!/bin/bash
#Pulledpork Rule Updater
#Fatih USTA / fatihusta@labrisnetworks.com

if [[ $1 == "debug" ]]; then
    set -x
fi

export LC_ALL=C

pulledpork=/usr/local/sbin/pulledpork.pl
ppconfig=/etc/pulledpork/pulledpork.conf
ids=suricata-3.0
logfile=/var/log/pulledpork/pulledpork.log
createsidmap=/usr/share/oinkmaster/create-sidmap.pl
sidmsg=/etc/suricata/rules/sid-msg.map
suricataconfigdir=/etc/suricata
rules=$suricataconfigdir/rules/
signaturefile=emerging.rules.tar.gz

_grep=/bin/grep
_awk=/usr/bin/awk
_cat=/bin/cat
_tar=/bin/tar

#Run PulledPork
#Do Not Change Log ReDirection !!!
echo "Fetching Suricata rules" > $logfile
$pulledpork -c $ppconfig -k -S $ids -l  >> $logfile 

# If the rules have changed, restart Suricata and barnyard2
if ! ($_grep "No Rule Changes" $logfile &> /dev/null) ; then
        echo "The rules have changed, reloading" >> $logfile

        #ReGenerate sid-msg.map
        $createsidmap $rules > $sidmsg

        #Extracting New gen-msg.map
        eval $($_grep "^temp_path=" $ppconfig)
        if [ -f $temp_path/$signaturefile ];then
            $_tar -xf $temp_path/$signaturefile -C $suricataconfigdir "rules/gen-msg.map"
        fi

        if [ -f /usr/bin/barnyard2 ] ; then
            systemctl stop barnyard2
        fi

        echo "Rules are being reloaded in the background"
        /usr/bin/suricatasc -c reload-rules &

        if [ -f /usr/bin/barnyard2 ] ; then
            systemctl start barnyard2
        fi
fi
