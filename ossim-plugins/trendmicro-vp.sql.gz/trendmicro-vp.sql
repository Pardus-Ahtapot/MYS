-- Trendmicro-vp
-- plugin_id: 1910

DELETE FROM plugin WHERE id = 1910;
DELETE FROM plugin_sid where plugin_id = 1910;

INSERT IGNORE INTO plugin (id, type, name, description, vendor, product_type) VALUES (1910, 1, 'Trendmicro-vp', 'Trend Micro Vulnerability Protection', 'Trend Micro', 9 );

INSERT IGNORE INTO plugin_sid (plugin_id, sid, priority, reliability, category_id, subcategory_id, class_id, name) VALUES
(1910, 101, 2, 2, 7, 54, NULL, 'Trendmicro-vp: Invalid Flags'),
(1910, 107, 2, 2, 7, 54, NULL, 'Trendmicro-vp: Invalid IP Datagram Length'),
(1910, 115, 2, 2, 12, 101, NULL, 'Trendmicro-vp: Rule Update Downloaded'),
(1910, 123, 2, 2, 3, 76, NULL, 'Trendmicro-vp: Blocked by Firewall'),
(1910, 130, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Same Source and Destination IP'),
(1910, 138, 2, 2, 7, 55, NULL, 'Trendmicro-vp: Packet on Closed Connection'),
(1910, 151, 2, 2, 7, 55, NULL, 'Trendmicro-vp: Max TCP Connections'),
(1910, 152, 2, 2, 7, 55, NULL, 'Trendmicro-vp: Max UDP Connections'),
(1910, 153, 2, 2, 7, 54, NULL, 'Trendmicro-vp: Invalid Timestamp'),
(1910, 154, 2, 2, 11, 139, NULL, 'Trendmicro-vp: SYN with Data'),

(1910, 252, 2, 2, 11, 187, NULL, 'Trendmicro-vp: Computer Updated'),

(1910, 326, 2, 2, 11, 139, NULL, 'Trendmicro-vp: User Synchronization Finished'),

(1910, 564, 2, 2, 11, 147, NULL, 'Trendmicro-vp: Scheduled Task Started'),
(1910, 570, 2, 2, 23, 287, NULL, 'Trendmicro-vp: Sending Report'),

(1910, 600, 2, 2, 2, 24, NULL, 'Trendmicro-vp: User Signed In'),
(1910, 601, 2, 2, 2, 27, NULL, 'Trendmicro-vp: User Signed Out'),

(1910, 710, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Events Retrieved'),
(1910, 720, 2, 2, 21, 250, NULL, 'Trendmicro-vp: Policy Sent'),
(1910, 721, 2, 2, 21, 250, NULL, 'Trendmicro-vp: Send Policy Failed'),
(1910, 722, 2, 2, 11, 137, NULL, 'Trendmicro-vp: Get Interfaces Failed'),
(1910, 723, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Get Interfaces Failure Resolved'),
(1910, 728, 2, 2, 11, 137, NULL, 'Trendmicro-vp: Get Events Failed'),
(1910, 729, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Get Events Failure Resolved'),
(1910, 736, 2, 2, 5, 212, NULL, 'Trendmicro-vp: Check Status Failure Resolved'),
(1910, 737, 2, 2, 5, 211, NULL, 'Trendmicro-vp: Check Status Failed'),
(1910, 741, 2, 2, 11, 151, NULL, 'Trendmicro-vp: Abnormal Restart Detected'),
(1910, 771, 2, 2, 7, 122, NULL, 'Trendmicro-vp: Contact by Unrecognized Client'),
(1910, 780, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Recommendation Scan Failure Resolved'),
(1910, 781, 2, 2, 11, 137, NULL, 'Trendmicro-vp: Recommendation Scan Failure'),

(1910, 801, 2, 2, 11, 137, NULL, 'Trendmicro-vp: Error Dismissed'),
(1910, 803, 2, 2, 11, 137, NULL, 'Trendmicro-vp: Unknown Error'),
(1910, 850, 2, 2, 9, 70, NULL, 'Trendmicro-vp: Reconnaissance Detected: Computer OS Fingerprint Probe'),
(1910, 851, 2, 2, 9, 70, NULL, 'Trendmicro-vp: Reconnaissance Detected: Network or Port Scan'),
(1910, 852, 2, 2, 9, 70, NULL, 'Trendmicro-vp: Reconnaissance Detected: TCP Null Scan'),
(1910, 853, 2, 2, 9, 70, NULL, 'Trendmicro-vp: Reconnaissance Detected: TCP SYNFIN Scan'),
(1910, 854, 2, 2, 9, 70, NULL, 'Trendmicro-vp: Reconnaissance Detected: TCP XMAS Scan'),

(1910, 2908, 2, 2, 11, 145, NULL, 'Trendmicro-vp: Agent Self-Protection enabled'),

(1910, 1002103, 2, 2, 5, 44, NULL, 'Trendmicro-vp: AOL Instant Messenger'),
(1910, 1002475, 2, 2, 8, 68, NULL, 'Trendmicro-vp: Telnet Client'),
(1910, 1002487, 2, 2, 7, 58, NULL, 'Trendmicro-vp: SSH Client'),
(1910, 1002490, 2, 2, 3, 32, NULL, 'Trendmicro-vp: Radmin'),
(1910, 1002508, 2, 2, 3, 32, NULL, 'Trendmicro-vp: RDP'),
(1910, 1004707, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Dropbox'),
(1910, 1006296, 2, 2, 8, 163, NULL, 'Trendmicro-vp: Detected SSLv3 Response'),
(1910, 1006298, 2, 2, 8, 163, NULL, 'Trendmicro-vp: Identified CBC Based Cipher Suite In SSLv3 Request'),
(1910, 1006785, 2, 2, 2, 216, NULL, 'Trendmicro-vp: Identified LDAP BindRequest Using NTLM Authentication Mechanism'),
(1910, 1007695, 2, 2, 1, 3, NULL, 'Trendmicro-vp: Adobe Flash Player DLL Hijacking Vulnerability (CVE-2016-4140)'),
(1910, 1008227, 2, 2, 1, 20, NULL, 'Trendmicro-vp: Microsoft Windows SMB Information Disclosure Vulnerability (CVE-2017-0147)'),
(1910, 1008327, 2, 2, 1, 20, NULL, 'Trendmicro-vp: Identified Server Suspicious SMB Session'),

(1910, 200000000, 2, 2, 11, 139, NULL, 'Trendmicro-vp: Generic Event');
