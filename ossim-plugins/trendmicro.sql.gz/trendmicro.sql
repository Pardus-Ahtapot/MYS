-- trendmicro
-- plugin_id: 1574

DELETE FROM plugin WHERE id="1574";
DELETE FROM plugin_sid WHERE plugin_id="1574";

INSERT IGNORE INTO plugin (id, type, name, description, vendor, product_type) VALUES (1574, 1, 'trendmicro', 'Trend Micro Messaging Security', 'Trendmicro', 15);

INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES 
(1574, 1, 12, 97, NULL, 'Trend Micro: Virus found', 1, 3),
(1574, 2, 12, 104, NULL, 'Trend Micro: OpemDKIM filter started', 1, 3),
(1574, 3, 12, 108, NULL, 'Trend Micro: OpemDKIM filter terminating with error', 1, 3),
(1574, 4, 11, 146, NULL, 'Trend Micro: OpemDKIM filter stopped', 1, 3),
(1574, 5, 12, 103, NULL, 'Trend Micro: Client statistics', 1, 3),
(1574, 6, 11, 138, NULL, 'Trend Micro: Sender delivery notification', 1, 3),
(1574, 7, 11, 138, NULL, 'Trend Micro: Sender non-delivery notification', 1, 3),
(1574, 8, 11, 134, NULL, 'Trend Micro: Mail warning', 1, 3),
(1574, 9, 12, 103, NULL, 'Trend Micro: Mail message-id', 1, 3),
(1574, 10, 12, 103, NULL, 'Trend Micro: Mail filtered', 1, 3),
(1574, 11, 11, 137, NULL, 'Trend Micro: Connection refused', 1, 3),
(1574, 12, 12, 103, NULL, 'Trend Micro: Deferred Queue Event', 1, 3),
(1574, 13, 12, 103, NULL, 'Trend Micro: Reload Event', 1, 3),
(1574, 14, 11, 145, NULL, 'Trend Micro: Daemon started', 1, 3),
(1574, 15, 12, 103, NULL, 'Trend Micro: Refreshing the Postfix mail system', 1, 3),
(1574, 16, 11, 146, NULL, 'Trend Micro: Stopping the Postfix mail system', 1, 3),
(1574, 17, 12, 108, NULL, 'Trend Micro: The Postfix mail system is not running', 1, 3),
(1574, 18, 12, 103, NULL, 'Trend Micro: Checking if IMSS is running', 1, 3),
(1574, 19, 12, 103, NULL, 'Trend Micro: Starting to flush "new" queue objects', 1, 3),
(1574, 20, 12, 103, NULL, 'Trend Micro: Success flushing queue objects', 1, 3),
(1574, 21, 12, 103, NULL, 'Trend Micro: Message removed', 1, 3),
(1574, 22, 12, 103, NULL, 'Trend Micro: Queue message', 1, 3),
(1574, 23, 12, 103, NULL, 'Trend Micro: Postfix shared connection cache server statistics', 1, 3),
(1574, 24, 12, 103, NULL, 'Trend Micro: Postfix SMTP host replied', 1, 3),
(1574, 25, 3, 142, NULL, 'Trend Micro: Postfix SMTP connection accepted', 1, 3),
(1574, 26, 11, 134, NULL, 'Trend Micro: Postfix SMTP connection reset', 1, 3),
(1574, 27, 3, 143, NULL, 'Trend Micro: Postfix SMTP connection refused', 1, 3),
(1574, 28, 3, 144, NULL, 'Trend Micro: Postfix SMTP connection timed out', 1, 3),
(1574, 29, 11, 134, NULL, 'Trend Micro: Postfix SMTP no route found to host', 1, 3),
(1574, 30, 3, 142, NULL, 'Trend Micro: Postfix SMTP client connected', 1, 3),
(1574, 31, 3, 143, NULL, 'Trend Micro: Postfix SMTP client disconnected', 1, 3),
(1574, 32, 3, 143, NULL, 'Trend Micro: Postfix SMTP connection lost', 1, 3),
(1574, 33, 11, 134, NULL, 'Trend Micro: Postfix SMTP certificate verification failed', 1, 3),
(1574, 34, 11, 134, NULL, 'Trend Micro: Postfix SMTP SSL error event', 1, 3),
(1574, 35, 11, 134, NULL, 'Trend Micro: Postfix address rewriting and resolving daemon warning', 1, 3),
(1574, 36, 11, 134, NULL, 'Trend Micro: PID file missing ', 1, 3),
(1574, 37, 11, 134, NULL, 'Trend Micro: Shutting down SMTP Traffic Throttling agent', 1, 3),
(1574, 38, 11, 139, NULL, 'Trend Micro: Postfix SMTP rejected from remote host', 1, 3),
(1574, 39, 11, 145, NULL, 'Trend Micro: Starting the Postfix mail system', 1, 3),
(1574, 40, 11, 145, NULL, 'Trend Micro: IMSSDTASAgent generic event', 1, 3),
(1574, 41, 11, 145, NULL, 'Trend Micro: IMSSDTASAgent DDA is not enabled', 1, 3),
(1574, 42, 11, 145, NULL, 'Trend Micro: IMSSDTASAgent Error: No dda server', 1, 3),
(1574, 43, 11, 145, NULL, 'Trend Micro: IMSSDTASAgent Failed to load configuration', 1, 3),
(1574, 44, 11, 145, NULL, 'Trend Micro: IMSSDTASAgent current is in synchronization mode', 1, 3),
(1574, 45, 11, 139, NULL, 'Trend Micro: Callback NULL', 1, 3),
(1574, 46, 11, 139, NULL, 'Trend Micro: Cannot find a destination', 1, 3),
(1574, 47, 11, 146, NULL, 'Trend Micro: The delivery policy server finishes', 1, 3),
(1574, 48, 11, 145, NULL, 'Trend Micro: The delivery policy server starts', 1, 3),
(1574, 49, 12, 103, NULL, 'Trend Micro: IMSS Manager event', 1, 3),
(1574, 50, 12, 103, NULL, 'Trend Micro: IMSS Policy Service event', 1, 3),
(1574, 51, 12, 103, NULL, 'Trend Micro: IMSS Task Services event', 1, 3),
(1574, 52, 12, 103, NULL, 'Trend Micro: Administration Console event', 1, 3),
(1574, 53, 8, 67, NULL, 'Trend Micro: SMTP Traffic Throttling event', 1, 3),
(1574, 54, 12, 103, NULL, 'Trend Micro: IMSS Daemon Service event', 1, 3),
(1574, 55, 12, 103, NULL, 'Trend Micro: TLS Agent event', 1, 3),
(1574, 56, 12, 103, NULL, 'Trend Micro: Dynamic Threat Analysis System Agent event', 1, 3),
(1574, 57, 12, 103, NULL, 'Trend Micro: Web Reputation Service Agent event', 1, 3),
(1574, 58, 12, 103, NULL, 'Trend Micro: Email Reputation Service event', 1, 3),
(1574, 59, 12, 103, NULL, 'Trend Micro: End User Quarantine event', 1, 3),
(1574, 60, 12, 103, NULL, 'Trend Micro: Fox Proxy parser event', 1, 3),
(1574, 61, 12, 103, NULL, 'Trend Micro: Scanning Daemon Service event', 1, 3),
(1574, 62, 12, 103, NULL, 'Trend Micro: Spam mail released event', 1, 3),
(1574, 63, 12, 103, NULL, 'Trend Micro: IMSS Transaction event', 1, 3),
(1574, 64, 12, 103, NULL, 'Trend Micro: Scanning Activity Daemon history event', 1, 3),
(1574, 65, 12, 103, NULL, 'Trend Micro: SMTP event', 1, 3),
(1574, 66, 13, 174, NULL, 'Trend Micro: Email sent', 1, 3),
(1574, 67, 11, 147, NULL, 'Trend Micro: Policy/rule cache scheduled update started', 1, 3),
(1574, 68, 11, 139, NULL, 'Trend Micro: Version number unchanged, nothing to update', 1, 3),
(1574, 69, 11, 139, NULL, 'Trend Micro: PRStatusMonitor: Updating the product license status', 1, 3),
(1574, 70, 11, 147, NULL, 'Trend Micro: Find increased version number, start update the policy setting', 1, 3),
(1574, 71, 11, 137, NULL, 'Trend Micro: Could not determine product registration status for Compliance filter', 1, 3),
(1574, 72, 11, 139, NULL, 'Trend Micro: Product is currently licensed', 1, 3),
(1574, 73, 11, 139, NULL, 'Trend Micro: Policy version changed, update policy/rule succeed', 1, 3),
(1574, 74, 3, 142, NULL, 'Trend Micro: Connection Opened', 1, 3),
(1574, 75, 3, 142, NULL, 'Trend Micro: Rate result event', 1, 3),
(1574, 76, 11, 148, NULL, 'Trend Micro: Policy setting update finished', 1, 3),
(1574, 77, 3, 142, NULL, 'Trend Micro: Accept connection from client', 1, 3),
(1574, 78, 11, 139, NULL, 'Trend Micro: Send original email', 1, 3),
(1574, 79, 12, 107, NULL, 'Trend Micro: Scan finished', 1, 3),
(1574, 80, 3, 143, NULL, 'Trend Micro: SMTP client connection closed', 1, 3),
(1574, 81, 11, 148, NULL, 'Trend Micro: The application wrsagent finished successfully', 1, 3),
(1574, 82, 11, 147, NULL, 'Trend Micro: The application wrsagent started successfully', 1, 3),
(1574, 83, 11, 139, NULL, 'Trend Micro: Pump Events', 1, 3),
(1574, 84, 11, 139, NULL, 'Trend Micro: Write Log', 1, 3),
(1574, 85, 11, 139, NULL, 'Trend Micro: Event is Triggered', 1, 3),
(1574, 86, 11, 139, NULL, 'Trend Micro: Get entity filename', 1, 3),
(1574, 87, 11, 139, NULL, 'Trend Micro: Get Raw Address', 1, 3),
(1574, 88, 11, 139, NULL, 'Trend Micro: New file name', 1, 3),
(1574, 89, 11, 139, NULL, 'Trend Micro: Quarantine to message to folder', 1, 3),
(1574, 90, 11, 147, NULL, 'Trend Micro: Scheduled Update started', 1, 3),
(1574, 91, 11, 147, NULL, 'Trend Micro: Application or process started successfully', 1, 3),
(1574, 92, 11, 148, NULL, 'Trend Micro: Application or process finished successfully', 1, 3),
(1574, 93, 11, 148, NULL, 'Trend Micro: Scheduled Update finished finally', 1, 3),

(1574, 20000000, 11, 139, NULL, 'Trend Micro: generic event', 1, 3);














