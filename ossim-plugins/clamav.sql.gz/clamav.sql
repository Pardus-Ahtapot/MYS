-- clamav - Clam antivirus
-- plugin_id: 1555

DELETE FROM plugin WHERE id = 1555;
DELETE FROM plugin_sid WHERE plugin_id=1555;

INSERT IGNORE INTO plugin (id, type, name, description, vendor, product_type) VALUES (1555, 1, 'ClamAV', 'Clam AntiVirus', 'ClamAV', 3);

INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 1, 12, 97, NULL, 'ClamAV: Virus Found', 3, 5);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 2, 21, 252, NULL, 'ClamAV: CLAM_OPTION_SCAN_MAIL message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 3, 21, 252, NULL, 'ClamAV: CLAM_OPTION_SCAN_ARCHIVE message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 4, 21, 252, NULL, 'ClamAV: New instance created', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 5, 21, 252, NULL, 'ClamAV: Instance has been destroyed', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 6, 21, 252, NULL, 'ClamAV: Scan_GetFileType message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 7, 12, 108, NULL, 'ClamAV: An error has ocurred', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 8, 21, 252, NULL, 'ClamAV: Limited size', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 9, 21, 252, NULL, 'ClamAV: Load_db message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 10, 21, 252, NULL, 'ClamAV: Scan_ReloadDatabase message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 11, 21, 252, NULL, 'ClamAV: Monitor thread message', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 12, 21, 252, NULL, 'ClamAV: Scan_ScanObjectByHandle event', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 13, 21, 252, NULL, 'ClamAV: Core initialized', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 14, 21, 252, NULL, 'ClamAV: Module initialization succeded', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 15, 21, 252, NULL, 'ClamAV: A warning has ocurred', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 16, 12, 107, NULL, 'ClamAV: Scan Summary', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 17, 21, 252, NULL, 'ClamAV: Can not download', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 18, 21, 252, NULL, 'ClamAV: ClamAV update process started', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 19, 21, 252, NULL, 'ClamAV: Clamd successfully notified about the update', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 20, 21, 252, NULL, 'ClamAV: Connecting via IP', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 21, 21, 252, NULL, 'ClamAV: Database correctly reloaded', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 22, 21, 252, NULL, 'ClamAV: Database updated', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 23, 21, 252, NULL, 'ClamAV: Downloading file', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 24, 21, 252, NULL, 'ClamAV: Giving up on', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 25, 21, 252, NULL, 'ClamAV: Reading databases from', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 26, 21, 252, NULL, 'ClamAV: Self check', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 27, 21, 252, NULL, 'ClamAV: Trying again in', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 28, 21, 252, NULL, 'ClamAV: Unknown response', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 29, 21, 252, NULL, 'ClamAV: File updated', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1555, 20000000, 12, 103, NULL, 'ClamAV: Generic', 2, 2);