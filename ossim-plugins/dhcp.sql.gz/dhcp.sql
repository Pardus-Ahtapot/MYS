-- MS DHCP
-- plugin_id: 1584
--

DELETE FROM plugin WHERE id = 1584;
DELETE FROM plugin_sid WHERE plugin_id=1584;

INSERT IGNORE INTO plugin (id, type, name, description, vendor, product_type ) VALUES ( 1584, 1, 'dhcp', 'Microsoft DHCP Service Activity', 'Microsoft', 25 );

INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 33, 8, 74, NULL, 1, 1, 'DHCP: The log was started.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 1000, 8, 74, NULL, 1, 1, 'DHCP: The log was started.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 1, 8, 74, NULL, 1, 1, 'DHCP: The log was stopped.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 2, 8, 74, NULL, 1, 1, 'DHCP: The log was temporarily paused due to low disk space.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 10, 8, 74, NULL, 1, 1, 'DHCP: A new IP address was leased to a client.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 11, 8, 74, NULL, 1, 1, 'DHCP: A lease was renewed by a client.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 12, 8, 74, NULL, 1, 1, 'DHCP: A lease was released by a client.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 13, 8, 74, NULL, 1, 1, 'DHCP: An IP address was found to be in use on the network.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 14, 8, 74, NULL, 1, 1, 'DHCP: A lease request could not be satisfied because the scope s address pool was exhausted.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 15, 8, 74, NULL, 1, 1, 'DHCP: A lease was denied.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 16, 8, 74, NULL, 1, 1, 'DHCP: A lease was deleted.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 17, 8, 74, NULL, 1, 1, 'DHCP: A lease was expired.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 20, 8, 74, NULL, 1, 1, 'DHCP: A BOOTP address was leased to a client.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 21, 8, 74, NULL, 1, 1, 'DHCP: A dynamic BOOTP address was leased to a client.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 22, 8, 74, NULL, 1, 1, 'DHCP: A BOOTP request could not be satisfied because the scopes address pool for BOOTP was exhausted.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 23, 8, 74, NULL, 1, 1, 'DHCP: A BOOTP IP address was deleted after checking to see it was not in use.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 24, 8, 74, NULL, 1, 1, 'DHCP: IP address cleanup operation has began.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 25, 8, 74, NULL, 1, 1, 'DHCP: IP address cleanup statistics.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 30, 8, 74, NULL, 1, 1, 'DHCP: DNS update request to the named DNS server.');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 31, 8, 74, NULL, 1, 1, 'DHCP: DNS update failed');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, reliability, priority, name) VALUES (1584, 32, 8, 74, NULL, 1, 1, 'DHCP: DNS update successful');
