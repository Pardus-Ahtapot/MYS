-- VMware ESXi 
-- plugin_id=1686
--
-- $Id: esxi.sql,v 1.0 17/05/2012

DELETE FROM plugin WHERE id = "1686";
DELETE FROM plugin_sid where plugin_id = "1686";
INSERT INTO plugin(id, type, name, description, vendor, product_type ) VALUES (1686, 1, 'vmware-esxi', 'VMware ESXi server' , 'VMware', 21 );

INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 1, 11, 134, 2, 2, NULL, 'VMware-ESXI: Warning');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 2, 11, 137, 2, 2, NULL, 'VMware-ESXI: Error');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 3, 11, 139, 2, 2, NULL, 'VMware-ESXI: Info');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 4, 11, 140, 2, 2, NULL, 'VMware-ESXI: Verbose');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 5, 2, 216, 2, 2, NULL, 'VMware-ESXI: Authentication event: New connection');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 6, 2, 216, 2, 2, NULL, 'VMware-ESXI: Authentication event');

-- #7989
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 7, 11, 137, 2, 2, NULL, 'VMware-ESXI: Accepted password');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 8, 11, 137, 2, 2, NULL, 'VMware-ESXI: Claiming');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 9, 11, 137, 2, 2, NULL, 'VMware-ESXI: IpmiIfcSelGetAll');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 10, 11, 137, 2, 2, NULL, 'VMware-ESXI: HostCtl Exception');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 11, 11, 139, 2, 2, NULL, 'VMware-ESXI: Version Info');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 12, 11, 137, 2, 2, NULL, 'VMware-ESXI: No match, sensor_health file missing');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 13, 11, 137, 2, 2, NULL, 'VMware-ESXI: Query Information');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 14, 11, 137, 2, 2, NULL, 'VMware-ESXI: Section for VMware ESX');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 15, 11, 137, 2, 2, NULL, 'VMware-ESXI: Plugin is already loaded');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 16, 11, 137, 2, 2, NULL, 'VMware-ESXI: Early init logs');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 17, 11, 139, 2, 2, NULL, 'VMware-ESXI: Successfully acquired hardware');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 18, 11, 139, 2, 2, NULL, 'VMware-ESXI: DictionaryLoad: Cannot open file');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 19, 11, 139, 2, 2, NULL, 'VMware-ESXI: Host event');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 20, 11, 139, 2, 2, NULL, 'VMware-ESXI: Vpx');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 21, 11, 139, 2, 2, NULL, 'VMware-ESXI: hostd-probe event');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 22, 11, 139, 2, 2, NULL, 'VMware-ESXI: Starting hostd probing');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 23, 11, 139, 2, 2, NULL, 'VMware-ESXI: Unlocking esx.conf');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 24, 11, 139, 2, 2, NULL, 'VMware-ESXI: Locking esx.conf');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 25, 11, 139, 2, 2, NULL, 'VMware-ESXI: Creating archive');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 26, 11, 139, 2, 2, NULL, 'VMware-ESXI: Released lock');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 27, 11, 139, 2, 2, NULL, 'VMware-ESXI: Received CONNECT command');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 28, 11, 139, 2, 2, NULL, 'VMware-ESXI: Heartbeat: up');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 29, 2, 24, 2, 2, NULL, 'VMware-ESXI: Login');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 30, 11, 139, 2, 2, NULL, 'VMware-ESXI: Local verification');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 31, 11, 139, 2, 2, NULL, 'VMware-ESXI: Info fdm');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 32, 11, 139, 2, 2, NULL, 'VMware-ESXI: hostdCgiServe');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 33, 11, 139, 2, 2, NULL, 'VMware-ESXI: Scanning');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 34, 13, 118, 2, 2, NULL, 'VMware-ESXI: HTTP Not Found. Error (404)');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 35, 11, 139, 2, 2, NULL, 'VMware-ESXI: Rejected password');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 36, 11, 139, 2, 2, NULL, 'VMware-ESXI: QueryInformation');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 37, 11, 139, 2, 2, NULL, 'VMware-ESXI: rhttpprox');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 39, 11, 139, 2, 2, NULL, 'VMware-ESXI: HTTP ok (200)');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 40, 13, 116, 2, 2, NULL, 'VMware-ESXI: Bad HTTP Request. Error (400)');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 41, 13, 116, 2, 2, NULL, 'VMware-ESXI: HTTP Forbidden Error (403)');

INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 9995, 11, 139, 2, 2, NULL, 'VMware-ESXI: vthread message');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 9996, 11, 134, 2, 2, NULL, 'VMware-ESXI: vmkwarning message');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 9997, 11, 139, 2, 2, NULL, 'VMware-ESXI: vmkernel message');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 9998, 11, 140, 2, 2, NULL, 'VMware-ESXI: Debug Traceback');
INSERT INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, priority, reliability, class_id, name) VALUES (1686, 20000000, 11, 139, 2, 2, NULL, 'VMware-ESXI: General');
