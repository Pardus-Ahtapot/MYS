-- mcafee-db
-- plugin_id: 1751

DELETE FROM plugin WHERE id = "1751";
DELETE FROM plugin_sid where plugin_id = "1751";

INSERT IGNORE INTO plugin (id, type, name, description, vendor, product_type) VALUES (1751, 1, 'mcafee-db', 'McAfee Database Security', 'McAfee', 8);

INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (1751, 1, 20, 238, NULL, 'McAfee Database Security: Query: Drop device', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 2, 20, 236, NULL, 'McAfee Database Security: Add login', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 3, 20, 243, NULL, 'McAfee Database Security: Add user', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 4, 20, 243, NULL, 'McAfee Database Security: Configuration event', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 5, 20, 243, NULL, 'McAfee Database Security: Delete permissions', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 6, 20, 238, NULL, 'McAfee Database Security: Query: Drop table', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 7, 20, 238, NULL, 'McAfee Database Security: Query: Drop database', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 8, 20, 243, NULL, 'McAfee Database Security: Execute proced', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 9, 20, 238, NULL, 'McAfee Database Security: Query: Grant/Priviledge modification', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 10, 20, 238, NULL, 'McAfee Database Security: Query: Update', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 11, 20, 238, NULL, 'McAfee Database Security: Query: Delete', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 12, 20, 238, NULL, 'McAfee Database Security: Query: Insert', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 13, 20, 243, NULL, 'McAfee Database Security: Query: Use database', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 14, 20, 238, NULL, 'McAfee Database Security: Query: Dump database', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 15, 20, 243, NULL, 'McAfee Database Security: Execute', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 16, 20, 238, NULL, 'McAfee Database Security: Query: Truncate table', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 17, 20, 238, NULL, 'McAfee Database Security: Condition', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 18, 20, 238, NULL, 'McAfee Database Security: Bulk insert', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 19, 20, 243, NULL, 'McAfee Database Security: Set textsize', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 20, 20, 238, NULL, 'McAfee Database Security: Declare', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 21, 20, 238, NULL, 'McAfee Database Security: Query: Select', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 22, 20, 238, NULL, 'McAfee Database Security: Query: Declare cursor', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 23, 20, 238, NULL, 'McAfee Database Security: Check Database', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 24, 20, 238, NULL, 'McAfee Database Security: Query: Alter table', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 25, 20, 238, NULL, 'McAfee Database Security: Query: Update statics', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 26, 20, 243, NULL, 'McAfee Database Security: Shutdown with nowait', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 27, 20, 243, NULL, 'McAfee Database Security: Print', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 28, 20, 243, NULL, 'McAfee Database Security: Drop user', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 29, 20, 242, NULL, 'McAfee Database Security: Error', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 30, 20, 243, NULL, 'McAfee Database Security: Failed Login', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 31, 20, 242, NULL, 'McAfee Database Security: Create Database', 2, 2);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability)  VALUES (1751, 20000000, 20, 243, NULL, 'McAfee Database Security: GENERAL', 2, 2);

