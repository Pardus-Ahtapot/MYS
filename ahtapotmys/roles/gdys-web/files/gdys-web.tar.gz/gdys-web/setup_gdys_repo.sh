#!/bin/bash
COLOR_GREEN="\033[92m"
COLOR_RED="\033[31m"
COLOR_YELLOW="\033[93m"
COLOR_DEFAULT="\033[39m"

echo -ne "$COLOR_DEFAULT"

function print_warn()
{
    echo -ne "$COLOR_YELLOW##### $1 #####$COLOR_DEFAULT\n"
}

function print_err()
{
    echo -ne "$COLOR_RED$1$COLOR_DEFAULT\n"
}

function print_success()
{
    echo -ne "$COLOR_GREEN$1$COLOR_DEFAULT\n"
}

if [ "$EUID" -ne 0 ]; then
  print_err "Lutfen bu script'i root kullanicisi olarak calistirin! Cikiliyor..."
  exit 1
fi

workdir_path="/etc/fw/gdys"
git_host=""
git_port=""
git_user=""
gdys_repo_name=""
gdys_user=""
gdys_group=""

echo -ne '
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#
# '$COLOR_YELLOW'UYARI!'$COLOR_DEFAULT'
# Bu islemi gerceklestirmeden once lutfen bu sunucunun ssh public keyinin git sunucusuna eklendiginden
# ve ssh uzerinden sifresiz sekilde repolara erisilebildiginden emin olun!
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
'
read -p "Gdys2 sahipligi icin ayarlanan kullanici adi  (varsayilan: ahtapotops): " gdys_user
if [ -z "$gdys_user" ]; then
gdys_user="ahtapotops"
fi

read -p "Gdys2 sahipligi icin ayarlanan kullanici grubu  (varsayilan: ahtapotops): " gdys_group
if [ -z "$gdys_group" ]; then
gdys_group="ahtapotops"
fi

while [ -z "$git_host" ]; do
  read -p "Gdys reposunun bulundugu git sunucusunun adresini giriniz (orn: git.gdys.test veya 192.168.1.1): " git_host
done

read -p "Gdys reposunun bulundugu git sunucusunun port numarasini giriniz (varsayilan: 22): " git_port
if [ -z "$git_port" ]; then
git_port="22"
fi

read -p "Gdys reposunun bulundugu git kullanicisinin adini giriniz (varsayilan: ahtapotops): " git_user
if [ -z "$git_user" ]; then
git_user="ahtapotops"
fi

read -p "Git sunucusu uzerinde gdys icin olusturulan reponun adini giriniz (varsayilan: gdys): " gdys_repo_name
if [ -z "$gdys_repo_name" ]; then
gdys_repo_name="gdys"
fi

gdys_repo_url="ssh://git@${git_host}:${git_port}/${git_user}/${gdys_repo_name}.git"

# Get the git server ssh key
git_ssh_key=`ssh-keyscan -p $git_port $git_host | grep rsa`
check_key_exist=$(cat /home/$gdys_user/.ssh/known_hosts | grep "$git_ssh_key")
if [ -z "$check_key_exist" ]; then
    print_warn "#### Git sunucusunun ssh key'i aliniyor..."
    echo $git_ssh_key >> /home/$git_user/.ssh/known_hosts
fi

cd /tmp
# Clear old files if exist
rm -rf "$gdys_repo_name"
# Clone the gdys repo to the tmp folder
su - $gdys_user -c "git clone $gdys_repo_url /tmp/$gdys_repo_name"

if [ $? -ne 0 ]; then
    print_err "Gdys reposunu clone etme islemi sirasinda hata gerceklesti. Lutfen ssh uzerinden sifresiz olarak iletisim saglanabildiginden emin olun!"
    exit 1
fi

# Clear old .git folder
rm -rf "$workdir_path/.git"
# Copy git files to the workdir
cp -a "/tmp/$gdys_repo_name/." "$workdir_path/"

# Enter the workdir path
cd $workdir_path
sudo chown -R $gdys_user:$gdys_group $workdir_path

# Make inital git stuff
su - $gdys_user -c "cd $workdir_path && git config user.email \"ahtapot@pardus.org.tr\"" && \
su - $gdys_user -c "cd $workdir_path && git config user.name \"Ahtapot system\"" && \
su - $gdys_user -c "cd $workdir_path && git add --all" && \
su - $gdys_user -c "cd $workdir_path && git commit -m \"Initial commit\"" && \
su - $gdys_user -c "cd $workdir_path && git push origin master" && \

print_success "Kurulum tamamlandi!"
