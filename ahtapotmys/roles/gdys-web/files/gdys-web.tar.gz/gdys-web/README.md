# gdys-web

Ahtapot GDYS Web application.

### Installation
For interactive installation just run the installation script

```
sudo ./install.sh
```

For non-interactive installation 
```
sudo ./install.sh -ni [options]

options:
-h,   --help               yardimi goster
-ni,  --non-interactive    degerleri parametreler araciligi ile al
-gu,  --gdys-user=NAME     Gdys uygulamasinin ait olacagi kullanici (varsayilan: ahtapotops)
-gg,  --gdys-group=NAME    Gdys uygulamasinin ait olacagi kullanici grubu (varsayilan: ahtapotops)
-f,   --fqdn=FQDN          Uygulamanin yayinlanacagi FQDN
-p,   --port=PORT          Uygulamanin yayinlanacagi port bilgisi (varsayilan: 80)
-mi,  --mys-ip=IP          MYS sunucusuna ait ip bilgisi
-aip, --access-via-ip      GDYS uygulamasini tarayici uzerinden IP ile ulasilabilir yap

```

If you install Gdys2 without playbook you need to setup local git repo(*/etc/fw/gdys*) manually:
```
sudo ./setup_gdys_repo.sh
```

Go to browser and open the url http://HOST:PORT/

### Configuring for your setings

Open .env file with your favorite text editor and edit settings for your setup.
Than just run
```
sudo systemctl restart gdysweb
```

### Running the development environment
```
# Create virtualenvironment and source it
virtualenv -p python3.5 venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy env file and edit
cp .env.sample .env
vim .env

# Init the db
flask db init

# Create migration for models
flask db migrate -m "Initial migration."

# Create the tables
flask db upgrade

python run.py
```

Go to browser and open the url http://HOST:PORT/