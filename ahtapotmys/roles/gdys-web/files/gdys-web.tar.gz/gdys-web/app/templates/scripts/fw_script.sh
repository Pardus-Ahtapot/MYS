#!/bin/sh 
#
#  This is automatically generated file. DO NOT MODIFY !
#
#  Ahtapot GDYS Web App v1.0.0
#
#  Generated in {{ vars.current_time }} by {{ vars.current_user }}
#
#
# Compiled for Ahtapot FW
#

PATH="/sbin:/usr/sbin:/bin:/usr/bin:${PATH}"
export PATH

IP="/sbin/ip"
MODPROBE="/sbin/modprobe"
IPTABLES="/sbin/iptables"
IP6TABLES="/sbin/ip6tables"

find_program() {
  PGM=$1
  which $PGM >/dev/null 2>&1 || {
    echo "\"$PGM\" not found"
    exit 1
  }
}
check_tools() {
  find_program which
  find_program $IPTABLES
  find_program $MODPROBE
  find_program $IP 
}

reset_iptables_v4() {
local list

$IPTABLES  -P OUTPUT  DROP
$IPTABLES  -P INPUT   DROP
$IPTABLES  -P FORWARD DROP

while read table; do
      list=$($IPTABLES  -t $table -L -n)
printf "%s" "$list" | while read c chain rest; do
if test "X$c" = "XChain" ; then
$IPTABLES  -t $table -F $chain
fi
done
$IPTABLES  -t $table -X
done < /proc/net/ip_tables_names
}

reset_iptables_v6() {
local list

$IP6TABLES  -P OUTPUT  DROP
$IP6TABLES  -P INPUT   DROP
$IP6TABLES  -P FORWARD DROP

while read table; do
      list=$($IP6TABLES -t $table -L -n)
printf "%s" "$list" | while read c chain rest; do
if test "X$c" = "XChain" ; then
$IP6TABLES  -t $table -F $chain
fi
done
$IP6TABLES  -t $table -X
done < /proc/net/ip6_tables_names
}


script_body() {
    # ================ IPv4


    # ================ Table 'filter', automatic rules
    # accept established sessions
    $IPTABLES -A INPUT   -m state --state ESTABLISHED,RELATED -j ACCEPT 
    $IPTABLES -A OUTPUT  -m state --state ESTABLISHED,RELATED -j ACCEPT 
    $IPTABLES -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
    
    # add anti-lockout rules
    $IPTABLES -N AUTOGEN_ANTI_LOCKOUT
    {% for manegement_ip in  vars.fw_manegement_ips%}
    $IPTABLES -A INPUT -s {{vars.mys_ip_addr}} -d {{manegement_ip.addr_value.split('/')[0]}} -m state --state NEW -j AUTOGEN_ANTI_LOCKOUT
    {% endfor %}
    $IPTABLES -A AUTOGEN_ANTI_LOCKOUT  -j LOG  --log-level info --log-prefix "AUTOGEN_ANTI_LOCKOUT_RULE "
    $IPTABLES -A AUTOGEN_ANTI_LOCKOUT  -j ACCEPT
    
    {% if vars.v4_nat_rules %}
    # ================ Table 'nat',  rule set NAT
    {% for rule in vars.v4_nat_rules %}
    # 
    # RULE -- {{ rule.name }} (NAT)
    # 
    echo "{{ rule.name }}"
    # {{ rule.comment }}
    {% for command in rule.commands %}
    {{ command }}
    {% endfor %}
    {% endfor %}
    {% endif %}

    {% if vars.v4_policy_rules %}
    # ================ Table 'filter', rule set POLICY
    {% for rule in vars.v4_policy_rules %}
    # 
    # RULE -- {{ rule.name }}
    # 
    echo "{{ rule.name }}"
    # {{ rule.comment }}
    {% for command in rule.commands %}
    {{ command }}
    {% endfor %}
    {% endfor %}
    {% endif %}

    {% if vars.v4_routing_rules %}
    # ============== ROUTING RULES ============== 

    HAVE_MKTEMP=$(which mktemp)

    test -n "$HAVE_MKTEMP" && {
      TMPDIRNAME=$(mktemp -d)
      test -z "$TMPDIRNAME" && exit 1
    }

    test -z "$HAVE_MKTEMP" && {
      TMPDIRNAME="/tmp/.ahtapotgdys.tempdir.$$"
      (umask 077 && mkdir $TMPDIRNAME) || exit 1
    }

    TMPFILENAME="$TMPDIRNAME/.ahtapotgdys.out"
    OLD_ROUTES="$TMPDIRNAME/.old_routes"

    #
    # This function stops stdout redirection
    # and sends previously saved output to terminal
    restore_script_output()
    {
      exec 1>&3 2>&1
      cat $TMPFILENAME
      rm -rf $TMPDIRNAME
    }

    # if any routing rule fails we do our best to prevent freezing the firewall
    route_command_error()
    {
      echo "Error: Routing rule $1 couldn't be activated"
      echo "Recovering previous routing configuration..."
      # delete current routing rules
      $IP route show | while read route ; do $IP route del $route ; done
      # restore old routing rules
      sh $OLD_ROUTES
      echo "...done"
      restore_script_output
      epilog_commands
      exit 1
    }

    # redirect output to prevent ssh session from stalling
    exec 3>&1
    exec 1> $TMPFILENAME
    exec 2>&1

    # store previous routing configuration (sort: 'via' GW has to be
    # inserted after device routes)

    $IP route show | sort -k 2 | awk '{printf "ip route add %s\n",$0;}' > $OLD_ROUTES

    echo "Deleting routing rules previously set by user space processes..."
    $IP route show | grep -v '\( proto kernel \)\|\(default via \)' | \
        while read route ; do $IP route del $route ; done
        
    echo "Activating non-ecmp routing rules..."
    {% for rule in vars.v4_routing_rules %}
    # 
    # RULE -- {{ rule.name }} (route)
    # 
    echo "{{ rule.name }}"
    # 
    # 
    #
    {% for command in rule.commands %}
    {{ command }} \
    || route_command_error "{{ rule.name }}"
    {% endfor %}
    {% endfor %}

    restore_script_output
    echo "...done."
    {% endif %}
}

epilog_commands() {
    echo "Running epilog script"
    {% if vars.epilog_commands is defined %}
    {% for epilog_command in vars.epilog_commands %}
    {{ epilog_command }}
    {% endfor %}
    {% endif %}
}

load_modules() {
    :
    OPTS=$1
    MODULES_DIR="/lib/modules/`uname -r`/kernel/net/"
    MODULES=$(find $MODULES_DIR -name '*conntrack*' \! -name '*ipv6*'|sed  -e 's/^.*\///' -e 's/\([^\.]\)\..*/\1/')
    echo $OPTS | grep -q nat && {
        MODULES="$MODULES $(find $MODULES_DIR -name '*nat*'|sed  -e 's/^.*\///' -e 's/\([^\.]\)\..*/\1/')"
    }
    echo $OPTS | grep -q ipv6 && {
        MODULES="$MODULES $(find $MODULES_DIR -name nf_conntrack_ipv6|sed  -e 's/^.*\///' -e 's/\([^\.]\)\..*/\1/')"
    }
    for module in $MODULES; do 
        if $LSMOD | grep ${module} >/dev/null; then continue; fi
        $MODPROBE ${module} ||  exit 1 
    done
}

ip_forward() {
    :
    echo 1 > /proc/sys/net/ipv4/ip_forward
}

reset_all() {
    :
    reset_iptables_v4
}

stop_action() {
    reset_all
    $IPTABLES -P OUTPUT  ACCEPT
    $IPTABLES -P INPUT   ACCEPT
    $IPTABLES -P FORWARD ACCEPT
}


# See how we were called.
# For backwards compatibility missing argument is equivalent to 'start'

cmd=$1
test -z "$cmd" && {
    cmd="start"
}

case "$cmd" in
    start)
        check_tools
        load_modules "nat "
        # configure_interfaces
        # verify_interfaces
        
        reset_all 
        
        script_body
        ip_forward
        epilog_commands
        RETVAL=$?
        ;;

    stop)
        stop_action
        RETVAL=$?
        ;;

    status)
        status_action
        RETVAL=$?
        ;;

    # block)
    #     block_action
    #     RETVAL=$?
    #     ;;

    reload)
        $0 stop
        $0 start
        RETVAL=$?
        ;;
    # interfaces)
    #     configure_interfaces
    #     RETVAL=$?
    #     ;;

    # test_interfaces)
    #     FWBDEBUG="echo"
    #     configure_interfaces
    #     RETVAL=$?
    #     ;;
    *)
    echo "Usage $0 [start|stop|status|block|reload|interfaces|test_interfaces]"
    ;;

esac

exit $RETVAL