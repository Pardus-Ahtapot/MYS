from functools import wraps
from flask import current_app, g
from flask_login import current_user
from app import db

def permission_required(*permission_names):
    """| This decorator ensures that the current user is logged in,
    | and has *all* of the specified permissions (AND operation).

    Example::

        @route('/escape')
        @permission_required('Special', 'Agent')
        def escape_capture():  # User must be 'Special' AND 'Agent'
            ...

    | Calls unauthenticated_view() when the user is not logged in
        or when user has not confirmed their email address.
    | Calls unauthorized_view() when the user does not have the required permissions.
    | Calls the decorated view otherwise.
    """
    def wrapper(view_function):
        @wraps(view_function)    # Tells debuggers that is a function wrapper
        def decorator(*args, **kwargs):
            user_manager = current_app.user_manager

            user_permissions = []
            for role in current_user.roles:
                for perm in role.permissions:
                    user_permissions.append(perm.name)
                
            has_perm = True
            for requirement in permission_names:
                if isinstance(requirement, (list, tuple)):
                    # this is a tuple_of_perm_names requirement
                    tuple_of_perm_names = requirement
                    authorized = False
                    for perm_name in tuple_of_perm_names:
                        if perm_name in user_permissions:
                            # tuple_of_perm_names requirement was met: break out of loop
                            authorized = True
                            break
                    if not authorized:
                        has_perm = False                    # tuple_of_perm_names requirement failed: return False
                else:
                    # this is a perm_name requirement
                    perm_name = requirement
                    # the user must have this role
                    if not perm_name in user_permissions:
                        has_perm = False                    # perm_name requirement failed: return False

            # User must have the required permissions
            if not has_perm:
                # Redirect to the unauthorized page
                return user_manager.unauthorized_view()

            # It's OK to call the view
            return view_function(*args, **kwargs)
        return decorator
    return wrapper