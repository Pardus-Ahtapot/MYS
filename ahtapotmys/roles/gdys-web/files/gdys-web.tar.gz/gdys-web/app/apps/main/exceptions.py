class DoesNotExist(Exception):
    pass

exceptions = {
     "DoesNotExist": {
         "message": "Record could not be found in the database",
         "status": 401
     }
}
