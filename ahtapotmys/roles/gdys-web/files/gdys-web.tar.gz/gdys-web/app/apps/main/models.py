from app import db
from flask_babelex import Babel
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy_utils import IPAddressType, JSONType
from sqlalchemy import event
from sqlalchemy.ext.orderinglist import ordering_list
from flask_user import current_user, login_required, roles_required, UserManager, UserMixin
from sqlalchemy.sql import func
import datetime
import netaddr
import socket

# -*- USER MODELS -*-*

# Define the User data-model
class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    # User authentication information. The collation='NOCASE' is required
    # to search case insensitively when USER_IFIND_MODE is 'nocase_collation'.
    username = db.Column(db.String(100, collation='NOCASE'), nullable=False, unique=True)
    email = db.Column(db.String(255, collation='NOCASE'), nullable=False, unique=True)
    email_confirmed_at = db.Column(db.DateTime())
    password = db.Column(db.String(255), nullable=False, server_default='')
    password_valid_date = db.Column(db.DateTime())

    # User information
    active = db.Column(db.Boolean())
    name = db.Column(db.String(100, collation='NOCASE'), nullable=False, server_default='')

    # Define the relationship to Role via UserRoles
    roles = db.relationship('Role', secondary='user_roles')

    @property
    def passwd_expired(self):
        if not self.password_valid_date:
            return False
        return self.password_valid_date <= datetime.datetime.now()

    def has_permission(self, perm_id = "", perm_name = ""):
        for role in self.roles:
            if role.have_permission(perm_id, perm_name):
                return True
        return False

    def have_role(self, role_id = "", role_name = ""):
        try:
            if role_id:
                role_ids = [role.id for role in self.roles]
                if int(role_id) in role_ids:
                    return True
                else:
                    return False
            elif role_name:
                role_names = [role.name for role in self.roles]
                if role_name in role_names:
                    return True
                else:
                    return False
        except Exception as e:
            return False

    def can_access_fw(self, fw_id):
        for role in self.roles:
            if role.can_access_fw(fw_id):
                return True
        return False
    
    @property
    def role_names(self):
        role_names = []
        for role in self.roles:
            role_names.append(role.name)
        return role_names

    @property
    def role_ids(self):
        role_ids = []
        for role in self.roles:
            role_ids.append(role.id)
        return role_ids

    def get_fw_ids(self):        
        fw_ids = []
        for role in self.roles:
            fw_ids = fw_ids + role.get_fw_ids()
        return fw_ids

# Define the Role data-model
class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(50), unique=True)
    description = db.Column(db.Text())
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    permissions = db.relationship('Permission', secondary='role_permissions')
    firewalls = db.relationship('Firewall', secondary='role_firewalls')

    @property
    def permission_names(self):
        permission_names = []
        for perm in self.permissions:
            permission_names.append(perm.name)
        return permission_names

    @property
    def permission_descs(self):
        permission_descs = []
        for perm in self.permissions:
            permission_descs.append(perm.description)
        return permission_descs

    @property
    def permission_ids(self):
        permission_ids = []
        for perm in self.permissions:
            permission_ids.append(perm.id)
        return permission_ids

    @property
    def firewall_ids(self):
        firewall_ids = []
        for fw in self.firewalls:
            firewall_ids.append(fw.id)
        return firewall_ids  

    def have_permission(self, perm_id = "", perm_name = ""):
        try:
            if "super_user" in self.permission_names:
                return True

            if perm_id:
                perm_ids = [perm.id for perm in self.permissions]
                if int(perm_id) in perm_ids:
                    return True
                else:
                    return False
            elif perm_name:
                perm_names = [perm.name for perm in self.permissions]
                if perm_name in perm_names:
                    return True
                else:
                    return False
        except Exception as e:
            return False
            

    def can_access_fw(self, fw_id):
        try:
            if self.have_permission(perm_name="super_user"):
                return True
            fw_ids = [fw.id for fw in self.firewalls]
            if int(fw_id) in fw_ids:
                return True
            else:
                return False            
        except Exception as e:
            return False

    def get_fw_ids(self):   
        if self.have_permission(perm_name="super_user"):
            return [fw.id for fw in Firewall.query.all()]
        fw_ids = []
        for fw in self.firewalls:
            fw_ids.append(fw.id)
        return fw_ids

# Define the Permission data-model
class Permission(db.Model):
    __tablename__ = 'permissions'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(50), unique=True)
    description = db.Column(db.Text())
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

# Define the UserRoles association table
class UserRoles(db.Model):
    __tablename__ = 'user_roles'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey('users.id', ondelete='CASCADE'))
    role_id = db.Column(db.Integer(), db.ForeignKey('roles.id', ondelete='CASCADE'))
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

# Define the RolePermissions association table
class RolePermissions(db.Model):
    __tablename__ = 'role_permissions'
    id = db.Column(db.Integer(), primary_key=True)
    role_id = db.Column(db.Integer(), db.ForeignKey('roles.id', ondelete='CASCADE'))
    permission_id = db.Column(db.Integer(), db.ForeignKey('permissions.id', ondelete='CASCADE'))
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())      

# Define the RoleFirewalls association table
class RoleFirewalls(db.Model):
    __tablename__ = 'role_firewalls'
    id = db.Column(db.Integer(), primary_key=True)
    role_id = db.Column(db.Integer(), db.ForeignKey('roles.id', ondelete='CASCADE'))
    firewall_id = db.Column(db.Integer(), db.ForeignKey('firewall.id', ondelete='CASCADE'))
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp()) 

# -*- GENERAL DATA MODELS -*-*

class Address(db.Model):
    __tablename__ = 'address'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False, unique=True)
    addr_type = db.Column(db.Text(), nullable=False) # Available types: "fqdn, range, netmask, geo(CN)"
    addr_value = db.Column(db.Text())
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    def __unicode__(self):
        return ("[%s(%s)]" % (self.__class__.__name__, ', '.join('%s=%s' % (k, self.__dict__[k]) for k in sorted(self.__dict__) if '_sa_' != k[:4])))

    @property
    def get_ipt_addr(self):
        ret = ""
        if self.addr_type == "range":
            addr = self.addr_value.split('-')
            cidrs = netaddr.iprange_to_cidrs(addr[0], addr[1])
            res = []
            for cidr in cidrs:
                cidr = format(cidr)
                if cidr.split('/')[1] == '32':
                    cidr = cidr.split('/')[0]
                res.append(cidr)
            ret = ','.join(res)
        elif self.addr_type == "netmask" and self.addr_value.split('/')[1] == '32':
            return self.addr_value.split('/')[0]
        if self.addr_type == "fqdn":
            return socket.gethostbyname(self.addr_value)
        else:
            ret = self.addr_value
        return ret
    
class Service(db.Model):
    __tablename__ = 'service'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False, unique=True)
    category = db.Column(db.Text())
    protocol = db.Column(db.Text())
    src_start_port = db.Column(db.Integer())
    src_end_port = db.Column(db.Integer())
    dst_start_port = db.Column(db.Integer())
    dst_end_port = db.Column(db.Integer())
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    def __unicode__(self):
        return ("[%s(%s)]" % (self.__class__.__name__, ', '.join('%s=%s' % (k, self.__dict__[k]) for k in sorted(self.__dict__) if '_sa_' != k[:4])))

    @property
    def raw_ports(self):
        if self.src_start_port == self.src_end_port:
            src_port = str(self.src_start_port or '')
        else:
            src_port = str(self.src_start_port or '') + ":" + str(self.src_end_port or '')

        if self.dst_start_port == self.dst_end_port:
            dst_port = str(self.dst_start_port or '')
        else:
            dst_port = str(self.dst_start_port or '') + ":" + str(self.dst_end_port or '')
        return [src_port,dst_port]
    
class TimeProfile(db.Model):
    __tablename__ = 'time_profile'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False, unique=True)
    days = db.Column(db.Text(), nullable=False)
    start_date = db.Column(db.DateTime())
    start_time = db.Column(db.DateTime())
    end_date = db.Column(db.DateTime())
    end_time = db.Column(db.DateTime())
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    @property
    def turkish_days(self):
        translations = {
            "monday": "Pazartesi",
            "thuesday": "Salı",
            "wednesday": "Çarşamba",
            "thursday": "Perşembe",
            "friday": "Cuma",
            "saturday": "Cumartesi",
            "sunday": "Pazar"
        }
        return ",".join([translations[day] for day in self.days.split(",")])

    @property
    def day_numbers(self):
        translations = {
            "monday": "1",
            "thuesday": "2",
            "wednesday": "3",
            "thursday": "4",
            "friday": "5",
            "saturday": "6",
            "sunday": "7"
        }
        return ",".join([translations[day] for day in self.days.split(",")])
    

    def __unicode__(self):
        return ("[%s(%s)]" % (self.__class__.__name__, ', '.join('%s=%s' % (k, self.__dict__[k]) for k in sorted(self.__dict__) if '_sa_' != k[:4])))

InterfaceAddr = db.Table('interface_addr',
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)

class Interface(db.Model):
    __tablename__ = 'interface'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False)
    iface_type = db.Column(db.String(255, collation='NOCASE'))
    addr = db.relationship("Address", secondary=InterfaceAddr, lazy='subquery', backref="owned_interface")
    is_manegement = db.Column(db.Boolean(), server_default='0')
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

# -*- RULE MODELS -*-*

PolicyRuleSrcAddr = db.Table('policy_rule_src_addr',
    db.Column('policy_rule_id', db.Integer, db.ForeignKey('policy_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)

PolicyRuleDstAddr = db.Table('policy_rule_dst_addr',
    db.Column('policy_rule_id', db.Integer, db.ForeignKey('policy_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
PolicyRuleService = db.Table('policy_rule_service',
    db.Column('policy_rule_id', db.Integer, db.ForeignKey('policy_rule.id'), primary_key=True),
    db.Column('service_id', db.Integer, db.ForeignKey('service.id'), primary_key=True)
)
PolicyRuleInterface = db.Table('policy_rule_interface',
    db.Column('policy_rule_id', db.Integer, db.ForeignKey('policy_rule.id'), primary_key=True),
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id'), primary_key=True)
)


class PolicyRule(db.Model):
    __tablename__ = 'policy_rule'
    id = db.Column(db.Integer(), primary_key=True)
    active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False)
    rule_type = db.Column(db.String(255, collation='NOCASE'), nullable=False) # IPv4 or IPv6
    direction = db.Column(db.Text())
    action = db.Column(db.Text())
    comment = db.Column(db.Text())
    log = db.Column(db.Boolean(), nullable=False, server_default='1')
    firewalls = db.relationship("FwPolicyRules", back_populates="rule")
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    negate_src_addr = db.Column(db.Boolean(), nullable=False, server_default='0')
    negate_dst_addr = db.Column(db.Boolean(), nullable=False, server_default='0')

    # Foreign key assignments for relationships
    time_profile_id = db.Column(db.Integer(), db.ForeignKey(TimeProfile.id, ondelete='CASCADE'))
    
    # Relationship definitions for access the objects directly like "policy_rule.src_addr".
    src_addr = db.relationship("Address", secondary=PolicyRuleSrcAddr, lazy='subquery', backref="policy_src_addr")
    dst_addr = db.relationship("Address", secondary=PolicyRuleDstAddr, lazy='subquery',backref="policy_dst_addr")
    port = db.relationship("Service", secondary=PolicyRuleService, lazy='subquery',backref="policy_port")
    interface = db.relationship("Interface", secondary=PolicyRuleInterface, lazy='subquery',backref="policy_interface")
    time_profile = db.relationship("TimeProfile", foreign_keys=[time_profile_id], lazy='subquery',backref=db.backref("policy_time_profile", uselist=True))


NatRuleOrgSrcAddr = db.Table('nat_rule_org_src_addr',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
NatRuleOrgDstAddr = db.Table('nat_rule_org_dst_addr',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
NatRuleTrnSrcAddr = db.Table('nat_rule_trn_src_addr',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
NatRuleTrnDstAddr = db.Table('nat_rule_trn_dst_addr',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
NatRuleOrgService = db.Table('nat_rule_org_service',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('service_id', db.Integer, db.ForeignKey('service.id'), primary_key=True)
)
NatRuleTrnService = db.Table('nat_rule_trn_service',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('service_id', db.Integer, db.ForeignKey('service.id'), primary_key=True)
)
NatRuleInterfaceIn = db.Table('nat_rule_interface_in',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id'), primary_key=True)
)
NatRuleInterfaceOut = db.Table('nat_rule_interface_out',
    db.Column('nat_rule_id', db.Integer, db.ForeignKey('nat_rule.id'), primary_key=True),
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id'), primary_key=True)
)

class NatRule(db.Model):
    __tablename__ = 'nat_rule'
    id = db.Column(db.Integer(), primary_key=True)
    active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False)
    rule_type = db.Column(db.String(255, collation='NOCASE'), nullable=False) # IPv4 or IPv6
    action = db.Column(db.Text())
    comment = db.Column(db.Text())
    log = db.Column(db.Boolean(), nullable=False, server_default='1')
    firewalls = db.relationship("FwNatRules", back_populates="rule")
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    negate_original_src = db.Column(db.Boolean(), nullable=False, server_default='0')
    negate_original_dst = db.Column(db.Boolean(), nullable=False, server_default='0')

    # Foreign key assignments for relationships
    time_profile_id = db.Column(db.Integer(), db.ForeignKey(TimeProfile.id, ondelete='CASCADE'))

    # Relationship definitions for access the objects directly like "nat_rule.original_src".
    original_src = db.relationship("Address", secondary=NatRuleOrgSrcAddr, backref="nat_original_src")
    original_dst = db.relationship("Address", secondary=NatRuleOrgDstAddr, backref="nat_original_dst")
    original_srv = db.relationship("Service", secondary=NatRuleOrgService, backref="nat_original_srv")
    translated_src = db.relationship("Address", secondary=NatRuleTrnSrcAddr, backref="nat_translated_src")
    translated_dst = db.relationship("Address", secondary=NatRuleTrnDstAddr, backref="nat_translated_dst")
    translated_srv = db.relationship("Service", secondary=NatRuleTrnService, backref="nat_translated_srv")
    interface_in = db.relationship("Interface", secondary=NatRuleInterfaceIn, backref="nat_interface_in")
    interface_out = db.relationship("Interface", secondary=NatRuleInterfaceOut, backref="nat_interface_out")
    time_profile = db.relationship("TimeProfile", foreign_keys=[time_profile_id], backref=db.backref("nat_time_profile", uselist=True))

RoutingRuleDst = db.Table('routing_rule_src_addr',
    db.Column('routing_rule_id', db.Integer, db.ForeignKey('routing_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
RoutingRuleGw = db.Table('routing_rule_dst_addr',
    db.Column('routing_rule_id', db.Integer, db.ForeignKey('routing_rule.id'), primary_key=True),
    db.Column('address_id', db.Integer, db.ForeignKey('address.id'), primary_key=True)
)
RoutingRuleInterface = db.Table('routing_rule_interface',
    db.Column('routing_rule_id', db.Integer, db.ForeignKey('routing_rule.id'), primary_key=True),
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id'), primary_key=True)
)

class RoutingRule(db.Model):
    __tablename__ = 'routing_rule'
    id = db.Column(db.Integer(), primary_key=True)
    active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False)
    rule_type = db.Column(db.String(255, collation='NOCASE'), nullable=False) # IPv4 or IPv6
    comment = db.Column(db.Text())
    log = db.Column(db.Boolean(), nullable=False, server_default='1')
    firewalls = db.relationship("FwRoutingRules", back_populates="rule")
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    # Relationship definitions for access the objects directly like "routing_rule.destination".
    destination = db.relationship("Address", secondary=RoutingRuleDst, backref="routing_destination")
    gateway = db.relationship("Address", secondary=RoutingRuleGw, backref="routing_gateway")
    interface = db.relationship("Interface", secondary=RoutingRuleInterface, backref="routing_interface")

# -*- FIREWALL MODELS -*-*

class FwPolicyRules(db.Model):
    __tablename__ = 'fw_policy_rules'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    firewall_id = db.Column(db.Integer, db.ForeignKey('firewall.id', ondelete='CASCADE'))
    policy_rule_id = db.Column(db.Integer, db.ForeignKey('policy_rule.id', ondelete='CASCADE'))
    rank = db.Column(db.Integer, autoincrement=True)
    rule = db.relationship("PolicyRule", back_populates="firewalls", lazy='joined')
    firewall = db.relationship("Firewall", back_populates="policy_rules", lazy='joined')

class FwNatRules(db.Model):
    __tablename__ = 'fw_nat_rules'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    firewall_id = db.Column(db.Integer, db.ForeignKey('firewall.id', ondelete='CASCADE'))
    nat_rule_id = db.Column(db.Integer, db.ForeignKey('nat_rule.id', ondelete='CASCADE'))
    rank = db.Column(db.Integer, autoincrement=True)
    rule = db.relationship("NatRule", back_populates="firewalls", lazy='joined')
    firewall = db.relationship("Firewall", back_populates="nat_rules", lazy='joined')

class FwRoutingRules(db.Model):
    __tablename__ = 'fw_routing_rules'

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    firewall_id = db.Column(db.Integer, db.ForeignKey('firewall.id', ondelete='CASCADE'))
    routing_rule_id = db.Column(db.Integer, db.ForeignKey('routing_rule.id', ondelete='CASCADE'))
    rank = db.Column(db.Integer, autoincrement=True)
    rule = db.relationship("RoutingRule", back_populates="firewalls", lazy='joined')
    firewall = db.relationship("Firewall", back_populates="routing_rules", lazy='joined')

interfaces = db.Table('fw_interfaces',
    db.Column('firewall_id', db.Integer, db.ForeignKey('firewall.id', ondelete='cascade'), primary_key=True),
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id', ondelete='cascade'), primary_key=True)
)

class Firewall(db.Model):
    __tablename__ = 'firewall'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(255, collation='NOCASE'), nullable=False, unique=True)
    created_at = db.Column(db.TIMESTAMP, server_default=func.now())
    updated_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())
    policy_rules = db.relationship("FwPolicyRules", back_populates="firewall", lazy='select', cascade="save-update, merge, delete, delete-orphan",
                                    order_by="FwPolicyRules.rank", collection_class=ordering_list('rank'))

    nat_rules = db.relationship("FwNatRules", back_populates="firewall", lazy='select', cascade="save-update, merge, delete, delete-orphan",
                                    order_by="FwNatRules.rank", collection_class=ordering_list('rank'))
    routing_rules = db.relationship("FwRoutingRules", back_populates="firewall", lazy='select', cascade="save-update, merge, delete, delete-orphan", 
                                    order_by="FwRoutingRules.rank", collection_class=ordering_list('rank'))

    interfaces = db.relationship('Interface', secondary=interfaces, lazy='select', backref=db.backref('used_firewalls', lazy=True, uselist=True))

    @property
    def is_change(self):
        return (Commit.query.filter(Commit.is_applied == False).filter(Commit.firewall == self.name).count() > 0)
    
    @property
    def manegement_iface(self):
        for iface in self.interfaces:
            if iface.is_manegement:
                return iface
    @property
    def manegement_ip(self):
        for iface in self.interfaces:
            if iface.is_manegement:
                return iface.addr
    @property
    def all_ips(self):
        ips = []
        for iface in self.interfaces:
            for ip in iface.addr:
                ips.append(ip)
        return ips
      
class Commit(db.Model):
    __tablename__ = "commit"

    id = db.Column(db.Integer(), primary_key=True)
    uuid = db.Column(db.String(128), nullable=False)
    is_applied = db.Column(db.Boolean(), server_default='0')
    commited_by = db.Column(db.Text())
    applied_by = db.Column(db.Text())
    commited_at = db.Column(db.TIMESTAMP, server_default=func.now())
    applied_at = db.Column(db.TIMESTAMP, server_default=func.now(), onupdate=func.current_timestamp())

    firewall = db.Column(db.Text())
    section = db.Column(db.Text())
    operation = db.Column(db.Text())


# @event.listens_for(db.Session, 'after_flush')
def delete_rule_orphans(session, ctx):
    session.query(PolicyRule).filter(~PolicyRule.firewalls.any()).delete(synchronize_session=False)
    session.query(NatRule).filter(~NatRule.firewalls.any()).delete(synchronize_session=False)
    session.query(RoutingRule).filter(~RoutingRule.firewalls.any()).delete(synchronize_session=False)