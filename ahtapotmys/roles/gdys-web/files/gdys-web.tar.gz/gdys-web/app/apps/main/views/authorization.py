from flask import render_template, flash, redirect, url_for, request, jsonify, session, current_app
from app.apps.main import models as main_models
from flask_user import current_user, login_required, roles_required, UserManager, UserMixin
from sqlalchemy import inspect, or_, and_, func, alias
from sqlalchemy_filters import apply_filters
from sqlalchemy.orm import aliased, joinedload
from app import ACTIVE_FW, db
from app.apps.main.utils import *
from app.apps.main.permissions import permission_required
from dateutil.relativedelta import relativedelta

import traceback
import ipaddress, json
import datetime

@login_required
def user_validation():
    if current_user.passwd_expired:
        flash('Şifrenizin süresi dolmuş!', 'error')
        return redirect("/user/change-password", code=302)
    else:
        return redirect("/", code=302)

@login_required
def user_set_passwd_expire():
    current_user.password_valid_date = datetime.datetime.utcnow() + relativedelta(months=+6)
    db.session.commit()
    return redirect("/", code=302)

@login_required
@permission_required(['view_user', 'super_user'])
def users(err=False, saved=False, msg=""):
    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "users" not in referrer:
        clear_filter_params()

    User = main_models.User
    Role = main_models.Role
    extra_vars = get_default_payload()

    filters = {
        "name": User.name,
        "username": User.username,
        "email": User.email,
    }

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))    
    
    try:
        filter_field, filter_input = get_filter_params()
        """the function returns the index page when the user is logged in"""
        if filter_field and filter_input:
            users = User.query.filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(User.id).paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            users = User.query.order_by(User.id).paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        users = User.query.order_by(User.id).paginate(per_page=per_page, page=page, error_out=True)
        clear_filter_params()

    extra_vars['page_name'] = 'users'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['users'] = users
    extra_vars['roles'] = Role.query.all()
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('users.html', vars=extra_vars)

@login_required
@permission_required(['edit_user', 'super_user'])
def add_new_user():
    User = main_models.User
    Role = main_models.Role
    user_manager = current_app.user_manager

    try:
        user_name_surname = request.form.get("user_name_surname")
        user_username = request.form.get("user_username")
        user_email = request.form.get("user_email")
        user_passwd = request.form.get("user_passwd")
        user_passwd_expired = True if request.form.get("user_passwd_expired") == "on" else False
        user_active = True if request.form.get("user_active", default="off") == "on" else False
        user_role = request.form.get("user_role")

        if User.query.filter(or_(User.username == user_username.lower(), User.email == user_email.lower())).first():
            return users(err=True, msg="Kullanıcı zaten mevcut!")
        
        user = User(
            name=user_name_surname,
            username=user_username,
            email=user_email,
            email_confirmed_at=datetime.datetime.utcnow(),
            password=user_manager.hash_password(user_passwd),
            active=user_active
        )
        user.roles.append(Role.query.filter(Role.id == user_role).first())

        if user_passwd_expired:
            user.password_valid_date = datetime.datetime.utcnow()

        db.session.add(user)
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('users' + ' <UserName: ' + user_username + '>'), operation='add')
        return users(saved=True, msg="Kullanıcı basariyla eklendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return users(err=True, msg="Kullanıcı eklenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['edit_user', 'super_user'])
def update_user(user_id: int):
    User = main_models.User
    Role = main_models.Role
    user_manager = current_app.user_manager

    try:
        user_name_surname = request.form.get("user_name_surname")
        user_username = request.form.get("user_username")
        user_email = request.form.get("user_email")
        user_passwd = request.form.get("user_passwd", default="")
        user_passwd_expired = True if request.form.get("user_passwd_expired") == "on" else False
        user_active = True if request.form.get("user_active", default="off") == "on" else False
        user_role = request.form.get("user_role")

        exist_user = User.query.filter(or_(User.username == user_username.lower(), User.email == user_email.lower())).first()
        if exist_user and int(user_id) != int(exist_user.id):
            return users(err=True, msg="Bu epostayı/kullanıcı adını kullanan başka bir kullanıcı mevcut!")
        
        user = User.query.filter(User.id == user_id).first()
        user.name = user_name_surname
        user.username = user_username
        user.email = user_email
        user.email_confirmed_at = datetime.datetime.utcnow()
        user.active = user_active
        if user_passwd:
            user.password = user_manager.hash_password(user_passwd)
        if user_passwd_expired:
            user.password_valid_date = datetime.datetime.utcnow()

        user.roles.clear()
        user.roles.append(Role.query.filter(Role.id == user_role).first())
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('users' + ' <UserName: ' + user_username + '>'), operation='update')
        return users(saved=True, msg="Kullanıcı basariyla guncellendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return users(err=True, msg="Kullanıcı guncellenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['view_role', 'super_user'])
def roles(err=False, saved=False, msg=""):
    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "users" not in referrer:
        clear_filter_params()

    Role = main_models.Role
    Permission = main_models.Permission
    Firewall = main_models.Firewall
    extra_vars = get_default_payload()

    filters = {
        "name": Role.name,
        "description": Role.description,
    }

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))    
    
    try:
        filter_field, filter_input = get_filter_params()
        """the function returns the index page when the user is logged in"""
        if filter_field and filter_input:
            roles = Role.query.filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(Role.id).paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            roles = Role.query.order_by(Role.id).paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        roles = Role.query.order_by(Role.id).paginate(per_page=per_page, page=page, error_out=True)
        clear_filter_params()

    extra_vars['page_name'] = 'roles'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['roles'] = roles
    extra_vars['permissions'] = Permission.query.all()
    extra_vars['firewalls'] = Firewall.query.all()
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('roles.html', vars=extra_vars)

@login_required
@permission_required(['edit_role', 'super_user'])
def add_new_role():
    Role = main_models.Role
    Permission = main_models.Permission
    Firewall = main_models.Firewall
    user_manager = current_app.user_manager

    try:
        role_name = request.form.get("role_name")
        role_desc = request.form.get("role_desc")
        super_user = True if request.form.get("is_super_user", default="off") == "on" else False

        permission_ids = request.form.getlist('permissions', None)
        permissions = []
        if permission_ids and not super_user:
            for perm_id in permission_ids:
                permissions.append(Permission.query.filter(Permission.id == perm_id).first())
        elif super_user:
            permissions.append(Permission.query.filter(Permission.name == "super_user").first())
        
        fw_ids = request.form.getlist('firewalls', None)
        firewalls = []
        if fw_ids and not super_user:
            for fw_id in fw_ids:
                firewalls.append(Firewall.query.filter(Firewall.id == fw_id).first())

        if Role.query.filter(Role.name == role_name).first():
            return roles(err=True, msg="Grup zaten mevcut!")
        
        role = Role(
            name=role_name,
            description=role_desc,
            permissions=permissions,
            firewalls=firewalls
        )

        db.session.add(role)
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('roles' + ' <RoleName: ' + role_name + '>'), operation='add')
        return roles(saved=True, msg="Grup basariyla eklendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return roles(err=True, msg="Grup eklenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['edit_role', 'super_user'])
def update_role(role_id: int):
    Role = main_models.Role
    Permission = main_models.Permission
    Firewall = main_models.Firewall
    user_manager = current_app.user_manager

    try:
        role_name = request.form.get("role_name")
        role_desc = request.form.get("role_desc")
        super_user = True if request.form.get("is_super_user", default="off") == "on" else False

        permission_ids = request.form.getlist('permissions', None)
        permissions = []
        if permission_ids and not super_user:
            for perm_id in permission_ids:
                permissions.append(Permission.query.filter(Permission.id == perm_id).first())
        elif super_user:
            permissions.append(Permission.query.filter(Permission.name == "super_user").first())
        
        fw_ids = request.form.getlist('firewalls', None)
        firewalls = []
        if fw_ids and not super_user:
            for fw_id in fw_ids:
                firewalls.append(Firewall.query.filter(Firewall.id == fw_id).first())
        
        exist_role = Role.query.filter(Role.name == role_name).first()
        if exist_role and int(role_id) != int(exist_role.id):
            return roles(err=True, msg="Bu isimde bir grup zaten mevcut!")


        role = Role.query.filter(Role.id == role_id).first()
        role.name=role_name
        role.description=role_desc
        role.permissions=permissions
        role.firewalls=firewalls
        
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('roles' + ' <RoleName: ' + role_name + '>'), operation='update')
        return roles(saved=True, msg="Grup basariyla guncellendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return roles(err=True, msg="Grup guncellenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['view_user', 'super_user'])
def get_user():
    User = main_models.User

    try:
        user_id = request.args.get('user_id',default=None)
        user = User.query.filter(User.id == user_id).first()
        json_dump = json.dumps(user, cls=AlchemyEncoder)
        json_resp = json.loads(json_dump)
        json_resp.pop("password")
        return json.dumps(json_resp)
    except Exception as e:
        return jsonify(success=False)

@login_required
@permission_required(['edit_user', 'super_user'])
def delete_user(user_id: int):
    User = main_models.User

    try:
        user_name = User.query.filter(User.id == user_id).first().name
        User.query.filter(User.id == user_id).delete()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('users' + ' <UserName: ' + user_name + '>'), 
                    operation='delete')
        db.session.commit()
    except Exception as e:
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
@permission_required(['view_role', 'super_user'])
def get_role():
    Role = main_models.Role

    try:
        role_id = request.args.get('role_id',default=None)
        role = Role.query.filter(Role.id == role_id).first()
        return json.dumps(role, cls=AlchemyEncoder)
    except Exception as e:
        return jsonify(success=False)

@login_required
@permission_required(['edit_role', 'super_user'])
def delete_role(role_id: int):
    Role = main_models.Role

    try:
        role_name = Role.query.filter(Role.id == role_id).first().name
        Role.query.filter(Role.id == role_id).delete()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('roles' + ' <RoleName: ' + role_name + '>'), 
                    operation='delete')
        db.session.commit()
    except Exception as e:
        return jsonify(success=False)
    return jsonify(success=True)
        