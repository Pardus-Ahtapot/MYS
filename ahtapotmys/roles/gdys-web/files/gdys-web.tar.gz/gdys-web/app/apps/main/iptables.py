from app import app, db, log
from app.apps.main import models
from flask import render_template
from flask_user import current_user

import os
import socket
import traceback
import datetime
import netaddr

class ipt_chain():
    FORWARD = "FORWARD"
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    # Custom chains for policy
    FORWARD_IN = "FORWARD_IN"
    FORWARD_OUT = "FORWARD_OUT"
    # Nat specific chain
    PREROUTING = "PREROUTING"
    POSTROUTING = "POSTROUTING"


class ipt_target():
    DROP = "DROP"
    ACCEPT = "ACCEPT"
    REJECT = "REJECT"
    LOG = "LOG"
    # Nat specific target
    DNAT = "DNAT"
    SNAT = "SNAT"

class ipt_state():
    NEW = "NEW"
    ESTABLISHED = "ESTABLISHED"
    RELATED = "RELATED"

class ipt_table():
    NAT = "nat"
    FILTER = "filter"
    MANGLE = "mangle"

extra_matchs = {
    "icmp" : "--icmp-type any"
}

class IptablePolicyRule(object):
    """This class returns the basic functions of iptables as a string"""
    def __init__(self):
        self.IPTABLES = "$IPTABLES"
        self.RULE_COMMANDS = []

    class RawRule(object):
        def __init__(self):
            self.RULE = ""

        def join(self, param):
            self.RULE += (param + " ")

    def create_chain(self, chain_name):
        self.RULE_COMMANDS.append(self.IPTABLES + " -N {}".format(chain_name))

    def append_raw_command(self, command):
        self.RULE_COMMANDS.append(command)

    def append_to_chain(self, chain_name, target, direction=None, interface=None, protocol=None, ports: list=None, source=None, destination=None,
                        log_msg=None, state=None, negate_src=False, negate_dst=False, time_profile=None):
        """
            chain_name: RULE_0
            direction: both/inbound/outbound
            interface: None or iface_name
            protocol: protocol name like tcp,udp,icmp
            ports: List of ports ex: [[src_port,dst_port], [None,80], [100:112,130:133]]
            source: source ip addr or fqdn
            destination: destination ip addr or fqdn
            target: target chain name or action like DROP/ACCEPT/REJECT
        """

        # Manupilate chain if necessary
        _c_name = ""
        if chain_name == ipt_chain.FORWARD_OUT:
            _c_name = "FORWARD"
            direction = "outbound"
        elif chain_name == ipt_chain.FORWARD_IN:
            _c_name = "FORWARD"
            direction = "inbound"
        else:
            _c_name = chain_name

        raw_rule = self.RawRule()
        raw_rule.join(self.IPTABLES)
        # Add chain name
        raw_rule.join("-A {}".format(_c_name))
        # Add input or output interface
        if direction and direction.lower() != "both":
            # If direction is not both then check the is interface name exist
            interface = interface or '+'
            if direction.lower() == "outbound":
                raw_rule.join("-o {}".format(interface))
            elif direction.lower() == "inbound":
                raw_rule.join("-i {}".format(interface))
        elif direction and interface:
            raw_rule.join("-i {} -o {}".format(interface, interface))


        # Add protocol
        if protocol:
            raw_rule.join("-p {} -m {}".format(protocol, protocol))

        # Add source if exist
        if source:
            if negate_src:
                raw_rule.join("! -s {}".format(source))
            else:
                raw_rule.join("-s {}".format(source))

        # Add source if exist
        if destination:
            if negate_src:
                raw_rule.join("! -d {}".format(destination))
            else:
                raw_rule.join("-d {}".format(destination))

        # Add ports
        if ports:
            sports = ports[0].split(',')
            sports = sports if sports[0] != '' else [] # Split adding '' to list if there is nothing to splitting.
            dports = ports[1].split(',')
            dports = dports if dports[0] != '' else [] # Split adding '' to list if there is nothing to splitting.
            if len(sports) > 1 or len(dports) > 1:
                # If more than one port then add multiport match
                raw_rule.join("-m multiport")

            if sports:
                if len(sports) > 1:
                    raw_rule.join("--sports {}".format(",".join(sports)))
                else:
                    raw_rule.join("--sport {}".format(",".join(sports)))
            if dports:
                if len(dports) > 1:
                    raw_rule.join("--dports {}".format(",".join(dports)))
                else:
                    raw_rule.join("--dport {}".format(",".join(dports)))

        if protocol in extra_matchs.keys():
            raw_rule.join(extra_matchs[protocol])

        if state:
            raw_rule.join("-m state --state {}".format(state))

        if time_profile:
            raw_rule.join("-m time --kerneltz")

            datestart = time_profile.start_date.date().strftime('%Y-%m-%d') if time_profile.start_date else None
            if datestart:
                raw_rule.join("--datestart {}".format(datestart))

            datestop = time_profile.end_date.date().strftime('%Y-%m-%d') if time_profile.end_date else None
            if datestop:
                raw_rule.join("--datestop {}".format(datestop))

            timestart = time_profile.start_time.time().strftime('%H:%M') if time_profile.start_time else None
            if timestart:
                raw_rule.join("--timestart {}".format(timestart))

            timestop = time_profile.end_time.time().strftime('%H:%M') if time_profile.end_time else None
            if timestop:
                raw_rule.join("--timestop {}".format(timestop))

            weekdays = time_profile.day_numbers
            if weekdays:
                raw_rule.join("--weekdays {}".format(weekdays))

        # Add target
        raw_rule.join("-j {}".format(target))

        # Add Logging options
        if log_msg:
            raw_rule.join('--log-level info --log-prefix "{} "'.format(log_msg))

        self.RULE_COMMANDS.append(raw_rule.RULE)

class IptableNatRule(object):
    """This class returns the basic functions of iptables as a string"""
    def __init__(self):
        self.IPTABLES = "$IPTABLES"
        self.RULE_COMMANDS = []

    class RawRule(object):
        def __init__(self):
            self.RULE = ""

        def join(self, param):
            self.RULE += (param + " ")

    def create_chain(self, chain_name):
        self.RULE_COMMANDS.append(self.IPTABLES + " -N {}".format(chain_name))

    def append_raw_command(self, command):
        self.RULE_COMMANDS.append(command)

    def append_to_chain(self, chain_name, target, protocol=None, source=None, destination=None, sport=None, dport=None,
                        to_addr=None, to_port=None, in_iface=None, out_iface=None, negate_src=False, negate_dst=False, time_profile=None):

        raw_rule = self.RawRule()
        raw_rule.join(self.IPTABLES)

        # Add table name
        raw_rule.join("-t nat")

        # Add chain name
        raw_rule.join("-A {}".format(chain_name))

        # Add interface in
        if chain_name == ipt_chain.PREROUTING and in_iface:
            raw_rule.join("-i {}".format(in_iface))
        if chain_name == ipt_chain.POSTROUTING and out_iface:
            raw_rule.join("-o {}".format(out_iface))

        # Add protocol
        if protocol and protocol != '*':
            raw_rule.join("-p {} -m {}".format(protocol, protocol))

        # Add source if exist
        if source and source != '*':
            if negate_src:
                raw_rule.join("! -s {}".format(source))
            else:
                raw_rule.join("-s {}".format(source))

        # Add source port if exist
        if sport and sport != '*':
            raw_rule.join("--sport {}".format(sport))

        # Add source if exist
        if destination and destination != '*':
            if negate_dst:
                raw_rule.join("! -d {}".format(destination))
            else:
                raw_rule.join("-d {}".format(destination))

        # Add dest port if exist
        if dport and dport != '*':
            raw_rule.join("--dport {}".format(dport))

        if time_profile:
            raw_rule.join("-m time --kerneltz")

            datestart = time_profile.start_date.date().strftime('%Y-%m-%d') if time_profile.start_date else None
            if datestart:
                raw_rule.join("--datestart {}".format(datestart))

            datestop = time_profile.end_date.date().strftime('%Y-%m-%d') if time_profile.end_date else None
            if datestop:
                raw_rule.join("--datestop {}".format(datestop))

            timestart = time_profile.start_time.time().strftime('%H:%M') if time_profile.start_time else None
            if timestart:
                raw_rule.join("--timestart {}".format(timestart))

            timestop = time_profile.end_time.time().strftime('%H:%M') if time_profile.end_time else None
            if timestop:
                raw_rule.join("--timestop {}".format(timestop))

            weekdays = time_profile.day_numbers
            if weekdays:
                raw_rule.join("--weekdays {}".format(weekdays))

        # Add target
        raw_rule.join("-j {}".format(target))

        if target == "DNAT":
            match = "--to-destination {}".format(to_addr)
            if to_port and to_port != '*':
                match += ":{}".format(to_port)
            raw_rule.join(match)
        elif target == "SNAT":
            match = "--to-source {}".format(to_addr)
            if to_port and to_port != '*':
                match += ":{}".format(to_port)
            raw_rule.join(match)

        self.RULE_COMMANDS.append(raw_rule.RULE)

class IptableRoutingRule(object):
    """This class returns the basic functions of iptables as a string"""
    def __init__(self):
        self.IPROUTE = "$IP route add"
        self.RULE_COMMANDS = []

    class RawRule(object):
        def __init__(self):
            self.RULE = ""

        def join(self, param):
            self.RULE += (param + " ")

    def append_raw_command(self, command):
        self.RULE_COMMANDS.append(command)

    def append_to_chain(self, destination="default", gateway=None, interface=None):
        raw_rule = self.RawRule()
        raw_rule.join(self.IPROUTE)

        raw_rule.join(destination)

        if gateway:
            raw_rule.join("via {}".format(gateway))

        if interface:
            raw_rule.join("dev {}".format(interface.name))

        self.RULE_COMMANDS.append(raw_rule.RULE)

def _build_v4_policy_rule(rule_data, fw_manegement_ips):
    # Prepare the vars for rule submition
    rule_chain_name = rule_data.name.replace(" ", "_")
    target = rule_data.action.upper()
    direction = rule_data.direction
    source = ','.join([addr.get_ipt_addr for addr in rule_data.src_addr])
    destination = ','.join([addr.get_ipt_addr for addr in rule_data.dst_addr])
    negate_src = rule_data.negate_src_addr
    negate_dst = rule_data.negate_dst_addr
    time_profile = rule_data.time_profile

    chains = []
    input_addresses = []
    output_addresses = []
    
    if not rule_data.interface:
        chains.append(ipt_chain.FORWARD)
    else:
        if direction.lower() == "both":
            chains.append(ipt_chain.FORWARD_IN)
            chains.append(ipt_chain.FORWARD_OUT)
        elif direction.lower == "inbound":
            chains.append(ipt_chain.FORWARD_IN)
        elif direction.lower == "outbound":
            chains.append(ipt_chain.FORWARD_OUT)

    for m_ip in fw_manegement_ips:
        for src in source.split(","):
            if src and is_network_contain_ip(m_ip.addr_value.split("/")[0], src):
                output_addresses.append(src)
                if direction.lower() == "outbound" or direction.lower() == "both":
                    chains.append(ipt_chain.OUTPUT) if ipt_chain.OUTPUT not in chains else chains
                if direction.lower() == "inbound" or direction.lower() == "both":
                    chains.append(ipt_chain.INPUT) if ipt_chain.INPUT not in chains else chains

    for m_ip in fw_manegement_ips:
        for dst in destination.split(","):
            if dst and is_network_contain_ip(m_ip.addr_value.split("/")[0], dst):
                input_addresses.append(dst)
                if direction.lower() == "outbound" or direction.lower() == "both":
                    chains.append(ipt_chain.OUTPUT) if ipt_chain.OUTPUT not in chains else chains
                if direction.lower() == "inbound" or direction.lower() == "both":
                    chains.append(ipt_chain.INPUT) if ipt_chain.INPUT not in chains else chains

    if not destination:
        chains.append(ipt_chain.INPUT) if ipt_chain.INPUT not in chains else chains
    if not source:
        chains.append(ipt_chain.OUTPUT) if ipt_chain.OUTPUT not in chains else chains
    
    ports = []
    sports = {}
    dports = {}
    for port in rule_data.port:
        rp = port.raw_ports
        if rp[0] and rp[1]:
            rp.append(port.protocol)
            ports.append(rp)
        elif rp[0]:
            if port.protocol not in sports.keys():
                sports[port.protocol] = []
            sports[port.protocol].append(rp[0])
        elif rp[1]:
            if port.protocol not in dports.keys():
                dports[port.protocol] = []
            dports[port.protocol].append(rp[1])
        else:
            ports.append(['', '', port.protocol])
    if sports:
        for key in sports:
            ports.append([','.join(sports[key]), '', key])
    if dports:
        for key in dports:
            ports.append(['', ','.join(dports[key]), key])

    new_rule = IptablePolicyRule()
    new_rule.create_chain(rule_chain_name)


    if rule_data.interface:
        for iface in rule_data.interface:
            interface = iface.name
            if ports:
                for port in ports:
                    print(">>>>>>>>", port)
                    protocol = port[2] # Pop the protocol of current port from list [src_ports, dst_ports, protocol]
                    if not port[0] and not port[1]:
                        port = None
                    for chain in chains:
                        src_addr = source
                        dst_addr = destination
                        if chain == ipt_chain.OUTPUT:
                            src_addr = ','.join(output_addresses)
                            direction = "outbound"
                        elif chain == ipt_chain.INPUT:
                            dst_addr = ','.join(input_addresses)
                            direction = "inbound"
                        new_rule.append_to_chain(chain_name=chain, target=rule_chain_name, direction=direction,
                            interface=interface, protocol=protocol, ports=port, source=src_addr, destination=dst_addr, state=ipt_state.NEW,
                            negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)
            else:
                for chain in chains:
                    src_addr = source
                    dst_addr = destination
                    if chain == ipt_chain.OUTPUT:
                        src_addr = ','.join(output_addresses)
                        direction = "outbound"
                    elif chain == ipt_chain.INPUT:
                        dst_addr = ','.join(input_addresses)
                        direction = "inbound"
                    new_rule.append_to_chain(chain_name=chain, target=rule_chain_name, direction=direction,
                    interface=interface, protocol=None, ports=None, source=src_addr, destination=dst_addr, state=ipt_state.NEW,
                    negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)

    elif ports:
        for port in ports:
            protocol = port.pop(2) # Pop the protocol of current port from list [src_ports, dst_ports, protocol]
            if not port[0] and not port[1]:
                port = None
            for chain in chains:
                src_addr = source
                dst_addr = destination
                if chain == ipt_chain.OUTPUT:
                    src_addr = ','.join(output_addresses)
                    direction = "outbound"
                elif chain == ipt_chain.INPUT:
                    dst_addr = ','.join(input_addresses)
                    direction = "inbound"
                new_rule.append_to_chain(chain_name=chain, target=rule_chain_name, direction=direction,
                    interface=None, protocol=protocol, ports=port, source=src_addr, destination=dst_addr, state=ipt_state.NEW,
                    negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)
    else:
        for chain in chains:
            src_addr = source
            dst_addr = destination
            if chain == ipt_chain.OUTPUT:
                src_addr = ','.join(output_addresses)
                direction = "outbound"
            elif chain == ipt_chain.INPUT:
                dst_addr = ','.join(input_addresses)
                direction = "inbound"
            new_rule.append_to_chain(chain_name=chain, target=rule_chain_name, direction=direction,
                    interface=None, protocol=None, ports=None, source=src_addr, destination=dst_addr, state=ipt_state.NEW,
                    negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)

    if rule_data.log:
        msg = rule_chain_name + " -- " + target
        new_rule.append_to_chain(chain_name=rule_chain_name, target=ipt_target.LOG, log_msg=msg)
    new_rule.append_to_chain(rule_chain_name, target)
    return new_rule.RULE_COMMANDS

def _build_v4_nat_rule(rule_data):
    # Prepare the vars for rule submition
    target = rule_data.action.upper()

    interface_in = rule_data.interface_in[0].name if rule_data.interface_in else None
    interface_out = rule_data.interface_out[0].name if rule_data.interface_out else None
    negate_src = rule_data.negate_original_src
    negate_dst = rule_data.negate_original_dst
    time_profile = rule_data.time_profile

    orj_sources = []
    for addr in rule_data.original_src:
        _addr_data = addr.get_ipt_addr.split(',')
        for data in _addr_data:
            orj_sources.append(data)

    orj_destinations = []
    for addr in rule_data.original_dst:
        _addr_data = addr.get_ipt_addr.split(',')
        for data in _addr_data:
            orj_destinations.append(data)

    orj_ports = []
    for port in rule_data.original_srv:
        rp = port.raw_ports
        rp.append(port.protocol)
        orj_ports.append(rp)

    trs_source = ','.join([addr.get_ipt_addr for addr in rule_data.translated_src])
    trs_destination = ','.join([addr.get_ipt_addr for addr in rule_data.translated_dst])
    if rule_data.translated_srv:
        trs_port = rule_data.translated_srv[0].raw_ports
        trs_port_proto = rule_data.translated_srv[0].protocol
    else:
        trs_port = None
        trs_port_proto = None

    new_rule = IptableNatRule()

    if trs_destination or (trs_port and trs_port[1]):
        # Make DNAT firts
        chain_name = ipt_chain.PREROUTING
        target = ipt_target.DNAT

        orj_ports = orj_ports or [['*','*','*']]
        orj_destinations = orj_destinations or ['*']
        orj_sources = orj_sources or ['*']

        for orj_port in orj_ports:
            for orj_destination in orj_destinations:
                for orj_source in orj_sources:
                    sport = orj_port[0]
                    dport = orj_port[1]
                    protocol = orj_port[2]
                    source = orj_source
                    destination = orj_destination
                    to_addr = trs_destination
                    to_port = trs_port[1] if trs_port else None

                    new_rule.append_to_chain(chain_name=chain_name, target=target, protocol=protocol, source=source, destination=destination,
                        sport=sport, dport=dport, to_addr=to_addr, to_port=to_port, in_iface=interface_in,
                        negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)

        if trs_source or (trs_port and trs_port[0]):
            # make SNAT after DNAT
            chain_name = ipt_chain.POSTROUTING
            target = ipt_target.SNAT

            for orj_source in orj_sources:
                dport = trs_port[1] if trs_port else None
                protocol = trs_port_proto
                source = orj_source
                destination = trs_destination
                to_addr = trs_source
                to_port = trs_port[0] if trs_port else None

                new_rule.append_to_chain(chain_name=chain_name, target=target, protocol=protocol, source=source, destination=destination,
                    dport=dport, to_addr=to_addr, to_port=to_port, out_iface=interface_out, negate_src=negate_src,
                    negate_dst=negate_dst, time_profile=time_profile)

    elif trs_source or (trs_port and trs_port[0]):
        # make directly SNAT
        chain_name = ipt_chain.POSTROUTING
        target = ipt_target.SNAT

        orj_ports = orj_ports or [['*','*', '*']]
        orj_destinations = orj_destinations or ['*']
        orj_sources = orj_sources or ['*']

        for orj_port in orj_ports:
            for orj_destination in orj_destinations:
                for orj_source in orj_sources:
                    sport = orj_port[0]
                    dport = orj_port[1]
                    protocol = orj_port[2]
                    source = orj_source
                    destination = orj_destination
                    to_addr = trs_source
                    to_port = trs_port[0] if trs_port else None

                    new_rule.append_to_chain(chain_name=chain_name, target=target, protocol=protocol, source=source, destination=destination,
                        sport=sport, dport=dport, to_addr=to_addr, to_port=to_port, out_iface=interface_out,
                        negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)
    else:
        chain_names = [ipt_chain.POSTROUTING, ipt_chain.PREROUTING]
        target = ipt_target.ACCEPT

        orj_ports = orj_ports or [['*','*', '*']]
        orj_destinations = orj_destinations or ['*']
        orj_sources = orj_sources or ['*']

        for chain_name in chain_names:
            for orj_port in orj_ports:
                for orj_destination in orj_destinations:
                    for orj_source in orj_sources:
                        sport = orj_port[0]
                        dport = orj_port[1]
                        protocol = orj_port[2]
                        source = orj_source
                        destination = orj_destination
                        to_addr = trs_source
                        to_port = trs_port[0] if trs_port else None

                        new_rule.append_to_chain(chain_name=chain_name, target=target, protocol=protocol, source=source, destination=destination,
                            sport=sport, dport=dport, to_addr=to_addr, to_port=to_port, in_iface=interface_in, out_iface=interface_out,
                            negate_src=negate_src, negate_dst=negate_dst, time_profile=time_profile)

    return new_rule.RULE_COMMANDS

def _build_v4_routing_rule(rule_data):
    new_rule = IptableRoutingRule()

    destinations = []
    for addr in rule_data.destination:
        _addr_data = addr.get_ipt_addr.split(',')
        for data in _addr_data:
            destinations.append(data)

    if not destinations:
        destinations.append("default")

    gateway = rule_data.gateway[0]
    interface = rule_data.interface[0] if rule_data.interface else None

    for destination in destinations:
        new_rule.append_to_chain(destination=destination, gateway=gateway.addr_value.split('/')[0], interface=interface)

    return new_rule.RULE_COMMANDS

def apply_firewall_commits(fw_ids):
    Firewall = models.Firewall

    if "all" in fw_ids:
        fw_ids = [fw.id for fw in Firewall.query.all()]

    status = True
    for fw_id in fw_ids:
        ret = build_firewall_script(fw_id=fw_id)
        if not ret:
            status = False
    return status

def build_firewall_script(fw_id = None, fw_name = None):
    Firewall = models.Firewall

    if fw_id:
        fw = Firewall.query.filter(Firewall.id == fw_id).first()
    elif fw_name:
        fw = Firewall.query.filter(Firewall.name == fw_name).first()

    if not fw:
        log.error("Error was occured while building firewall {}".format((fw_name or fw_id or "Undefined"), traceback.format_exc()))
        return False

    try:
        if not fw.manegement_iface:
            log.error("Error was occured while building firewall {}: Fw does not have management iface".format(fw.name))
            return False

        built_v4_policy_rules = []
        for rule_assoc in fw.policy_rules:
            if rule_assoc.rule.active:
                rule = {}
                rule['commands'] = _build_v4_policy_rule(rule_assoc.rule, fw.all_ips)
                rule['name'] = rule_assoc.rule.name.replace(" ", "_")
                rule['comment'] = rule_assoc.rule.comment
                built_v4_policy_rules.append(rule)

        built_v4_nat_rules = []
        for rule_assoc in fw.nat_rules:
            if rule_assoc.rule.active:
                rule = {}
                rule['commands'] = _build_v4_nat_rule(rule_assoc.rule)
                rule['name'] = rule_assoc.rule.name.replace(" ", "_")
                rule['comment'] = rule_assoc.rule.comment
                built_v4_nat_rules.append(rule)

        built_v4_routing_rules = []
        for rule_assoc in fw.routing_rules:
            if rule_assoc.rule.active:
                rule = {}
                rule['commands'] = _build_v4_routing_rule(rule_assoc.rule)
                rule['name'] = rule_assoc.rule.name.replace(" ", "_")
                rule['comment'] = rule_assoc.rule.comment
                built_v4_routing_rules.append(rule)

        payload = {}
        payload['v4_policy_rules'] = built_v4_policy_rules
        payload['v4_nat_rules'] = built_v4_nat_rules
        payload['v4_routing_rules'] = built_v4_routing_rules
        payload['current_user'] = current_user.username + " <{}>".format(current_user.email)
        payload['current_time'] = datetime.datetime.now()
        payload['iptables_path'] = app.config['IPTABLES_PATH']
        payload['ip6tables_path'] = app.config['IP6TABLES_PATH']
        payload['mys_ip_addr'] = app.config['MYS_IP_ADDR']
        payload['fw_manegement_ips'] = fw.manegement_ip

        rendered_template = render_template("scripts/fw_script.sh", vars=payload)
        output_dir = app.config['WORKDIR']
        files_dir = os.path.join(output_dir, "files")
        output_file = os.path.join(output_dir, fw.name + ".fw")
        if not os.path.isdir(files_dir):
            os.makedirs(files_dir)
        if os.path.isfile(output_file):
            os.remove(output_file)
        with open(output_file, "wb") as f:
            f.write(rendered_template.encode('utf-8'))
        return True
    except Exception as e:
        log.error("Error was occured while building firewall {}: {}".format(fw.name, traceback.format_exc()))
        return False

def is_valid_ip(address):
    try:
        socket.inet_aton(address)
        return True
    except:
        return False


def is_network_contain_ip(_ip, _network):
    network = netaddr.IPNetwork(_network)
    ip = netaddr.IPAddress(_ip)

    return (ip in network.iter_hosts())
