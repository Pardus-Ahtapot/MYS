from flask import Flask
from app.apps.main.views import main_views as views
from app.apps.main.views import v4_rules, v6_rules, authorization
from app import log

def set_routes(app):
	log.debug("Setting up url routes...")
    
    # General
	app.add_url_rule('/', view_func=views.index)
	app.add_url_rule('/add_filter', view_func=views.add_filter)
	app.add_url_rule('/remove_filters', view_func=views.remove_filters)
	app.add_url_rule('/select_fw', view_func=views.select_fw, methods=['POST'])
	app.add_url_rule('/search_fw', view_func=views.search_firewall, methods=['POST'])
	app.add_url_rule('/build_single_rule', view_func=views.build_single_rule, methods=['POST'])
	app.add_url_rule('/apply_commits', view_func=views.apply_commits, methods=['POST'])
	app.add_url_rule('/revert_commits', view_func=views.revert_commits)
	
	# Firewall Urls
	app.add_url_rule('/firewall_options/<int:fw_id>', view_func=views.firewall_options)
	app.add_url_rule('/firewalls/get-firewall', view_func=views.get_firewall)
	app.add_url_rule('/add_new_firewall', view_func=views.add_new_firewall, methods=['POST'])
	app.add_url_rule('/delete_firewall/<int:firewall_id>', view_func=views.delete_firewall, methods=['DELETE'])
	app.add_url_rule('/update_firewall/<int:firewall_id>', view_func=views.update_firewall, methods=['PUT', 'POST'])

	# IPv4 Policy Urls
	app.add_url_rule('/ipv4_rules', view_func=v4_rules.ipv4_rules)
	app.add_url_rule('/ipv4_rules/get-rule', view_func=v4_rules.get_ipv4_rule)
	app.add_url_rule('/add_ipv4_policy_rule', view_func=v4_rules.add_ipv4_policy_rule, methods=['POST'])
	app.add_url_rule('/delete_ipv4_policy_rule/<int:rule_id>', view_func=v4_rules.delete_ipv4_policy_rule, methods=['DELETE'])
	app.add_url_rule('/update_ipv4_policy_rule/<int:rule_id>', view_func=v4_rules.update_ipv4_policy_rule, methods=['PUT', 'POST'])
	app.add_url_rule('/change_ipv4_policy_rule_rank', view_func=v4_rules.change_ipv4_policy_rule_rank, methods=['PUT', 'POST'])

	# IPv4 Nat Urls
	app.add_url_rule('/ipv4_nat_rules', view_func=v4_rules.ipv4_nat_rules)
	app.add_url_rule('/add_ipv4_nat_rule', view_func=v4_rules.add_ipv4_nat_rule, methods=['POST'])
	app.add_url_rule('/delete_ipv4_nat_rule/<int:rule_id>', view_func=v4_rules.delete_ipv4_nat_rule, methods=['DELETE'])
	app.add_url_rule('/update_ipv4_nat_rule/<int:rule_id>', view_func=v4_rules.update_ipv4_nat_rule, methods=['PUT', 'POST'])
	app.add_url_rule('/change_ipv4_nat_rule_rank', view_func=v4_rules.change_ipv4_nat_rule_rank, methods=['PUT', 'POST'])
	
	# IPv4 Routing Urls
	app.add_url_rule('/ipv4_routing_rules', view_func=v4_rules.ipv4_routing_rules)	
	app.add_url_rule('/add_ipv4_routing_rule', view_func=v4_rules.add_ipv4_routing_rule, methods=['POST'])
	app.add_url_rule('/delete_ipv4_routing_rule/<int:rule_id>', view_func=v4_rules.delete_ipv4_routing_rule, methods=['DELETE'])
	app.add_url_rule('/update_ipv4_routing_rule/<int:rule_id>', view_func=v4_rules.update_ipv4_routing_rule, methods=['PUT', 'POST'])
	app.add_url_rule('/change_ipv4_routing_rule_rank', view_func=v4_rules.change_ipv4_routing_rule_rank, methods=['PUT', 'POST'])

	# IPv6 Urls
	app.add_url_rule('/ipv6_rules', view_func=v6_rules.ipv6_rules)
	app.add_url_rule('/ipv6_nat_rules', view_func=v6_rules.ipv6_nat_rules)
	app.add_url_rule('/ipv6_routing_rules', view_func=v6_rules.ipv6_routing_rules)

	# User Urls
	app.add_url_rule('/user-validate', view_func=authorization.user_validation)
	app.add_url_rule('/user-set-passwd-expire', view_func=authorization.user_set_passwd_expire)
	app.add_url_rule('/users', view_func=authorization.users)
	app.add_url_rule('/users/get-user', view_func=authorization.get_user)
	app.add_url_rule('/add_new_user', view_func=authorization.add_new_user, methods=['POST'])
	app.add_url_rule('/delete_user/<int:user_id>', view_func=authorization.delete_user, methods=['DELETE'])
	app.add_url_rule('/update_user/<int:user_id>', view_func=authorization.update_user, methods=['PUT', 'POST'])
	# app.add_url_rule('/address_json_search', view_func=views.address_full_text_search, methods=['POST'])

	# Role Urls
	app.add_url_rule('/roles', view_func=authorization.roles)
	app.add_url_rule('/roles/get-role', view_func=authorization.get_role)
	app.add_url_rule('/add_new_role', view_func=authorization.add_new_role, methods=['POST'])
	app.add_url_rule('/delete_role/<int:role_id>', view_func=authorization.delete_role, methods=['DELETE'])
	app.add_url_rule('/update_role/<int:role_id>', view_func=authorization.update_role, methods=['PUT', 'POST'])

	# Interface urls 
	app.add_url_rule('/add_new_interface/<int:fw_id>', view_func=views.add_new_interface, methods=['POST'])
	app.add_url_rule('/interfaces/get-interface', view_func=views.get_interface)
	app.add_url_rule('/delete_iface/<int:iface_id>', view_func=views.delete_interface, methods=['DELETE'])
	app.add_url_rule('/update_interface/<int:iface_id>', view_func=views.update_interface, methods=['PUT', 'POST'])

	# Address Urls
	app.add_url_rule('/addresses', view_func=views.addresses)
	app.add_url_rule('/addresses/get-address', view_func=views.get_address)
	app.add_url_rule('/add_new_address', view_func=views.add_new_address, methods=['POST'])
	app.add_url_rule('/delete_address/<int:addr_id>', view_func=views.delete_address, methods=['DELETE'])
	app.add_url_rule('/update_address/<int:addr_id>', view_func=views.update_address, methods=['PUT', 'POST'])
	app.add_url_rule('/address_json_search', view_func=views.address_full_text_search, methods=['POST'])

	# Service Urls
	app.add_url_rule('/services', view_func=views.services)
	app.add_url_rule('/services/get-service', view_func=views.get_service)
	app.add_url_rule('/add_new_service', view_func=views.add_new_service, methods=['POST'])
	app.add_url_rule('/delete_service/<int:service_id>', view_func=views.delete_service, methods=['DELETE'])
	app.add_url_rule('/update_service/<int:service_id>', view_func=views.update_service, methods=['PUT', 'POST'])
	app.add_url_rule('/service_json_search', view_func=views.service_full_text_search, methods=['POST'])

	# Time Profile Urls
	app.add_url_rule('/time_profiles', view_func=views.time_profiles)
	app.add_url_rule('/time_profiles/get-time-profile', view_func=views.get_time_profile)
	app.add_url_rule('/add_new_time_profile', view_func=views.add_new_time_profile, methods=['POST'])
	app.add_url_rule('/delete_time_profile/<int:time_profile_id>', view_func=views.delete_time_profile, methods=['DELETE'])
	app.add_url_rule('/update_time_profile/<int:time_profile_id>', view_func=views.update_time_profile, methods=['PUT', 'POST'])
