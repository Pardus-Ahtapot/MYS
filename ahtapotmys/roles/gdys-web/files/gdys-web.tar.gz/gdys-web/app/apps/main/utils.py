from app import db, log
from app.apps.main import models
from app.apps.main import iptables
from app.apps.main import git
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm import aliased, joinedload
from sqlalchemy import inspect, or_, and_, func, alias
from flask_user import current_user
from flask import session

import json
import uuid 
import traceback

def refresh_session_object(obj):
    ACTIVE_FW = get_active_firewall()
    Firewall = models.Firewall

    ACTIVE_FW = Firewall.query.filter(Firewall.name == ACTIVE_FW.name).first()

def change_rule_rank(rule_rank, new_rank):
    ACTIVE_FW = get_active_firewall()

    db.session.autoflush = False
    rule_assoc = ACTIVE_FW.policy_rules.pop(rule_rank)
    new_rule_assoc = FwPolicyRules(rule=rule_assoc.rule)
    fw.policy_rules.insert(new_rank, new_rule_assoc)
    db.session.autoflush = True
    db.session.commit()

def clear_filter_params():
    session['filter_field'] = ""
    session['filter_input'] = ""

def get_filter_params():
    try:
        filter_field = session['filter_field']
        filter_input = session['filter_input']
        return filter_field, filter_input
    except Exception as e:
        filter_field = ""
        filter_input = ""
        return filter_field, filter_input

def select_fw_by_attr(fw_name = None, fw_id = None):
    Firewall = models.Firewall
    try:
        if fw_name:
            ACTIVE_FW = Firewall.query.filter(Firewall.name==fw_name).first()
        elif fw_id:
            ACTIVE_FW = Firewall.query.filter(Firewall.id==fw_id).first()

        session['ACTIVE_FW'] = ACTIVE_FW.id
    except Exception as e:
        raise e

def get_active_firewall():
    Firewall = models.Firewall
    try:
        ACTIVE_FW_ID = session['ACTIVE_FW']
        return Firewall.query.filter(Firewall.id == ACTIVE_FW_ID).first()
    except Exception as e:
        return None

def get_default_payload():
    ACTIVE_FW = get_active_firewall()
    Firewall = models.Firewall
    payload = {}

    if ACTIVE_FW is None:
        
        payload['active_fw'] =  None
        payload['fw_list'] = get_recently_used_firewalls()
        payload['all_fws'] = Firewall.query.all()
        payload['unapplied_commits'] = get_unapplied_commits()
        return payload 
        # select_fw_by_attr(fw_id = 1)
        # ACTIVE_FW = get_active_firewall()

    recent_fw_list = get_recently_used_firewalls()
    recent_fw_list.append(ACTIVE_FW)

    payload['unapplied_commits'] = get_unapplied_commits()
    payload['active_fw'] =  ACTIVE_FW.name
    payload['fw_list'] = recent_fw_list
    payload['all_fws'] = Firewall.query.all()
    return payload  

def get_recently_used_firewalls(count = 10):
    Firewall = models.Firewall
    FwPolicyRules = models.FwPolicyRules

    user_accessable_fws = current_user.get_fw_ids()

    recent_fw = Firewall.query.filter(Firewall.id.in_(user_accessable_fws)).join(FwPolicyRules).distinct().order_by(FwPolicyRules.updated_at.desc())
    recent_fw = list(recent_fw)[:count]

    recent_added_fw = Firewall.query.filter(Firewall.id.in_(user_accessable_fws)).order_by(Firewall.created_at.desc()) 
    fw_list = list(recent_added_fw)[:count] 

    return list(set(recent_fw + fw_list)) 

def get_recently_used_addresses(count = 10, addr_type = None):
    PolicyRule = models.PolicyRule 
    Address = models.Address 
    
    if not addr_type:
        recent_added_addr = Address.query.order_by(Address.created_at.desc()) 
    else:
        recent_added_addr = Address.query.filter(Address.addr_type == addr_type).order_by(Address.created_at.desc()) 
    addr_list = list(recent_added_addr)[:count] 
    
    return addr_list

def get_recently_used_services(count = 10): 
    PolicyRule = models.PolicyRule 
    Service = models.Service 
    
    recent_added_serv = Service.query.order_by(Service.created_at.desc()) 
    serv_list = list(recent_added_serv)[:count] 
    
    return serv_list  

# *-* Additional functions *-*

def get_unapplied_commits():
    Commit = models.Commit
    commits = Commit.query.filter(Commit.is_applied == False).order_by(Commit.section) 
    commits = commits if commits.count() > 0 else False

    return commits

def commit_changes(username, section, operation, firewall=None):
    Commit = models.Commit

    new_commit = Commit(uuid=uuid.uuid1().hex, commited_by=username, section=section, operation=operation, firewall=firewall)
    db.session.add(new_commit)
    db.session.commit()

def mark_commits_as_applied():
    Commit = models.Commit

    unapplied_commits = get_unapplied_commits()

    for commit in unapplied_commits:
        commit.is_applied = True
        commit.applied_by = (current_user.username + ' <' + current_user.email + '>')
    db.session.commit()

def apply_commits_and_push(git_message, fw_ids):
    try:
        # Build changed firewall scripts
        success = iptables.apply_firewall_commits(fw_ids)
        if not success:
            return False
        
        db.session.commit()

        success = git.create_new_git_commit(git_message)
        if not success:
            return False
        success = git.push_to_remote()
        if not success:
            return False
        mark_commits_as_applied()
        return True
    except Exception as e:
        log.error(traceback.format_exc())
        return False

def discard_changes():
    try:
        success = git.reset_repo_to_remote()
        if success:
            db.session.flush()
        return success
    except Exception as e:
        log.error(traceback.format_exc())
        return False

def build_single_policy_rule(rule_id):
    FwPolicyRules = models.FwPolicyRules
    
    try:
        fw = get_active_firewall()
        rule_data = FwPolicyRules.query.filter(FwPolicyRules.id == rule_id).first()
        ret = iptables._build_v4_policy_rule(rule_data.rule, fw.all_ips)
        return ret
    except Exception as e:
        log.error(traceback.format_exc())
        return False

def build_single_nat_rule(rule_id):
    FwNatRules = models.FwNatRules
    try:
        rule_data = FwNatRules.query.filter(FwNatRules.id == rule_id).first()
        ret = iptables._build_v4_nat_rule(rule_data.rule)
        return ret
    except Exception as e:
        log.error(traceback.format_exc())
        return False

def build_single_routing_rule(rule_id):
    FwRoutingRules = models.FwRoutingRules
    try:
        rule_data = FwRoutingRules.query.filter(FwRoutingRules.id == rule_id).first()
        ret = iptables._build_v4_routing_rule(rule_data.rule)
        return ret
    except Exception as e:
        log.error(traceback.format_exc())
        return False          

def is_firewall_contain_addr(fw, addr):
    FwPolicyRules = models.FwPolicyRules
    FwNatRules = models.FwNatRules
    FwRoutingRules = models.FwRoutingRules
    PolicyRule = models.PolicyRule
    NatRule = models.NatRule
    RoutingRule = models.RoutingRule
    Address = models.Address    

    def policy_rules():
        src_addr = aliased(Address)
        dst_addr = aliased(Address)
        return FwPolicyRules.query.join(PolicyRule).outerjoin(src_addr, PolicyRule.src_addr) \
            .outerjoin(dst_addr, PolicyRule.dst_addr) \
            .filter(FwPolicyRules.firewall==fw) \
            .filter(PolicyRule.rule_type == "ipv4") \
            .filter(or_(dst_addr.id == addr.id, src_addr.id == addr.id)).first()

    def nat_rules():
        original_src = aliased(Address)
        original_dst = aliased(Address)
        translated_src = aliased(Address)
        translated_dst = aliased(Address)
        
        return FwNatRules.query.join(NatRule).outerjoin(original_src, NatRule.original_src) \
            .outerjoin(original_dst, NatRule.original_dst) \
            .outerjoin(translated_src, NatRule.translated_src) \
            .outerjoin(translated_dst, NatRule.translated_dst) \
            .filter(FwNatRules.firewall==fw).filter(NatRule.rule_type == "ipv4") \
            .filter(or_(original_src.id == addr.id, original_dst.id == addr.id) | \
                    or_(translated_src.id == addr.id, translated_dst.id == addr.id)).first()

    def routing_rules():
        destination = aliased(Address)
        gateway = aliased(Address)
        return FwRoutingRules.query.join(RoutingRule).outerjoin(destination, RoutingRule.destination) \
            .outerjoin(gateway, RoutingRule.gateway) \
            .filter(FwRoutingRules.firewall==fw) \
            .filter(RoutingRule.rule_type == "ipv4") \
            .filter(or_(destination.id == addr.id, gateway.id == addr.id)).first()

    if policy_rules() or nat_rules() or routing_rules():
        return True
    else:
        return False

def is_firewall_contain_service(fw, service):
    FwPolicyRules = models.FwPolicyRules
    FwNatRules = models.FwNatRules
    PolicyRule = models.PolicyRule
    NatRule = models.NatRule
    Service = models.Service
    
    rule_service = aliased(Service)
    policy_rules = FwPolicyRules.query.join(PolicyRule).outerjoin(rule_service, PolicyRule.port) \
        .filter(FwPolicyRules.firewall==fw) \
        .filter(PolicyRule.rule_type == "ipv4") \
        .filter(rule_service.id == service.id).first()


    original_srv = aliased(Service)
    translated_srv = aliased(Service)

    nat_rules = FwNatRules.query.join(NatRule).outerjoin(original_srv, NatRule.original_srv) \
        .outerjoin(translated_srv, NatRule.translated_srv) \
        .filter(FwNatRules.firewall==fw).filter(NatRule.rule_type == "ipv4") \
        .filter(or_(original_srv.id == service.id, translated_srv.id == service.id)).first()

    if policy_rules or nat_rules:
        return True
    else:
        return False

# This class using for convert sqlalchemy result to the json encoding
class AlchemyEncoder(json.JSONEncoder):

    def default(self, obj):
        if isinstance(obj.__class__, DeclarativeMeta):
            # an SQLAlchemy class
            fields = {}
            for field in [x for x in dir(obj) if not x.startswith('_') and x != 'metadata']:
                data = obj.__getattribute__(field)
                try:
                    json.dumps(data) # this will fail on non-encodable values, like other classes
                    fields[field] = data
                except TypeError:
                    fields[field] = None
            # a json-encodable dict
            return fields

        return json.JSONEncoder.default(self, obj)