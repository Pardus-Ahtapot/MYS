from flask import render_template, flash, redirect, url_for, request, jsonify, session, current_app
from app.apps.main import models as main_models
from flask_user import current_user, login_required, roles_required, UserManager, UserMixin
from sqlalchemy import inspect, or_, and_, func, alias
from sqlalchemy_filters import apply_filters
from sqlalchemy.orm import aliased, joinedload
from app import ACTIVE_FW, db, log
from app.apps.main.utils import *
from app.apps.main.permissions import permission_required
from dateutil.relativedelta import relativedelta

import traceback
import ipaddress, json
import datetime

@login_required
def index():
    """the function returns the index page when the user is logged in"""

    firewall, filter_field, filter_input = firewalls()

    extra_vars = get_default_payload()
    extra_vars['page_name'] = 'index'
    extra_vars['firewalls'] = firewall
    extra_vars['filter_field'] = filter_field
    extra_vars['filter_input'] = filter_input
    return render_template('index.html', vars=extra_vars)

@login_required
def firewalls():
    Firewall = main_models.Firewall

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "/" != referrer[-1]:
        if '?' in referrer:
            ref = referrer.split("?")
            if '/' != ref[0][-1]:
                clear_filter_params()
        else:
            clear_filter_params()

    filters = {
        "name": Firewall.name,
    }
    filter_field, filter_input = get_filter_params()

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=10))
    user_accessable_fws = current_user.get_fw_ids()

    try:
        if filter_field and filter_input:
            firewalls = Firewall.query.filter(Firewall.id.in_(user_accessable_fws)) \
                            .filter(filters[str(filter_field)].like("%{}%".format(str(filter_input)))) \
                            .order_by(Firewall.name) \
                            .paginate(per_page=per_page, page=page, error_out=True)
        else:
            firewalls = Firewall.query.filter(Firewall.id.in_(user_accessable_fws)).order_by(Firewall.updated_at.desc()) \
                            .paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        clear_filter_params()
        firewalls = Firewall.query.filter(Firewall.id.in_(user_accessable_fws)).order_by(Firewall.updated_at.desc()) \
                        .paginate(per_page=per_page, page=page, error_out=True)
    return firewalls, filter_field, filter_input

@login_required
def firewall_options(fw_id: int, err=False, saved=False, msg=""):
    Firewall = main_models.Firewall

    if not current_user.can_access_fw(fw_id):
        return current_app.user_manager.unauthorized_view()

    extra_vars = get_default_payload()
    extra_vars['page_name'] = 'Firewall Ayarlari'
    extra_vars['firewall'] = Firewall.query.filter(Firewall.id == fw_id).first()
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('firewall_options.html', vars=extra_vars)

@login_required
def select_fw():
    ACTIVE_FW = get_active_firewall()
    """the function returns the index page when the user is logged in"""
    selected_fw_id = request.form.get("fw_id")
    if not current_user.can_access_fw(int(selected_fw_id)):
        return jsonify(success=False)
    select_fw_by_attr(fw_id = selected_fw_id)
    resp = jsonify(success=True)
    return resp

@login_required
def add_filter():
    session['filter_field'] = request.args.get('filter_field', default="")
    session['filter_input'] = request.args.get('filter_input', default="")
    resp = jsonify(success=True)
    return resp

@login_required
def remove_filters():
    clear_filter_params()
    resp = jsonify(success=True)
    return resp

# *-* Generic type stuff views *-*

@login_required
@permission_required(['view_address', 'super_user'])
def addresses(saved=False, err=False, msg=""):
    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "addresses" not in referrer:
        clear_filter_params()
    Address = main_models.Address
    extra_vars = get_default_payload()

    filters = {
        "name": Address.name,
        "addr_value": Address.addr_value,
        "addr_type": Address.addr_type,
    }

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    try:
        filter_field, filter_input = get_filter_params()
        """the function returns the index page when the user is logged in"""
        if filter_field and filter_input:
            addresses = Address.query.filter(filters[filter_field].like("%{}%".format(filter_input))).order_by(Address.id).paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            addresses = Address.query.order_by(Address.id).paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        addresses = Address.query.order_by(Address.id).paginate(per_page=per_page, page=page, error_out=True)
        clear_filter_params()

    extra_vars['page_name'] = 'addresses'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['addresses'] = addresses
    extra_vars['error'] = err
    extra_vars['msg'] = msg
    extra_vars['saved'] = saved
    return render_template('addresses.html', vars=extra_vars, ipaddress=ipaddress)

@login_required
@permission_required(['view_service', 'super_user'])
def services(saved=False, err=False, msg=""):
    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "services" not in referrer:
        clear_filter_params()
    extra_vars = get_default_payload()
    Service = main_models.Service
    filters = {
        "name": Service.name,
        "category": Service.category,
        "protocol": Service.protocol,
        "src_start_port": Service.src_start_port,
        "src_end_port": Service.src_end_port,
        "dst_start_port": Service.dst_start_port,
        "dst_end_port": Service.dst_end_port
    }

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    try:
        filter_field, filter_input = get_filter_params()
        """the function returns the index page when the user is logged in"""
        if filter_field and filter_input:
            services = Service.query.filter(filters[filter_field].like("%{}%".format(filter_input))).order_by(Service.id).paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            services = Service.query.order_by(Service.id).paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        clear_filter_params()
        services = Service.query.order_by(Service.id).paginate(per_page=per_page, page=page, error_out=True)
    extra_vars['page_name'] = 'services'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['services'] = services
    extra_vars['error'] = err
    extra_vars['msg'] = msg
    extra_vars['saved'] = saved
    return render_template('services.html', vars=extra_vars)

@login_required
@permission_required(['view_timeprofile', 'super_user'])
def time_profiles(err=False, saved=False, msg=""):
    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "time_profiles" not in referrer:
        clear_filter_params()
    extra_vars = get_default_payload()
    TimeProfile = main_models.TimeProfile
    filters = {
        "name": TimeProfile.name,
    }

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    if filter_field and filter_input:
        time_profiles = TimeProfile.query.filter(filters[filter_field].like("%{}%".format(filter_input))).order_by(TimeProfile.id).paginate(per_page=per_page, page=page, error_out=True)
        extra_vars['filter_field'] = filter_field
        extra_vars['filter_input'] = filter_input
    else:
        time_profiles = TimeProfile.query.order_by(TimeProfile.id).paginate(per_page=per_page, page=page, error_out=True)
    extra_vars['page_name'] = 'time_profiles'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['time_profiles'] = time_profiles
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('time_profiles.html', vars=extra_vars)

@login_required
@permission_required(['edit_timeprofile', 'super_user'])
def add_new_time_profile():
    TimeProfile = main_models.TimeProfile

    try:
        profile_name = request.form.get("time_profile_name")
        str_start_date = request.form.get("start_date", default=None)
        start_date = None
        if str_start_date:
            start_date = datetime.datetime.strptime(str_start_date, "%Y-%m-%d")

        str_start_time = request.form.get("start_time", default=None)
        start_time = datetime.datetime.strptime(str_start_time, "%H:%M")

        str_end_date = request.form.get("end_date", default=None)
        end_date = None
        if str_end_date:
            end_date = datetime.datetime.strptime(str_end_date, "%Y-%m-%d")

        str_end_time = request.form.get("end_time", default=None)
        end_time = datetime.datetime.strptime(str_end_time, "%H:%M")

        days = ','.join(request.form.getlist("days"))

        if start_time >= end_time:
            return time_profiles(err=True, msg="Başlangıç zamanı bitiş zamanından büyük veya eşit olamaz!")

        new_profile = TimeProfile(name=profile_name, days=days, start_date=start_date, start_time=start_time, end_date=end_date, end_time=end_time)
        db.session.add(new_profile)
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
            section=('time_profiles' + ' <ProfileName: ' + profile_name + '>'), operation='add')
        return time_profiles(saved=True, msg="Zaman profili eklendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return time_profiles(err=True, msg="Zaman profili eklenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['edit_address', 'super_user'])
def update_time_profile(time_profile_id: int):
    TimeProfile = main_models.TimeProfile

    try:
        profile_name = request.form.get("time_profile_name")
        str_start_date = request.form.get("start_date", default=None)
        start_date = None
        if str_start_date:
            start_date = datetime.datetime.strptime(str_start_date, "%Y-%m-%d")

        str_start_time = request.form.get("start_time", default=None)
        start_time = datetime.datetime.strptime(str_start_time, "%H:%M")

        str_end_date = request.form.get("end_date", default=None)
        end_date = None
        if str_end_date:
            end_date = datetime.datetime.strptime(str_end_date, "%Y-%m-%d")

        str_end_time = request.form.get("end_time", default=None)
        end_time = datetime.datetime.strptime(str_end_time, "%H:%M")

        days = ','.join(request.form.getlist("days"))

        if start_time >= end_time:
            return time_profiles(err=True, msg="Başlangıç zamanı bitiş zamanından büyük veya eşit olamaz!")

        time_profile = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        time_profile.name = profile_name
        time_profile.days = days
        time_profile.start_date = start_date
        time_profile.start_time = start_time
        time_profile.end_date = end_date
        time_profile.end_time = end_time
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('time_profiles' + ' <ProfileName: ' + profile_name + '>'), operation='update')
        return time_profiles(saved=True, msg="Zaman profili guncellendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return time_profiles(err=True, msg="Zaman profili guncellenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['edit_address', 'super_user'])
def add_new_address():
    Address = main_models.Address

    try:
        addr_name = request.form.get("addr_name")
        addr_type = request.form.get("addr_type")

        if addr_type == "netmask":
            addr_value = request.form.get("addr") + "/" + request.form.get("netmask")
        elif addr_type == "range":
            addr_value = request.form.get("start_addr") + "-" + request.form.get("end_addr")
        elif addr_type == "geo":
            addr_value = request.form.get("geo")
        elif addr_type == "fqdn":
            addr_value = request.form.get("fqdn")

        new_addr = Address(name=addr_name, addr_type=addr_type, addr_value=addr_value)

        iface_id = request.form.get("iface_id", default="")
        if iface_id:
            Interface = main_models.Interface
            iface = Interface.query.filter(Interface.id == iface_id).first()
            iface.addr.append(new_addr)
            db.session.commit()
            commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('interface_addresses <IfaceName,AddrName: {},{}>'.format(iface.name, addr_name)), operation='add')
            flash('Adres başarıyla eklendi!', 'success')
            return redirect(request.referrer, code=302)
        else:
            db.session.add(new_addr)
            db.session.commit()
            commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('addresses' + ' <AddrName: ' + addr_name + '>'), operation='add')
            return addresses(saved=True, msg="Adres başarıyla eklendi.")
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return addresses(err=True, msg="Adres eklenirken sunucu hatasi gerceklesti.")

@login_required
@permission_required(['edit_address', 'super_user'])
def update_address(addr_id: int):
    Address = main_models.Address

    try:
        addr_name = request.form.get("addr_name")
        addr_type = request.form.get("addr_type")
        if addr_type == "netmask":
            addr_value = request.form.get("addr") + "/" + request.form.get("netmask")
        elif addr_type == "range":
            addr_value = request.form.get("start_addr") + "-" + request.form.get("end_addr")
        elif addr_type == "geo":
            addr_value = request.form.get("geo")
        elif addr_type == "fqdn":
            addr_value = request.form.get("fqdn")

        addr = Address.query.filter(Address.id == addr_id).first()
        addr.name=addr_name
        addr.addr_type=addr_type
        addr.addr_value=addr_value

        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('addresses' + ' <AddrName: ' + addr_name + '>'), operation='update')
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return addresses(err=True, msg="Adres guncellenirken sunucu hatasi gerceklesti.")

    if "firewall_options" in request.referrer:
        flash('Adres başarıyla guncellendi!', 'success')
        return redirect(request.referrer, code=302)
    return addresses(saved=True, msg="Adres başarıyla guncellendi.")

@login_required
@permission_required(['edit_service', 'super_user'])
def add_new_service():
    Service = main_models.Service

    try:
        service_name = request.form.get("service_name", default=None)
        service_category = request.form.get("category", default=None)
        service_protocol = request.form.get("protocol", default=None)
        service_src_start_port = request.form.get("src_start_port", default=0)
        service_src_end_port = request.form.get("src_end_port", default=0)
        service_dst_start_port = request.form.get("dst_start_port", default=0)
        service_dst_end_port = request.form.get("dst_end_port", default=0)

        new_service = Service(name=service_name, category=service_category, protocol=service_protocol,
            src_start_port=service_src_start_port, src_end_port=service_src_end_port, dst_start_port=service_dst_start_port, dst_end_port=service_dst_end_port)
        db.session.add(new_service)
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('services' + ' <ServiceName: ' + service_name + '>'), operation='add')
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return services(err=True, msg="Yeni servis eklenirken sunucu hatasi gerceklesti.")
    return services(saved=True, msg="Yeni servis başarıyla eklendi." )

@login_required
@permission_required(['edit_service', 'super_user'])
def update_service(service_id: int):
    Service = main_models.Service

    try:
        service_name = request.form.get("service_name", default=None)
        service_category = request.form.get("category", default=None)
        service_protocol = request.form.get("protocol", default=None)
        service_src_start_port = request.form.get("src_start_port", default=0)
        service_src_end_port = request.form.get("src_end_port", default=0)
        service_dst_start_port = request.form.get("dst_start_port", default=0)
        service_dst_end_port = request.form.get("dst_end_port", default=0)

        if not service_src_start_port and not service_src_end_port and not service_dst_start_port and not service_dst_end_port:
            return services(err=True, msg="Servis guncellenirken sunucu hatasi gerceklesti.")

        srv = Service.query.filter(Service.id == service_id).first()
        srv.name = service_name
        srv.category = service_category
        srv.protocol = service_protocol
        srv.src_start_port = service_src_start_port
        srv.src_end_port = service_src_end_port
        srv.dst_start_port = service_dst_start_port
        srv.dst_end_port = service_dst_end_port

        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('services' + ' <ServiceName: ' + service_name + '>'), operation='update')
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return services(err=True, msg="Servis guncellenirken sunucu hatasi gerceklesti.")
    return services(saved=True, msg="Servis başarıyla guncellendi.")

@login_required
@permission_required(['edit_fw', 'super_user'])
def add_new_firewall():
    Firewall = main_models.Firewall
    Interface = main_models.Interface
    Address = main_models.Address

    try:
        fw_name = request.form.get("fw_name", default=None)
        fw_manegement_iface = request.form.get("manegement_iface_name", default=None)
        fw_manegement_ip = request.form.get("manegement_iface_addr", default=None)

        if not fw_name or not fw_manegement_iface or not fw_manegement_ip:
            return jsonify(success=False, msg="Bütün bilgiler eksiksiz girilmelidir!")

        if Firewall.query.filter(Firewall.name == fw_name).first():
            return jsonify(success=False, msg="Bu isimde bir guvenlik duvari zaten mevcut!")

        # Add new firewall
        new_fw = Firewall(name=fw_name.strip())
        db.session.add(new_fw)

        # Add management iface to fw
        fw = Firewall.query.filter(Firewall.name == fw_name).first()
        new_iface = Interface(name=fw_manegement_iface, iface_type="ethernet", is_manegement=True)
        fw.interfaces.append(new_iface)

        # Add address to manegement iface
        addr_name = fw_name + ':' + fw_manegement_iface + ':ip'
        addr_type = 'netmask'
        new_addr = Address(name=addr_name, addr_type=addr_type, addr_value=fw_manegement_ip)
        new_iface.addr.append(new_addr)

        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewalls' + ' <FwName: ' + fw_name + '>'), operation='add', firewall=fw_name)
        print("JAKSDKJASBDKABSD")
        return jsonify(success=True)
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

@login_required
@permission_required(['edit_fw', 'super_user'])
def update_firewall(firewall_id: int):
    Firewall = main_models.Firewall

    try:
        fw_name = request.form.get("fw_name", default=None)
        if not fw_name:
            return jsonify(success=False)
        fw = Firewall.query.filter(Firewall.id==firewall_id).first()
        old_name = fw.name
        fw.name = fw_name
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewalls' + ' <FwName: ' + old_name + '>'), operation='rename', firewall=fw_name)
        return jsonify(success=True)
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

@login_required
@permission_required(['edit_fw', 'super_user'])
def add_new_interface(fw_id: int):
    Firewall = main_models.Firewall
    Interface = main_models.Interface

    try:
        iface_name = request.form.get("iface_name", default=None)
        iface_type = request.form.get("iface_type", default="ethernet")
        is_manegement_iface = request.form.get("manegement_iface", default="off") == "on"
        fw = Firewall.query.filter(Firewall.id == fw_id).first()
        new_iface = Interface(name=iface_name, iface_type=iface_type, is_manegement=is_manegement_iface)
        fw.interfaces.append(new_iface)
        db.session.commit()
        if is_manegement_iface:
            for iface in fw.interfaces:
                iface.is_manegement = False
        new_iface.is_manegement = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewall_interface' + ' <IfaceName: ' + iface_name + '>'), operation='add')
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return firewall_options(fw_id, err=True, msg="Interface eklenirken sunucu hatasi gerceklesti.")
    return firewall_options(fw_id, saved=True, msg="Interface basariyla eklendi.")

@login_required
@permission_required(['edit_fw', 'super_user'])
def update_interface(iface_id: int):
    Interface = main_models.Interface

    try:
        fw_id = request.form.get("fw_id", default="")
        iface_name = request.form.get("iface_name", default="")
        iface_type = request.form.get("iface_type", default="ethernet")
        is_manegement_iface = request.form.get("manegement_iface", default="off") == "on"

        if is_manegement_iface:
            Firewall = main_models.Firewall
            fw = Firewall.query.filter(Firewall.id == fw_id).first()
            for iface in fw.interfaces:
                iface.is_manegement = False
            db.session.commit()

        iface = Interface.query.filter(Interface.id == iface_id).first()
        iface.name = iface_name
        iface.iface_type = iface_type
        iface.is_manegement = is_manegement_iface
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewall_interface' + ' <IfaceName: ' + iface_name + '>'), operation='update')
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return firewall_options(fw_id, err=True, msg="Interface guncellenirken sunucu hatasi gerceklesti.")
    return firewall_options(fw_id, saved=True, msg="Interface basariyla guncellendi.")

# *-* API like(json) returns for ajax requests *-*

@login_required
def search_firewall():
    Firewall = main_models.Firewall
    q = request.form['q'] # Name is the only query value in firewalls.

    if not q:
        return jsonify(success=False)
    try:
        fw_list = Firewall.query.filter(Firewall.name.like("%{}%".format(q))).all()
        ret = json.dumps(fw_list, cls=AlchemyEncoder)
        return ret
    except Exception as e:
        return jsonify(success=False)

@login_required
@permission_required(['view_address', 'super_user'])
def get_address():
    Address = main_models.Address

    try:
        addr_id = request.args.get('addr_id',default=None)
        addr = Address.query.filter(Address.id == addr_id).first()
        return json.dumps(addr, cls=AlchemyEncoder)
    except Exception as e:
        log.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['edit_address', 'super_user'])
def delete_address(addr_id: int):
    Address = main_models.Address
    try:
        if request.form.get("iface_id", ""):
            Interface = main_models.Interface
            iface = Interface.query.filter(Interface.id == request.form["iface_id"]).first()
            addr = Address.query.filter(Address.id == addr_id).first()
            iface.addr.pop(iface.addr.index(addr))
        addr_name = Address.query.filter(Address.id == addr_id).first().name
        addr = Address.query.filter(Address.id == addr_id).first()
        db.session.delete(addr)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('addresses' + ' <AddrName: ' + addr_name + '>'),
                    operation='delete')
        db.session.commit()
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
@permission_required(['view_service', 'super_user'])
def get_service():
    Service = main_models.Service

    try:
        service_id = request.args.get('service_id',default=None)
        service = Service.query.filter(Service.id == service_id).first()
        return json.dumps(service, cls=AlchemyEncoder)
    except Exception as e:
        log.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['edit_service', 'super_user'])
def delete_service(service_id: int):
    Service = main_models.Service

    try:
        service_name = Service.query.filter(Service.id == service_id).first().name
        serv = Service.query.filter(Service.id == service_id).first()
        db.session.delete(serv)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('services' + ' <ServiceName: ' + service_name + '>'),
                    operation='delete')
        db.session.commit()
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
@permission_required(['view_timeprofile', 'super_user'])
def get_time_profile():
    TimeProfile = main_models.TimeProfile

    try:
        time_profile_id = request.args.get('time_profile_id',default=None)
        tp = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()

        ret = {}
        ret['id'] = tp.id
        ret['name'] = tp.name
        ret['start_date'] = tp.start_date.strftime("%Y-%m-%d") if tp.start_date else False
        ret['start_time'] = tp.start_time.strftime("%H:%M")
        ret['end_date'] = tp.end_date.strftime("%Y-%m-%d") if tp.end_date else False
        ret['end_time'] = tp.end_time.strftime("%H:%M")
        ret['days'] = tp.days
        return json.dumps(ret)
    except Exception as e:
        log.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['view_timeprofile', 'super_user'])
def delete_time_profile(time_profile_id: int):
    TimeProfile = main_models.TimeProfile

    try:
        profile_name = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first().name
        tp = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        db.session.delete(tp)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('time_profiles' + ' <ProfileName: ' + profile_name + '>'),
                    operation='delete')
        db.session.commit()
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
def get_firewall():
    Firewall = main_models.Firewall

    try:
        firewall_id = request.args.get('firewall_id',default=None)
        if not current_user.can_access_fw(int(firewall_id)):
            return jsonify(success=False)

        fw = Firewall.query.filter(Firewall.id == firewall_id).first()
        return json.dumps(fw, cls=AlchemyEncoder)
    except Exception as e:
        log.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['edit_fw', 'super_user'])
def delete_firewall(firewall_id: int):
    Firewall = main_models.Firewall

    if not current_user.can_access_fw(int(firewall_id)):
            return jsonify(success=False)
    try:
        fw_name = Firewall.query.filter(Firewall.id == firewall_id).first().name
        fw = Firewall.query.filter(Firewall.id == firewall_id).first()
        for iface in fw.interfaces:
            for addr in iface.addr:
                db.session.delete(addr)
            db.session.delete(iface)
        db.session.delete(fw)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewalls' + ' <FwName: ' + fw_name + '>'),
                    operation='delete')
        db.session.commit()
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
def get_interface():
    Interface = main_models.Interface

    try:
        iface_id = request.args.get('iface_id',default=None)
        interface = Interface.query.filter(Interface.id == iface_id).first()
        return json.dumps(interface, cls=AlchemyEncoder)
    except Exception as e:
        log.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['edit_fw', 'super_user'])
def delete_interface(iface_id: int):
    Interface = main_models.Interface

    try:
        iface = Interface.query.filter(Interface.id == iface_id).first()
        iface_name = iface.name
        for addr in iface.addr:
            db.session.delete(addr)
        db.session.delete(iface)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'),
                    section=('firewall_interface' + ' <IfaceName: ' + iface_name + '>'),
                    operation='delete')
        db.session.commit()
    except Exception as e:
        log.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
@permission_required(['view_address', 'super_user'])
def address_full_text_search():
    """ the function returns the address list as a json data"""
    Address = main_models.Address

    q = request.form['q']

    if not q:
        return jsonify(success=False)

    filter_spec = [{'or': []}]
    for column in Address.__table__.columns.keys():
        spec = {'field': str(column), 'op': 'like', 'value': str("%" + q + "%")}
        filter_spec[0]['or'].append(spec)
    sql_query = db.session.query(Address)
    filtered_query = apply_filters(sql_query, filter_spec)
    records = filtered_query.all()
    y = json.dumps(records, cls=AlchemyEncoder)
    return y

@login_required
@permission_required(['view_service', 'super_user'])
def service_full_text_search():
    """ the function returns the address list as a json data"""
    Service = main_models.Service

    q = request.form['q']

    if not q:
        return jsonify(success=False)

    filter_spec = [{'or': []}]
    for column in Service.__table__.columns.keys():
        spec = {'field': str(column), 'op': 'like', 'value': str("%" + q + "%")}
        filter_spec[0]['or'].append(spec)
    sql_query = db.session.query(Service)
    filtered_query = apply_filters(sql_query, filter_spec)
    records = filtered_query.all()
    y = json.dumps(records, cls=AlchemyEncoder)
    return y

@login_required
@permission_required(['apply_commit', 'super_user'])
def apply_commits():
    git_commit_message = request.form.get("msg", default=None)
    fw_ids = request.form.getlist("fw_ids[]", None)

    if not git_commit_message:
        return jsonify(success=False)

    try:
        ret = apply_commits_and_push(git_commit_message, fw_ids)
    except Exception as e:
        log.error(traceback.format_exc())
        ret = False
    return jsonify(success=ret)

@login_required
@permission_required(['apply_commit', 'super_user'])
def revert_commits():
    try:
        ret = discard_changes()
    except Exception as e:
        log.error(traceback.format_exc())
        ret = False
    return jsonify(success=ret)

@login_required
@permission_required(['view_rule', 'super_user'])
def build_single_rule():
    rule_type = request.form['rule_type'] # policy/nat/routing
    rule_id = request.form['rule_id']

    if rule_type.lower() == "policy":
        ret = build_single_policy_rule(rule_id)
    elif rule_type.lower() == "nat":
        ret = build_single_nat_rule(rule_id)
    elif rule_type.lower() == "routing":
        ret = build_single_routing_rule(rule_id)
    return json.dumps(ret)
