from flask import render_template, flash, redirect, url_for, request, jsonify, session, current_app
from app.apps.main import models as main_models
from flask_user import current_user, login_required, roles_required, UserManager, UserMixin
from sqlalchemy import inspect, or_, and_, func, alias
from sqlalchemy_filters import apply_filters
from sqlalchemy.orm import aliased, joinedload
from app import ACTIVE_FW, db, log
from app.apps.main.utils import *
from app.apps.main.permissions import permission_required
from dateutil.relativedelta import relativedelta

import traceback
import ipaddress, json
import datetime

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv6_rules():
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv6_rules" not in referrer:
        clear_filter_params()

    if not ACTIVE_FW:
        return redirect("/", code=302)

    PolicyRule = main_models.PolicyRule
    Address = main_models.Address
    Service = main_models.Service
    TimeProfile = main_models.TimeProfile

    filters = {
        "name": PolicyRule.name,
        "direction": PolicyRule.direction,
        "action": PolicyRule.action,
        "log": PolicyRule.log,
        "src_addr": PolicyRule.src_addr,
        "dst_addr": PolicyRule.dst_addr
    }

    FwPolicyRules = main_models.FwPolicyRules

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    try:
        if filter_field and filter_input:
            if filter_field == "addr":
                src_addr = aliased(Address)
                dst_addr = aliased(Address)
                rules = FwPolicyRules.query.join(PolicyRule).outerjoin(src_addr, PolicyRule.src_addr) \
                    .outerjoin(dst_addr, PolicyRule.dst_addr) \
                    .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                    .filter(PolicyRule.rule_type == "ipv6") \
                    .filter(or_(dst_addr.name.like("%{}%".format(filter_input)), src_addr.name.like("%{}%".format(filter_input))) | \
                            or_(dst_addr.addr_value.like("%{}%".format(filter_input)), src_addr.addr_value.like("%{}%".format(filter_input)))) \
                    .order_by(FwPolicyRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field in ["src_addr", "dst_addr"]:
                rules = FwPolicyRules.query.join(PolicyRule).join(filters[filter_field]) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv6") \
                            .filter(or_(Address.addr_value.like("%{}%".format(filter_input)), Address.name.like("%{}%".format(filter_input)))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field == "service":
                rules = FwPolicyRules.query.join(PolicyRule).join(Service) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv6") \
                            .filter(or_(Service.start_port.like("%{}%".format(filter_input)), Service.end_port.like("%{}%".format(filter_input)))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            else:
                rules = FwPolicyRules.query.join(PolicyRule) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv6") \
                            .filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            rules = FwPolicyRules.query.join(PolicyRule) \
                        .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                        .filter(PolicyRule.rule_type == "ipv6") \
                        .order_by(FwPolicyRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)            
    except Exception as e:
        clear_filter_params()
        rules = FwPolicyRules.query.join(PolicyRule) \
            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
            .filter(PolicyRule.rule_type == "ipv6") \
            .order_by(FwPolicyRules.rank) \
            .paginate(per_page=per_page, page=page, error_out=True) 
    extra_vars['page_name'] = 'ipv6_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces
    return render_template('ipv6_rules.html', vars=extra_vars)

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv6_nat_rules():
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv6_nat_rules" not in referrer:
        clear_filter_params()

    if not ACTIVE_FW:
        return redirect("/", code=302)

    NatRule = main_models.NatRule
    Address = main_models.Address
    Service = main_models.Service
    TimeProfile = main_models.TimeProfile

    filters = {
        "name": NatRule.name,
        "interface_in": NatRule.interface_in,
        "interface_out": NatRule.interface_out,
        "action": NatRule.action,
        "log": NatRule.log,
        "original_src": NatRule.original_src,
        "original_dst": NatRule.original_dst,
        "translated_src": NatRule.translated_src,
        "translated_dst": NatRule.translated_dst,
        "original_srv": NatRule.original_srv,
        "translated_srv": NatRule.translated_srv
    }

    FwNatRules = main_models.FwNatRules

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    try:  
        if filter_field and filter_input:
            filter_args = {}
            filter_args["rule." + filter_field] = filter_input
            if filter_field == "addr":
                original_src = aliased(Address)
                original_dst = aliased(Address)
                translated_src = aliased(Address)
                translated_dst = aliased(Address)
                
                rules = FwNatRules.query.join(NatRule).outerjoin(original_src, NatRule.original_src) \
                            .outerjoin(original_dst, NatRule.original_dst) \
                            .outerjoin(translated_src, NatRule.translated_src) \
                            .outerjoin(translated_dst, NatRule.translated_dst) \
                            .filter(FwNatRules.firewall==ACTIVE_FW).filter(NatRule.rule_type == "ipv6") \
                            .filter(Address.addr_value.like("%{}%".format(filter_input))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)            

            elif filter_field == "srv":
                original_srv = aliased(Service)
                translated_srv = aliased(Service)

            if filter_field in ["original_src", "original_dst", "translated_src", "translated_dst"]:
                rules = FwNatRules.query.join(NatRule).join(filters[filter_field]) \
                            .filter(FwNatRules.firewall==ACTIVE_FW).filter(NatRule.rule_type == "ipv6") \
                            .filter(Address.addr_value.like("%{}%".format(filter_input))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field in ["original_srv", "translated_srv"]:
                rules = FwNatRules.query.join(NatRule).join(filters[filter_field]) \
                            .filter(FwNatRules.firewall==ACTIVE_FW) \
                            .filter(NatRule.rule_type == "ipv6") \
                            .filter(or_(Service.start_port.like("%{}%".format(filter_input)), Service.end_port.like("%{}%".format(filter_input)))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            else:
                rules = FwNatRules.query.join(NatRule) \
                            .filter(FwNatRules.firewall==ACTIVE_FW) \
                            .filter(NatRule.rule_type == "ipv6") \
                            .filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            rules = FwNatRules.query.join(NatRule) \
                        .filter(FwNatRules.firewall==ACTIVE_FW) \
                        .filter(NatRule.rule_type == "ipv6") \
                        .order_by(FwNatRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        clear_filter_params()
        rules = FwNatRules.query.join(NatRule) \
                        .filter(FwNatRules.firewall==ACTIVE_FW) \
                        .filter(NatRule.rule_type == "ipv6") \
                        .order_by(FwNatRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)                         
    extra_vars['page_name'] = 'ipv6_nat_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces
    return render_template('ipv6_nat_rules.html', vars=extra_vars)

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv6_routing_rules():
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv6_routing_rules" not in referrer:
        clear_filter_params()  

    if not ACTIVE_FW:
        return redirect("/", code=302)  
    
    FwRoutingRules = main_models.FwRoutingRules
    RoutingRule = main_models.RoutingRule
    filters = {
        "name": RoutingRule.name,
        "destination": RoutingRule.destination,
        "gateway": RoutingRule.gateway,
        "interface": RoutingRule.interface,
        "log": RoutingRule.log
    }

    Address = main_models.Address
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    
    if filter_field and filter_input:
        filter_args = {}
        filter_args["rule." + filter_field] = filter_input
        if filter_field in ["destination", "gateway"]:
            rules = FwRoutingRules.query.join(RoutingRule).join(filters[filter_field]) \
                        .filter(FwRoutingRules.firewall==ACTIVE_FW) \
                        .filter(RoutingRule.rule_type == "ipv6") \
                        .filter(or_(Address.addr_value.like("%{}%".format(filter_input)), Address.name.like("%{}%".format(filter_input)))) \
                        .order_by(FwRoutingRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
        elif filter_field in "interface":
            rules = FwRoutingRules.query.join(RoutingRule).join(filters[filter_field]) \
                        .filter(FwRoutingRules.firewall==ACTIVE_FW) \
                        .filter(RoutingRule.rule_type == "ipv6") \
                        .filter(Interface.name.like("%{}%".format(filter_input))) \
                        .order_by(FwRoutingRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
        else:
            rules = FwRoutingRules.query.join(RoutingRule).filter(FwRoutingRules.firewall==ACTIVE_FW) \
                    .filter(RoutingRule.rule_type == "ipv6") \
                    .order_by(FwRoutingRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
        extra_vars['filter_field'] = filter_field
        extra_vars['filter_input'] = filter_input
    else:
        rules = FwRoutingRules.query.join(RoutingRule).filter(FwRoutingRules.firewall==ACTIVE_FW) \
                    .filter(RoutingRule.rule_type == "ipv6") \
                    .order_by(FwRoutingRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
    extra_vars['page_name'] = 'ipv6_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces

    return render_template('ipv6_routing_rules.html', vars=extra_vars)