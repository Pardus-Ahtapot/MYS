from flask import render_template, flash, redirect, url_for, request, jsonify, session, current_app
from app.apps.main import models as main_models
from flask_user import current_user, login_required, roles_required, UserManager, UserMixin
from sqlalchemy import inspect, or_, and_, func, alias
from sqlalchemy_filters import apply_filters
from sqlalchemy.orm import aliased, joinedload
from app import ACTIVE_FW, db, log
from app import log as logger
from app.apps.main.utils import *
from app.apps.main.permissions import permission_required
from dateutil.relativedelta import relativedelta

import traceback
import ipaddress, json
import datetime

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv4_rules(err=False, saved=False, msg=""):
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv4_rules" not in referrer:
        clear_filter_params()

    if not ACTIVE_FW:
        return redirect("/", code=302)

    PolicyRule = main_models.PolicyRule
    Address = main_models.Address
    Service = main_models.Service
    TimeProfile = main_models.TimeProfile

    filters = {
        "name": PolicyRule.name,
        "direction": PolicyRule.direction,
        "action": PolicyRule.action,
        "log": PolicyRule.log,
        "src_addr": PolicyRule.src_addr,
        "dst_addr": PolicyRule.dst_addr
    }

    FwPolicyRules = main_models.FwPolicyRules

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    try:
        if filter_field and filter_input:
            if filter_field == "addr":
                src_addr = aliased(Address)
                dst_addr = aliased(Address)
                rules = FwPolicyRules.query.join(PolicyRule).outerjoin(src_addr, PolicyRule.src_addr) \
                    .outerjoin(dst_addr, PolicyRule.dst_addr) \
                    .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                    .filter(PolicyRule.rule_type == "ipv4") \
                    .filter(or_(dst_addr.name.like("%{}%".format(filter_input)), src_addr.name.like("%{}%".format(filter_input))) | \
                            or_(dst_addr.addr_value.like("%{}%".format(filter_input)), src_addr.addr_value.like("%{}%".format(filter_input)))) \
                    .order_by(FwPolicyRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field in ["src_addr", "dst_addr"]:
                rules = FwPolicyRules.query.join(PolicyRule).join(filters[filter_field]) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv4") \
                            .filter(or_(Address.addr_value.like("%{}%".format(filter_input)), Address.name.like("%{}%".format(filter_input)))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field == "service":
                rule_service = aliased(Service)
                rules = FwPolicyRules.query.join(PolicyRule).join(rule_service, PolicyRule.port) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv4") \
                            .filter(or_(rule_service.src_start_port.like("%{}%".format(filter_input)), rule_service.src_end_port.like("%{}%".format(filter_input))) |
                                    or_(rule_service.dst_start_port.like("%{}%".format(filter_input)), rule_service.dst_end_port.like("%{}%".format(filter_input)))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            else:
                rules = FwPolicyRules.query.join(PolicyRule) \
                            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                            .filter(PolicyRule.rule_type == "ipv4") \
                            .filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(FwPolicyRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            rules = FwPolicyRules.query.join(PolicyRule) \
                        .filter(FwPolicyRules.firewall==ACTIVE_FW) \
                        .filter(PolicyRule.rule_type == "ipv4") \
                        .order_by(FwPolicyRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)            
    except Exception as e:
        log.error(traceback.format_exc())
        clear_filter_params()
        rules = FwPolicyRules.query.join(PolicyRule) \
            .filter(FwPolicyRules.firewall==ACTIVE_FW) \
            .filter(PolicyRule.rule_type == "ipv4") \
            .order_by(FwPolicyRules.rank) \
            .paginate(per_page=per_page, page=page, error_out=True) 
    extra_vars['page_name'] = 'ipv4_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('ipv4_rules.html', vars=extra_vars)

@login_required
@permission_required(['edit_rule', 'super_user'])
def add_ipv4_policy_rule():
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwPolicyRules = main_models.FwPolicyRules
    PolicyRule = main_models.PolicyRule 
    Address = main_models.Address 
    Service = main_models.Service
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        abow_rule_id = request.form.get('abow_rule_id', "")
        below_rule_id = request.form.get('below_rule_id', "")

        src_addr_ids = request.form.getlist('src-ip-select', None)
        if src_addr_ids:
            src_addr = []
            for src_addr_id in src_addr_ids:
                if src_addr_id == "any":
                    src_addr = []
                    break
                src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            src_addr = []
        
        dst_addr_ids = request.form.getlist('dst-ip-select', None)
        if dst_addr_ids:
            dst_addr = []
            for dst_addr_id in dst_addr_ids:
                if dst_addr_id == "any":
                    dst_addr = []
                    break
                dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            dst_addr = []
        
        iface_ids = request.form.getlist('iface-select', None)
        if iface_ids:
            iface = []
            for iface_id in iface_ids:
                if iface_id == "any":
                    iface = []
                    break
                iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            iface = []

        service_ids = request.form.getlist('service-select', None)
        if service_ids:
            service = []
            for service_id in service_ids:
                if service_id == "any":
                    service = []
                    break
                service.append(Service.query.filter(Service.id == service_id).first())
        else:
            service = []

        time_profile_id = request.form.get('schedule', None)
        if time_profile_id:
            time_profile = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        else:
            time_profile = None    

        direction = request.form.get('direction', default="both")
        log = True if request.form.get('log', False) == "on" else False
        negate_src = True if request.form.get('negate-src', False) == "on" else False
        negate_dst = True if request.form.get('negate-dst', False) == "on" else False
        action = request.form.get('action', default="accept")
        comment = request.form.get('comment', default="")

        # Add Policy Rule
        db.session.autoflush = False
        test_policy = PolicyRule(active=active, name=name, rule_type=rule_type, direction=direction, action=action, 
                                comment=comment, src_addr=src_addr, dst_addr=dst_addr, port=service, interface=iface,
                                time_profile=time_profile, log=log, negate_src_addr=negate_src, negate_dst_addr=negate_dst)
        rule_assoc = FwPolicyRules(rule=test_policy)
        if abow_rule_id or below_rule_id:
            if abow_rule_id:
                rank = FwPolicyRules.query.filter(FwPolicyRules.id == abow_rule_id).first().rank
                rank = int(rank)
            if below_rule_id:
                rank = FwPolicyRules.query.filter(FwPolicyRules.id == below_rule_id).first().rank
                rank = int(rank) + 1
            fw.policy_rules.insert(rank, rule_assoc)
        else:
            fw.policy_rules.append(rule_assoc)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('policy_rules' + ' <RuleName: ' + name + '>'), 
                    operation='add', firewall=ACTIVE_FW.name)
        return ipv4_rules(saved=True, msg="Kural basariyla eklendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_rules(err=True, msg="Kural eklenirken hata olustu!")

@login_required
@permission_required(['edit_rule', 'super_user'])
def update_ipv4_policy_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwPolicyRules = main_models.FwPolicyRules
    PolicyRule = main_models.PolicyRule 
    Address = main_models.Address 
    Service = main_models.Service
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        print(request.form)
        src_addr_ids = request.form.getlist('src-ip-select', None)
        src_addr = []
        if src_addr_ids:
            for src_addr_id in src_addr_ids:
                if src_addr_id == "any":
                    src_addr = []
                    break
                src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            src_addr = []
        
        dst_addr_ids = request.form.getlist('dst-ip-select', None)
        dst_addr = []
        if dst_addr_ids:
            for dst_addr_id in dst_addr_ids:
                if dst_addr_id == "any":
                    dst_addr = []
                    break
                dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            dst_addr = []
        
        iface_ids = request.form.getlist('iface-select', None)
        iface = []
        if iface_ids:
            for iface_id in iface_ids:
                if iface_id == "any":
                    iface = []
                    break
                iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            iface = []

        service_ids = request.form.getlist('service-select', None)
        service = []
        if service_ids:
            for service_id in service_ids:
                if service_id == "any":
                    service = []
                    break
                service.append(Service.query.filter(Service.id == service_id).first())
        else:
            service = []

        time_profile_id = request.form.get('schedule', None)
        if time_profile_id:
            time_profile = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        else:
            time_profile = None

        direction = request.form.get('direction', "both")
        log = True if request.form.get('log', False) == "on" else False
        negate_src = True if request.form.get('negate-src', False) == "on" else False
        negate_dst = True if request.form.get('negate-dst', False) == "on" else False
        action = request.form.get('action', "accept")
        comment = request.form.get('comment', default="")

        # Update Policy Rule
        db.session.autoflush = False
        policy_rule = FwPolicyRules.query.filter(FwPolicyRules.id == rule_id).first().rule
        policy_rule.active = active
        policy_rule.name = name
        policy_rule.rule_type = rule_type
        policy_rule.direction = direction
        policy_rule.action = action
        policy_rule.comment = comment
        policy_rule.src_addr = src_addr
        policy_rule.dst_addr = dst_addr
        policy_rule.port = service
        policy_rule.interface = iface
        policy_rule.time_profile = time_profile
        policy_rule.log = log
        policy_rule.negate_src_addr = negate_src
        policy_rule.negate_dst_addr = negate_dst
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('policy_rules' + ' <RuleName: ' + name + '>'),
                    operation='update', firewall=ACTIVE_FW.name)
        return ipv4_rules(saved=True, msg="Kural basariyla guncellendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_rules(err=True, msg="Kural guncellendi hata olustu!")    

@login_required
@permission_required(['edit_rule', 'super_user'])
def change_ipv4_policy_rule_rank():
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwPolicyRules = main_models.FwPolicyRules
    NatRule = main_models.NatRule 

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()

    rule_id = request.form.get("rule_id")
    direction = request.form.get("direction")
    rule_rank = request.form.get("rule_rank")
    
    try:
        db.session.autoflush = False
        rank = FwPolicyRules.query.filter(FwPolicyRules.id == rule_id).first().rank
        greatest_rank = db.session.query(func.max(FwPolicyRules.rank)).first()[0]
        
        if rule_rank:
            new_rank = int(rule_rank)
        elif direction == "up":
            new_rank = rank - 1
        elif direction == "down":
            new_rank = rank + 1

        if new_rank < 0:
            new_rank = 0
        elif new_rank > greatest_rank:
            new_rank = greatest_rank

        rule_assoc = fw.policy_rules.pop(rank)
        rule_name = rule_assoc.rule.name
        a = FwPolicyRules(rule=rule_assoc.rule)
        fw.policy_rules.insert(new_rank, a)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('policy_rules' + ' <RuleName: ' + rule_name + '>'), 
                    operation='reorder', firewall=ACTIVE_FW.name)
        return jsonify(success=True)
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv4_nat_rules(err=False, saved=False, msg=""):
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv4_nat_rules" not in referrer:
        clear_filter_params()

    if not ACTIVE_FW:
        return redirect("/", code=302)

    NatRule = main_models.NatRule
    Address = main_models.Address
    Service = main_models.Service
    TimeProfile = main_models.TimeProfile

    filters = {
        "name": NatRule.name,
        "interface_in": NatRule.interface_in,
        "interface_out": NatRule.interface_out,
        "action": NatRule.action,
        "log": NatRule.log,
        "original_src": NatRule.original_src,
        "original_dst": NatRule.original_dst,
        "translated_src": NatRule.translated_src,
        "translated_dst": NatRule.translated_dst,
        "original_srv": NatRule.original_srv,
        "translated_srv": NatRule.translated_srv
    }

    FwNatRules = main_models.FwNatRules

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    try:  
        if filter_field and filter_input:
            filter_args = {}
            filter_args["rule." + filter_field] = filter_input
            if filter_field == "addr":
                original_src = aliased(Address)
                original_dst = aliased(Address)
                translated_src = aliased(Address)
                translated_dst = aliased(Address)
                
                rules = FwNatRules.query.join(NatRule).outerjoin(original_src, NatRule.original_src) \
                            .outerjoin(original_dst, NatRule.original_dst) \
                            .outerjoin(translated_src, NatRule.translated_src) \
                            .outerjoin(translated_dst, NatRule.translated_dst) \
                            .filter(FwNatRules.firewall==ACTIVE_FW).filter(NatRule.rule_type == "ipv4") \
                            .filter(or_(original_src.name.like("%{}%".format(filter_input)), original_dst.name.like("%{}%".format(filter_input))) | \
                                    or_(original_src.addr_value.like("%{}%".format(filter_input)), original_dst.addr_value.like("%{}%".format(filter_input))) | \
                                    or_(translated_src.name.like("%{}%".format(filter_input)), translated_dst.name.like("%{}%".format(filter_input))) | \
                                    or_(translated_src.addr_value.like("%{}%".format(filter_input)), translated_dst.addr_value.like("%{}%".format(filter_input)))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)            

            elif filter_field == "srv_name":
                original_srv = aliased(Service)
                translated_srv = aliased(Service)

                rules = FwNatRules.query.join(NatRule).outerjoin(original_srv, NatRule.original_srv) \
                            .outerjoin(translated_srv, NatRule.translated_srv) \
                            .filter(FwNatRules.firewall==ACTIVE_FW).filter(NatRule.rule_type == "ipv4") \
                            .filter(or_(original_srv.name.like("%{}%".format(filter_input)), translated_srv.name.like("%{}%".format(filter_input)))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True) 

            elif filter_field in ["original_src", "original_dst", "translated_src", "translated_dst"]:
                rules = FwNatRules.query.join(NatRule).join(filters[filter_field]) \
                            .filter(FwNatRules.firewall==ACTIVE_FW).filter(NatRule.rule_type == "ipv4") \
                            .filter(or_(Address.addr_value.like("%{}%".format(filter_input)), Address.name.like("%{}%".format(filter_input)))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            elif filter_field in ["original_srv", "translated_srv"]:
                rules = FwNatRules.query.join(NatRule).join(filters[filter_field]) \
                            .filter(FwNatRules.firewall==ACTIVE_FW) \
                            .filter(NatRule.rule_type == "ipv4") \
                            .filter(or_(Service.src_start_port.like("%{}%".format(filter_input)), Service.src_end_port.like("%{}%".format(filter_input))) |
                                    or_(Service.dst_start_port.like("%{}%".format(filter_input)), Service.dst_end_port.like("%{}%".format(filter_input)))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            else:
                rules = FwNatRules.query.join(NatRule) \
                            .filter(FwNatRules.firewall==ACTIVE_FW) \
                            .filter(NatRule.rule_type == "ipv4") \
                            .filter(filters[filter_field].like("%{}%".format(filter_input))) \
                            .order_by(FwNatRules.rank) \
                            .paginate(per_page=per_page, page=page, error_out=True)
            extra_vars['filter_field'] = filter_field
            extra_vars['filter_input'] = filter_input
        else:
            rules = FwNatRules.query.join(NatRule) \
                        .filter(FwNatRules.firewall==ACTIVE_FW) \
                        .filter(NatRule.rule_type == "ipv4") \
                        .order_by(FwNatRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        clear_filter_params()
        rules = FwNatRules.query.join(NatRule) \
                        .filter(FwNatRules.firewall==ACTIVE_FW) \
                        .filter(NatRule.rule_type == "ipv4") \
                        .order_by(FwNatRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)                         
    extra_vars['page_name'] = 'ipv4_nat_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg
    return render_template('ipv4_nat_rules.html', vars=extra_vars)

@login_required
@permission_required(['edit_rule', 'super_user'])
def add_ipv4_nat_rule():
    ACTIVE_FW = get_active_firewall()
    
    Firewall = main_models.Firewall
    NatRule = main_models.NatRule
    FwNatRules = main_models.FwNatRules
    Address = main_models.Address
    Service = main_models.Service
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        abow_rule_id = request.form.get('abow_rule_id', "")
        below_rule_id = request.form.get('below_rule_id', "")

        # Orjinal values
        orj_src_addr_ids = request.form.getlist('orj_src_addr', None)
        if orj_src_addr_ids:
            orj_src_addr = []
            for src_addr_id in orj_src_addr_ids:
                if src_addr_id == "any":
                    orj_src_addr = []
                    break
                orj_src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            orj_src_addr = []
        
        orj_dst_addr_ids = request.form.getlist('orj_dst_addr', None)
        if orj_dst_addr_ids:
            orj_dst_addr = []
            for dst_addr_id in orj_dst_addr_ids:
                if dst_addr_id == "any":
                    orj_dst_addr = []
                    break
                orj_dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            orj_dst_addr = []
        
        in_iface_ids = request.form.getlist('in_iface', None)
        if in_iface_ids:
            in_iface = []
            for iface_id in in_iface_ids:
                if iface_id == "any":
                    in_iface = []
                    break
                in_iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            in_iface = []

        orj_service_ids = request.form.getlist('orj_service', None)
        if orj_service_ids:
            orj_service = []
            for service_id in orj_service_ids:
                if service_id == "any":
                    orj_service = []
                    break      
                orj_service.append(Service.query.filter(Service.id == service_id).first())
        else:
            orj_service = []    

        # Translated values

        trans_src_addr_ids = request.form.getlist('trans_src_addr', None)
        if trans_src_addr_ids:
            trans_src_addr = []
            for src_addr_id in trans_src_addr_ids:
                if src_addr_id == "any":
                    trans_src_addr = []
                    break
                trans_src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            trans_src_addr = []
        
        trans_dst_addr_ids = request.form.getlist('trans_dst_addr', None)
        if trans_dst_addr_ids:
            trans_dst_addr = []
            for dst_addr_id in trans_dst_addr_ids:
                if dst_addr_id == "any":
                    trans_dst_addr = []
                    break
                trans_dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            trans_dst_addr = []
        
        out_iface_ids = request.form.getlist('out_iface', None)
        if out_iface_ids:
            out_iface = []
            for iface_id in out_iface_ids:
                if iface_id == "any":
                    out_iface = []
                    break
                out_iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            out_iface = []

        trans_service_ids = request.form.getlist('trans_service', None)
        if trans_service_ids:
            trans_service = []
            for service_id in trans_service_ids:
                if service_id == "any":
                    trans_service = []
                    break
                trans_service.append(Service.query.filter(Service.id == service_id).first())
        else:
            trans_service = [] 

        time_profile_id = request.form.get('schedule', None)
        if time_profile_id:
            time_profile = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        else:
            time_profile = None

        log = True if request.form.get('log', False) == 'on' else False
        negate_org_src = True if request.form.get('negate-org-src', False) == "on" else False
        negate_org_dst = True if request.form.get('negate-org-dst', False) == "on" else False
        action = request.form.get('action', default="translate")
        comment = request.form.get('comment', default="")           
        
        # Add Nat Rule
        db.session.autoflush = False
        new_nat_rule = NatRule(active=active, name=name, rule_type=rule_type, action=action, comment=comment,
                                original_src=orj_src_addr, original_dst=orj_dst_addr, original_srv=orj_service,
                                translated_src=trans_src_addr, translated_dst=trans_dst_addr, translated_srv=trans_service,
                                interface_in=in_iface, interface_out=out_iface, time_profile=time_profile, log=log,
                                negate_original_src=negate_org_src, negate_original_dst=negate_org_dst)
        rule_assoc = FwNatRules(rule=new_nat_rule)
        if abow_rule_id or below_rule_id:
            if abow_rule_id:
                rank = FwNatRules.query.filter(FwNatRules.id == abow_rule_id).first().rank
                rank = int(rank)
            if below_rule_id:
                rank = FwNatRules.query.filter(FwNatRules.id == below_rule_id).first().rank
                rank = int(rank) + 1
            ACTIVE_FW.nat_rules.insert(rank, rule_assoc)
        else:
            ACTIVE_FW.nat_rules.append(rule_assoc)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('nat_rules' + ' <RuleName: ' + name + '>'), 
                    operation='add', firewall=ACTIVE_FW.name)
        return ipv4_nat_rules(saved=True, msg="Kural basariyla eklendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_nat_rules(err=True, msg="Kural eklenirken hata olustu!")

@login_required
@permission_required(['edit_rule', 'super_user'])
def update_ipv4_nat_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()
    
    Firewall = main_models.Firewall
    NatRule = main_models.NatRule
    FwNatRules = main_models.FwNatRules
    Address = main_models.Address
    Service = main_models.Service
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        abow_rule_id = request.form.get('abow_rule_id', "")
        below_rule_id = request.form.get('below_rule_id', "")

        # Orjinal values
        orj_src_addr_ids = request.form.getlist('orj_src_addr', None)
        if orj_src_addr_ids:
            orj_src_addr = []
            for src_addr_id in orj_src_addr_ids:
                if src_addr_id == "any":
                    orj_src_addr = []
                    break
                orj_src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            orj_src_addr = []
        
        orj_dst_addr_ids = request.form.getlist('orj_dst_addr', None)
        if orj_dst_addr_ids:
            orj_dst_addr = []
            for dst_addr_id in orj_dst_addr_ids:
                if dst_addr_id == "any":
                    orj_dst_addr = []
                    break
                orj_dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            orj_dst_addr = []
        
        in_iface_ids = request.form.getlist('in_iface', None)
        if in_iface_ids:
            in_iface = []
            for iface_id in in_iface_ids:
                if iface_id == "any":
                    in_iface = []
                    break
                in_iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            in_iface = []

        orj_service_ids = request.form.getlist('orj_service', None)
        if orj_service_ids:
            orj_service = []
            for service_id in orj_service_ids:
                if service_id == "any":
                    orj_service = []
                    break
                orj_service.append(Service.query.filter(Service.id == service_id).first())
        else:
            orj_service = []    

        # Translated values

        trans_src_addr_ids = request.form.getlist('trans_src_addr', None)
        if trans_src_addr_ids:
            trans_src_addr = []
            for src_addr_id in trans_src_addr_ids:
                if src_addr_id == "any":
                    trans_src_addr = []
                    break
                trans_src_addr.append(Address.query.filter(Address.id == src_addr_id).first())
        else:
            trans_src_addr = []
        
        trans_dst_addr_ids = request.form.getlist('trans_dst_addr', None)
        if trans_dst_addr_ids:
            trans_dst_addr = []
            for dst_addr_id in trans_dst_addr_ids:
                if dst_addr_id == "any":
                    trans_dst_addr = []
                    break
                trans_dst_addr.append(Address.query.filter(Address.id == dst_addr_id).first())
        else:
            trans_dst_addr = []
        
        out_iface_ids = request.form.getlist('out_iface', None)
        if out_iface_ids:
            out_iface = []
            for iface_id in out_iface_ids:
                if iface_id == "any":
                    out_iface = []
                    break
                out_iface.append(Interface.query.filter(Interface.id == iface_id).first())
        else:
            out_iface = []

        trans_service_ids = request.form.getlist('trans_service', None)
        if trans_service_ids:
            trans_service = []
            for service_id in trans_service_ids:
                if service_id == "any":
                    trans_service = []
                    break
                trans_service.append(Service.query.filter(Service.id == service_id).first())
        else:
            trans_service = [] 

        time_profile_id = request.form.get('schedule', None)
        if time_profile_id:
            time_profile = TimeProfile.query.filter(TimeProfile.id == time_profile_id).first()
        else:
            time_profile = None

        log = True if request.form.get('log', False) == 'on' else False
        negate_org_src = True if request.form.get('negate-org-src', False) == "on" else False
        negate_org_dst = True if request.form.get('negate-org-dst', False) == "on" else False
        action = request.form.get('action', default="translate")
        comment = request.form.get('comment', default="")           
        
        # Update Nat Rule
        db.session.autoflush = False
        nat_rule = FwNatRules.query.filter(FwNatRules.id == rule_id).first().rule
        nat_rule.active=active
        nat_rule.name=name
        nat_rule.rule_type=rule_type
        nat_rule.action=action
        nat_rule.comment=comment
        nat_rule.original_src=orj_src_addr
        nat_rule.original_dst=orj_dst_addr
        nat_rule.original_srv=orj_service
        nat_rule.translated_src=trans_src_addr
        nat_rule.translated_dst=trans_dst_addr
        nat_rule.translated_srv=trans_service
        nat_rule.interface_in=in_iface
        nat_rule.interface_out=out_iface
        nat_rule.time_profile=time_profile
        nat_rule.log=log
        nat_rule.negate_original_src=negate_org_src
        nat_rule.negate_original_dst=negate_org_dst
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('nat_rules' + ' <RuleName: ' + name + '>'), 
            operation='update', firewall=ACTIVE_FW.name)
        return ipv4_nat_rules(saved=True, msg="Kural basariyla guncellendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_nat_rules(err=True, msg="Kural guncellenirken hata olustu!")

@login_required
@permission_required(['edit_rule', 'super_user'])
def change_ipv4_nat_rule_rank():
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwNatRules = main_models.FwNatRules

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()

    rule_id = request.form.get("rule_id")
    direction = request.form.get("direction")
    rule_rank = request.form.get("rule_rank")
    
    try:
        db.session.autoflush = False
        rank = FwNatRules.query.filter(FwNatRules.id == rule_id).first().rank
        greatest_rank = db.session.query(func.max(FwNatRules.rank)).first()[0]
        
        if rule_rank:
            new_rank = int(rule_rank)
        elif direction == "up":
            new_rank = rank - 1
        elif direction == "down":
            new_rank = rank + 1

        if new_rank < 0:
            new_rank = 0
        elif new_rank > greatest_rank:
            new_rank = greatest_rank

        rule_assoc = fw.nat_rules.pop(rank)
        name = rule_assoc.rule.name
        a = FwNatRules(rule=rule_assoc.rule)
        fw.nat_rules.insert(new_rank, a)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('nat_rules' + ' <RuleName: ' + name + '>'), 
            operation='reorder', firewall=ACTIVE_FW.name)
        return jsonify(success=True)
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

@login_required
@permission_required(['view_rule', 'super_user'])
def ipv4_routing_rules(err=False, saved=False, msg=""):
    ACTIVE_FW = get_active_firewall()
    extra_vars = get_default_payload()

    # If not same page clear filter params
    referrer = request.referrer
    if referrer and "ipv4_routing_rules" not in referrer:
        clear_filter_params()    
    
    if not ACTIVE_FW:
        return redirect("/", code=302)

    FwRoutingRules = main_models.FwRoutingRules
    RoutingRule = main_models.RoutingRule
    filters = {
        "name": RoutingRule.name,
        "destination": RoutingRule.destination,
        "gateway": RoutingRule.gateway,
        "interface": RoutingRule.interface,
        "log": RoutingRule.log
    }

    Address = main_models.Address
    Interface = main_models.Interface
    TimeProfile = main_models.TimeProfile

    page = int(request.args.get('page',default=1))
    per_page = int(request.args.get('per_page', default=15))

    filter_field, filter_input = get_filter_params()
    """the function returns the index page when the user is logged in"""
    refresh_session_object(ACTIVE_FW)
    
    if filter_field and filter_input:
        filter_args = {}
        filter_args["rule." + filter_field] = filter_input
        if filter_field in ["destination", "gateway"]:
            rules = FwRoutingRules.query.join(RoutingRule).join(filters[filter_field]) \
                        .filter(FwRoutingRules.firewall==ACTIVE_FW) \
                        .filter(RoutingRule.rule_type == "ipv4") \
                        .filter(or_(Address.addr_value.like("%{}%".format(filter_input)), Address.name.like("%{}%".format(filter_input)))) \
                        .order_by(FwRoutingRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
        elif filter_field in "interface":
            rules = FwRoutingRules.query.join(RoutingRule).join(filters[filter_field]) \
                        .filter(FwRoutingRules.firewall==ACTIVE_FW) \
                        .filter(RoutingRule.rule_type == "ipv4") \
                        .filter(Interface.name.like("%{}%".format(filter_input))) \
                        .order_by(FwRoutingRules.rank) \
                        .paginate(per_page=per_page, page=page, error_out=True)
        else:
            rules = FwRoutingRules.query.join(RoutingRule).filter(FwRoutingRules.firewall==ACTIVE_FW) \
                    .filter(RoutingRule.rule_type == "ipv4") \
                    .order_by(FwRoutingRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
        extra_vars['filter_field'] = filter_field
        extra_vars['filter_input'] = filter_input
    else:
        rules = FwRoutingRules.query.join(RoutingRule).filter(FwRoutingRules.firewall==ACTIVE_FW) \
                    .filter(RoutingRule.rule_type == "ipv4") \
                    .order_by(FwRoutingRules.rank) \
                    .paginate(per_page=per_page, page=page, error_out=True)
    extra_vars['page_name'] = 'ipv4_rules'
    extra_vars['page_num'] = page
    extra_vars['per_page'] = per_page
    extra_vars['rules'] = rules
    extra_vars['recent_addrs'] = get_recently_used_addresses()
    extra_vars['recent_gateway_addrs'] = get_recently_used_addresses(addr_type="netmask")
    extra_vars['recent_services'] = get_recently_used_services()
    extra_vars['time_profiles'] = TimeProfile.query.all()
    extra_vars['fw_ifaces'] = ACTIVE_FW.interfaces
    extra_vars['error'] = err
    extra_vars['saved'] = saved
    extra_vars['msg'] = msg

    return render_template('ipv4_routing_rules.html', vars=extra_vars)

@login_required
@permission_required(['edit_rule', 'super_user'])
def add_ipv4_routing_rule():
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwRoutingRules = main_models.FwRoutingRules
    RoutingRule = main_models.RoutingRule 
    Address = main_models.Address 
    Interface = main_models.Interface

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        abow_rule_id = request.form.get('abow_rule_id', "")
        below_rule_id = request.form.get('below_rule_id', "")

        destination_ids = request.form.getlist('destination', None)
        if destination_ids:
            destination = []
            for destination_id in destination_ids:
                if destination_id == "any":
                    destination = []
                    break
                addr = Address.query.filter(Address.id == destination_id).first()
                if addr:
                    destination.append(addr)
        else:
            destination = []
        
        gateway_ids = request.form.getlist('gateway', None)
        if gateway_ids:
            gateway = []
            for gateway_id in gateway_ids:
                addr = Address.query.filter(Address.id == gateway_id).first()
                if addr:
                    gateway.append(addr)
        else:
            gateway = []
        
        iface_ids = request.form.getlist('iface', None)
        if iface_ids:
            iface = []
            for iface_id in iface_ids:
                if iface_id == "any":
                    iface = []
                    break
                ifc = Interface.query.filter(Interface.id == iface_id).first()
                if ifc:
                    iface.append(ifc)
        else:
            iface = [] 

        log = True if request.form.get('log', False) == '1' else False
        comment = request.form.get('comment', default="")

        if not gateway:
            return ipv4_routing_rules(err=True, msg="Gateway bos olamaz!")
        # Add Policy Rule
        db.session.autoflush = False
        new_rule = RoutingRule(active=active, name=name, rule_type=rule_type, destination=destination, gateway=gateway, 
                                comment=comment, interface=iface, log=log)
        rule_assoc = FwRoutingRules(rule=new_rule)
        if abow_rule_id or below_rule_id:
            if abow_rule_id:
                rank = FwRoutingRules.query.filter(FwRoutingRules.id == abow_rule_id).first().rank
                rank = int(rank)
            if below_rule_id:
                rank = FwRoutingRules.query.filter(FwRoutingRules.id == below_rule_id).first().rank
                rank = int(rank) + 1
            fw.routing_rules.insert(rank, rule_assoc)
        else:
            fw.routing_rules.append(rule_assoc)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('routing_rules' + ' <RuleName: ' + name + '>'), 
            operation='add', firewall=ACTIVE_FW.name)
        return ipv4_routing_rules(saved=True, msg="Kural basariyla eklendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_routing_rules(err=True, msg="Kural eklenirken hata olustu!")

@login_required
@permission_required(['edit_rule', 'super_user'])
def update_ipv4_routing_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwRoutingRules = main_models.FwRoutingRules
    RoutingRule = main_models.RoutingRule 
    Address = main_models.Address 
    Interface = main_models.Interface

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
    try:
        name = request.form.get('rule_name')
        active = True if request.form.get('rule_status', False) == "on" else False
        rule_type = request.form.get('rule_type', "ipv4")
        abow_rule_id = request.form.get('abow_rule_id', "")
        below_rule_id = request.form.get('below_rule_id', "")

        destination_ids = request.form.getlist('destination', None)
        destination = []
        if destination_ids:
            for destination_id in destination_ids:
                if destination_id == "any":
                    destination = []
                    break
                addr = Address.query.filter(Address.id == destination_id).first()
                if addr:
                    destination.append(addr)
            
        
        gateway_ids = request.form.getlist('gateway', None)
        gateway = []
        if gateway_ids:
            for gateway_id in gateway_ids:
                addr = Address.query.filter(Address.id == gateway_id).first()
                if addr:
                    gateway.append(addr)

        
        iface_ids = request.form.getlist('iface', None)
        iface = []
        if iface_ids:    
            for iface_id in iface_ids:
                if iface_id == "any":
                    iface = []
                    break
                ifc = Interface.query.filter(Interface.id == iface_id).first()
                if ifc:
                    iface.append(ifc)

        log = True if request.form.get('log', False) == '1' else False
        comment = request.form.get('comment', default="")

        if not gateway:
            return ipv4_routing_rules(err=True, msg="Gateway bos olamaz!")

        # Update Routing Rule
        db.session.autoflush = False
        routing_rule = FwRoutingRules.query.filter(FwRoutingRules.id == rule_id).first().rule
        routing_rule.active = active
        routing_rule.name = name
        routing_rule.rule_type = rule_type
        routing_rule.destination = destination
        routing_rule.gateway = gateway
        routing_rule.comment = comment
        routing_rule.interface = iface
        routing_rule.log = log
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('routing_rules' + ' <RuleName: ' + name + '>'), 
            operation='update', firewall=ACTIVE_FW.name)
        return ipv4_routing_rules(saved=True, msg="Kural basariyla guncellendi")
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return ipv4_routing_rules(err=True, msg="Kural guncellenirken hata olustu!")

@login_required
@permission_required(['edit_rule', 'super_user'])
def change_ipv4_routing_rule_rank():
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwRoutingRules = main_models.FwRoutingRules

    fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()

    rule_id = request.form.get("rule_id")
    direction = request.form.get("direction")
    rule_rank = request.form.get("rule_rank")
    
    try:
        db.session.autoflush = False
        rank = FwRoutingRules.query.filter(FwRoutingRules.id == rule_id).first().rank
        greatest_rank = db.session.query(func.max(FwRoutingRules.rank)).first()[0]
        
        if rule_rank:
            new_rank = int(rule_rank)
        elif direction == "up":
            new_rank = rank - 1
        elif direction == "down":
            new_rank = rank + 1

        if new_rank < 0:
            new_rank = 0
        elif new_rank > greatest_rank:
            new_rank = greatest_rank

        rule_assoc = fw.routing_rules.pop(rank)
        name = rule_assoc.rule.name
        a = FwRoutingRules(rule=rule_assoc.rule)
        fw.routing_rules.insert(new_rank, a)
        db.session.autoflush = True
        db.session.commit()
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
            section=('routing_rules' + ' <RuleName: ' + name + '>'), 
            operation='reorder', firewall=ACTIVE_FW.name)
        return jsonify(success=True)
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

@login_required
@permission_required(['view_rule', 'super_user'])
def get_ipv4_rule():
    # Returns the rule object as a json in Active_FW
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwPolicyRules = main_models.FwPolicyRules
    FwNatRules = main_models.FwNatRules
    FwRoutingRules = main_models.FwRoutingRules

    try:
        rule_type = request.args.get('rule_type',default=None)
        rule_id = request.args.get('rule_id',default=None)

        fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()

        ret = {}

        if rule_type == "policy":
            rule_obj = FwPolicyRules.query.filter(FwPolicyRules.id == rule_id).first()
            ret["id"] = rule_obj.id
            ret["action"] = rule_obj.rule.action
            ret["name"] = rule_obj.rule.name
            ret["src_addr"] = json.loads(json.dumps(rule_obj.rule.src_addr, cls=AlchemyEncoder))
            ret["rule_type"] = rule_obj.rule.rule_type
            ret["direction"] = rule_obj.rule.direction
            ret["dst_addr"] = json.loads(json.dumps(rule_obj.rule.dst_addr, cls=AlchemyEncoder))
            ret["log"] = rule_obj.rule.log
            ret["negate_src_addr"] = rule_obj.rule.negate_src_addr
            ret["negate_dst_addr"] = rule_obj.rule.negate_dst_addr
            ret["port"] = json.loads(json.dumps(rule_obj.rule.port, cls=AlchemyEncoder))
            ret["time_profile"] = json.loads(json.dumps(rule_obj.rule.time_profile, cls=AlchemyEncoder))
            ret["active"] = rule_obj.rule.active
            ret["interface"] = json.loads(json.dumps(rule_obj.rule.interface, cls=AlchemyEncoder))
            ret["comment"] = rule_obj.rule.comment

        if rule_type == "nat":
            rule_obj = FwNatRules.query.filter(FwNatRules.id == rule_id).first()
            ret["id"] = rule_obj.id
            ret["rule_name"] = rule_obj.rule.name
            ret["in_iface"] = json.loads(json.dumps(rule_obj.rule.interface_in, cls=AlchemyEncoder))
            ret["out_iface"] = json.loads(json.dumps(rule_obj.rule.interface_out, cls=AlchemyEncoder))
            ret["orj_src_addr"] = json.loads(json.dumps(rule_obj.rule.original_src, cls=AlchemyEncoder))
            ret["orj_dst_addr"] = json.loads(json.dumps(rule_obj.rule.original_dst, cls=AlchemyEncoder))
            ret["orj_service"] = json.loads(json.dumps(rule_obj.rule.original_srv, cls=AlchemyEncoder))
            ret["trans_src_addr"] = json.loads(json.dumps(rule_obj.rule.translated_src, cls=AlchemyEncoder))
            ret["trans_dst_addr"] = json.loads(json.dumps(rule_obj.rule.translated_dst, cls=AlchemyEncoder))
            ret["trans_service"] = json.loads(json.dumps(rule_obj.rule.translated_srv, cls=AlchemyEncoder))
            ret["schedule"] = json.loads(json.dumps(rule_obj.rule.time_profile, cls=AlchemyEncoder))
            ret["log"] = rule_obj.rule.log
            ret["negate_original_src"] = rule_obj.rule.negate_original_src
            ret["negate_original_dst"] = rule_obj.rule.negate_original_dst
            ret["time_profile"] = json.loads(json.dumps(rule_obj.rule.time_profile, cls=AlchemyEncoder))
            ret["action"] = rule_obj.rule.action
            ret["rule_status"] = rule_obj.rule.active
            ret["comment"] = rule_obj.rule.comment

        if rule_type == "route":
            rule_obj = FwRoutingRules.query.filter(FwRoutingRules.id == rule_id).first()
            ret["id"] = rule_obj.id
            ret["rule_name"] = rule_obj.rule.name
            ret["iface"] = json.loads(json.dumps(rule_obj.rule.interface, cls=AlchemyEncoder))
            ret["destination"] = json.loads(json.dumps(rule_obj.rule.destination, cls=AlchemyEncoder))
            ret["gateway"] = json.loads(json.dumps(rule_obj.rule.gateway, cls=AlchemyEncoder))
            ret["rule_status"] = rule_obj.rule.active
            ret["comment"] = rule_obj.rule.comment

        ret["rule_rank"] = rule_obj.rank
        ret = json.dumps(ret)
        return ret        
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify(success=False)

@login_required
@permission_required(['edit_rule', 'super_user'])
def delete_ipv4_policy_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwPolicyRules = main_models.FwPolicyRules

    try:
        fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
        rule_to_be_deleted = FwPolicyRules.query.filter(FwPolicyRules.id == rule_id).first()
        rule_name = rule_to_be_deleted.rule.name
        fw.policy_rules.remove(rule_to_be_deleted)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('policy_rules' + ' <RuleName: ' + rule_name + '>'), 
                    operation='delete', firewall=ACTIVE_FW.name)
        db.session.commit()
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)

    return jsonify(success=True)

@login_required
@permission_required(['edit_rule', 'super_user'])
def delete_ipv4_nat_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwNatRules = main_models.FwNatRules

    try:
        fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
        rule_to_be_deleted = FwNatRules.query.filter(FwNatRules.id == rule_id).first()
        rule_name = rule_to_be_deleted.rule.name
        fw.nat_rules.remove(rule_to_be_deleted)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('nat_rules' + ' <RuleName: ' + rule_name + '>'), 
                    operation='delete', firewall=ACTIVE_FW.name)
        db.session.commit()
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)

@login_required
@permission_required(['edit_rule', 'super_user'])
def delete_ipv4_routing_rule(rule_id: int):
    ACTIVE_FW = get_active_firewall()

    Firewall = main_models.Firewall
    FwRoutingRules = main_models.FwRoutingRules

    try:
        fw = Firewall.query.filter(Firewall.id == ACTIVE_FW.id).first()
        rule_to_be_deleted = FwRoutingRules.query.filter(FwRoutingRules.id == rule_id).first()
        rule_name = rule_to_be_deleted.rule.name
        fw.routing_rules.remove(rule_to_be_deleted)
        commit_changes(username=(current_user.username + ' <' + current_user.email + '>'), 
                    section=('routing_rules' + ' <RuleName: ' + rule_name + '>'), 
                    operation='delete', firewall=ACTIVE_FW.name)
        db.session.commit()
    except Exception as e:
        logger.error(traceback.format_exc())
        db.session.rollback()
        return jsonify(success=False)
    return jsonify(success=True)        