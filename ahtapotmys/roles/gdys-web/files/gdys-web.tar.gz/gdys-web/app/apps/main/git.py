import subprocess
import traceback

from app import app, log
from flask_user import current_user

WORKDIR = app.config['WORKDIR']
BRANCH_NAME = app.config['BRANCH_NAME']

GIT_COMMIT = lambda msg: subprocess.getstatusoutput('cd {} && /usr/bin/git add --all && /usr/bin/git commit -m "{}"'.format(WORKDIR, msg))
GIT_PUSH = lambda branch: subprocess.getstatusoutput('cd {} && /usr/bin/git push origin {}'.format(WORKDIR, branch))
GIT_RESET = lambda branch: subprocess.getstatusoutput('cd {} && /usr/bin/git reset --hard origin/{}'.format(WORKDIR, branch))
GIT_SET_USER_INFO = lambda: subprocess.getstatusoutput('cd {} && /usr/bin/git config user.email "{}" && /usr/bin/git config user.name "{}"'.format(WORKDIR, current_user.username, current_user.email))
# Undo last commit but keep the local changes.
GIT_UNDO_LAST_COMMIT = lambda: subprocess.getstatusoutput('cd {} && /usr/bin/git reset --soft HEAD^ && /usr/bin/git reset'.format(WORKDIR))

def create_new_git_commit(commit_msg):
	try:
		GIT_SET_USER_INFO()
		commit_msg = commit_msg
		stat, output = GIT_COMMIT(commit_msg)
		if stat != 0:
			log.error(output)
			return False
		else:
			log.info("Created new git commit named '{}' by {}".format(commit_msg, current_username()))
			return True
	except Exception as e:
		log.error(traceback.format_exc())
		return False

def push_to_remote():
	try:
		stat, output = GIT_PUSH(BRANCH_NAME)
		if stat != 0:
			GIT_UNDO_LAST_COMMIT()
			log.error(output)
			return False
		else:
			log.info("Local changes pushed to remote by {}".format(current_username()))
			return True
	except Exception as e:
		# If something goes wrong, undo last commit.
		GIT_UNDO_LAST_COMMIT()
		log.error(traceback.format_exc())
		return False

def reset_repo_to_remote():
	try:
		stat, output = GIT_RESET(BRANCH_NAME)
		if stat != 0:
			log.error(output)
			return False
		else:
			log.info("Resetting local repo to remote by {}.".format(current_username()))
			return True
	except Exception as e:
		log.error(traceback.format_exc())
		return False

def current_username():
	return (current_user.username + ' <' + current_user.email + '>')
