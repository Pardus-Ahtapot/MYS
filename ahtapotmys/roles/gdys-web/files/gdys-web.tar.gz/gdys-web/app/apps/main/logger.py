"""This module exports a generic class for Easier Logging"""
import logging
from sys import stdout

class Log(object):
    """This class is a wrapper class around the logging module"""

    def __init__(self, config):
        self.config = config
        self.loglevel = self.get_level(self.config["LOGLEVEL"])

        # create logger
        root = logging.getLogger("gdys-web")
        root.handlers.clear()  # workaround for default stdout handler
        root.setLevel(self.loglevel)

        # create formatter and add it to the handlers
        formatter = logging.Formatter(
            '[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s')

        # create console handler -> logs are always written to stdout
        std_handler = logging.StreamHandler(stdout)
        std_handler.setLevel(self.loglevel)
        std_handler.setFormatter(formatter)
        root.addHandler(std_handler)

        # create log filepath if not exists
        self.create_folder_if_not_exists(
            self.config["LOGPATH"])

        file_handler = logging.FileHandler(
            self.config["LOGPATH"] + "/" +
            self.config["LOGFILE"]
        )
        file_handler.setLevel(self.loglevel)
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)

    def close_logging(self):
        """This function gently closes all handlers before exiting the software"""
        root = logging.getLogger("gdys-web")
        for handler in root.handlers:
            handler.close()
            root.removeFilter(handler)

    def get_level(self, log_level):
        """This internal function determines the log_level of the logging class"""
        level = logging.NOTSET
        if log_level == "debug":
            level = logging.DEBUG
        elif log_level == "info":
            level = logging.INFO
        elif log_level == "warning":
            level = logging.WARNING
        elif log_level == "error":
            level = logging.ERROR
        elif log_level == "critical":
            level = logging.CRITICAL
        return level

    def create_folder_if_not_exists(self, filepath: str):
        import os
        """Checks if a folder exists and creates if it does not exist"""
        if not os.path.exists(filepath):
            os.makedirs(filepath)