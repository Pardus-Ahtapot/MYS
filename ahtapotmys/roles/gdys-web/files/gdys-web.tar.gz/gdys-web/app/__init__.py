# *-* coding: utf-8 *-*
# maintaner "Zekeriya Akgül <zkry.akgul@gmail.com>"

import sys
import datetime
import logging
import traceback

from flask import Flask
from flask_jwt_extended import JWTManager
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData
from flask_migrate import Migrate
from flask_user import UserManager
from flask_babelex import Babel
from app.apps.main import logger
from app.apps.main.defaults import permissions, default_tcp_services, default_udp_services

# Define aplication
app = Flask(__name__)
app.config.from_object('config')
babel = Babel(app)

# Set logger
_log = logger.Log(app.config)
log = logging.getLogger('gdys-web')

# Redirect flask access logs to file
flask_log = logging.getLogger('werkzeug')
file_handler = logging.FileHandler(
            app.config["LOGPATH"] + "/" +
            app.config["ACCESSLOGFILE"]
        )
file_handler.setLevel(logging.INFO)
flask_log.addHandler(file_handler)

# Define the database, database URL in config
naming_convention = {
    "ix": 'ix_%(column_0_label)s',
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(column_0_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
}

db = SQLAlchemy(app, metadata=MetaData(naming_convention=naming_convention))
migrate = Migrate(app, db, render_as_batch=True)

# define the global Firewall object
ACTIVE_FW = None

# define the global filter objects
filter_field = ""
filter_input = ""

# Define JWT
jwt = JWTManager(app)

from app.apps.main import routes as main_routes
from app.apps.main import models as main_models

main_routes.set_routes(app)

# Add admin user if not exists:
User = main_models.User
Role = main_models.Role
Permission = main_models.Permission
Service = main_models.Service

user_manager = UserManager(app, db, User)

try:
    if not db.engine.dialect.has_table(db.engine, "users") or not db.engine.dialect.has_table(db.engine, "service"):
        log.warning("DB not ready yet! Skipping initial creation...")
    else:
        if not User.query.filter(User.email == app.config['ADMIN_MAIL']).first():
            user = User(
                name="Admin Kullanıcı",
                username=app.config['ADMIN_USERNAME'],
                email=app.config['ADMIN_MAIL'],
                email_confirmed_at=datetime.datetime.utcnow(),
                active=True,
                password=user_manager.hash_password(app.config['ADMIN_PASSWORD']),
            )
            user.roles.append(Role(name='Admin', description="Bütün yetkilere sahip yönetici grubu"))
            db.session.add(user)

            adm_role = Role.query.filter(Role.id == 1).first()
            for perm in permissions:
                p = Permission(name=perm['name'], description=perm['desc'])
                db.session.add(p)
                if perm['name'] == 'super_user':
                    adm_role.permissions.append(p)

            # After initial things save the changes to db
            db.session.commit()

        if not Service.query.filter(Service.category == "standart").first():
            # Add default TCP Services
            for tcp_service in default_tcp_services:
                service = Service(
                    name = tcp_service['name'],
                    category = "standart",
                    protocol = tcp_service['proto'],
                    src_start_port = tcp_service['src_port_start'],
                    src_end_port = tcp_service['src_port_end'],
                    dst_start_port = tcp_service['dst_port_start'],
                    dst_end_port = tcp_service['dst_port_end'],
                )
                db.session.add(service)
            # Add default TCP Services
            for udp_service in default_udp_services:
                service = Service(
                    name = udp_service['name'],
                    category = "standart",
                    protocol = udp_service['proto'],
                    src_start_port = udp_service['src_port_start'],
                    src_end_port = udp_service['src_port_end'],
                    dst_start_port = udp_service['dst_port_start'],
                    dst_end_port = udp_service['dst_port_end'],
                )
                db.session.add(service)

            # After initial things save the changes to db
            db.session.commit()
except Exception as e:
    traceback.print_exc()
    msg = """
        If you ran the 'flask db init/migrate/upgrade' command then ignore this message.
        User table was not found. Something may went wrong while creating db. Check the access rights of '{}'.
        """.format(app.config['WORKDIR'])
    log.warning(msg)
    # log.error(traceback.format_exc())
    # sys.exit(msg)
