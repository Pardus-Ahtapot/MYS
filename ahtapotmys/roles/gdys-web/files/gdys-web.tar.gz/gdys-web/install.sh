#!/bin/bash
COLOR_GREEN="\033[92m"
COLOR_RED="\033[31m"
COLOR_YELLOW="\033[93m"
COLOR_DEFAULT="\033[39m"

echo -ne "$COLOR_DEFAULT"

function print_warn()
{
    echo -ne "$COLOR_YELLOW##### $1 #####$COLOR_DEFAULT\n"
}

function print_err()
{
    echo -ne "$COLOR_RED$1$COLOR_DEFAULT\n"
}

function print_success()
{
    echo -ne "$COLOR_GREEN$1$COLOR_DEFAULT\n"
}

if [ "$EUID" -ne 0 ]; then
  print_err "Lutfen bu script'i root kullanicisi olarak calistirin! Cikiliyor..."
  exit 1
fi

# Get the current working directory
cwd=$(pwd)

# Define the systemd vars
SYSTEMD_PATH="/etc/systemd/system"
GDYSWEB_SYSTEMD_SERVICE_NAME="gdysweb"
GDYSWEB_SYSTEMD_SERVICE_FILE="$SYSTEMD_PATH/${GDYSWEB_SYSTEMD_SERVICE_NAME}.service"

# Define the necessary vars
REQUIRED_PKGS="build-essential git python3-dev virtualenv nginx"
venv_bin_path=""
workdir_path="/etc/fw/gdys"
log_path="/var/log/ahtapot"

# Define the config vars
gdys_user=""
gdys_group=""
virtualenv_path=""
web_port=""
web_host=""
mys_ip=""
access_via_ip=""

function valid_ip() {
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

function check_vars() {
    if [ -z "${gdys_user}" ]; then
        gdys_user="ahtapotops"
    fi

    if [ -z "$gdys_group" ]; then
      gdys_group="ahtapotops"
    fi

    if [ -z "$virtualenv_path" ]; then
      virtualenv_path="/opt"
    fi

    if [ -z "$web_port" ]; then
      web_port="80"
    fi

    check_valid_fqdn=$(echo $web_host | grep -P '(?=^.{1,254}$)(^(?>(?!\d+\.)[a-zA-Z0-9_\-]{1,63}\.?)+(?:[a-zA-Z]{2,})$)')
    if [ -z "$check_valid_fqdn" ]; then
      print_err "Lutfen gecerli bir FQDN bilgisi giriniz!"
      exit 1
    fi

    if [ -z "${access_via_ip}" ]; then
        access_via_ip=false
    fi

    if [ -z "${mys_ip}" ]; then
        print_err "Mys ip adresi bos!"
        exit 1
    elif [ ! valid_ip $ip ]; then
        print_err "Mys ip adresi hatali!"
        exit 1
    fi
}

function get_vars() {
    read -p "Gdys2 sahipligi icin kullanilacak kullanici adi (varsayilan: ahtapotops): " gdys_user
    if [ -z "$gdys_user" ]; then
      gdys_user="ahtapotops"
    fi

    read -p "Gdys2 sahipligi icin kullanilacak grup adi (varsayilan: ahtapotops): " gdys_group
    if [ -z "$gdys_group" ]; then
      gdys_group="ahtapotops"
    fi

    read -p "Virtualenv'i yüklemek istediğiniz path'i giriniz (varsayilan: /opt): " virtualenv_path
    if [ -z "$virtualenv_path" ]; then
      virtualenv_path="/opt"
    fi

    read -p "Web arayuzune erisilmesini istediginiz port numarası (varsayilan: 80): " web_port
    if [ -z "$web_port" ]; then
      web_port="80"
    fi

    while [ -z "$web_host" ]; do
        read -p "Web arayuzune erisilmesini istediginiz fqdn: " web_host
        check_valid_fqdn=$(echo $web_host | grep -P '(?=^.{1,254}$)(^(?>(?!\d+\.)[a-zA-Z0-9_\-]{1,63}\.?)+(?:[a-zA-Z]{2,})$)')
        if [ -z "$check_valid_fqdn" ]; then
          echo "Lutfen gecerli bir FQDN bilgisi giriniz!"
          web_host=""
        fi
    done

    while true; do
        read -p "Ip adresi uzerinden erisim acilsin mi? (varsayilan: no) (yes/no)" yn
        case $yn in
            [Yy]* ) access_via_ip=true; break;;
            [Nn]* ) access_via_ip=false; break;;
            * ) access_via_ip=false; break;;
        esac
    done

    while [ -z "$mys_ip" ]; do
      read -p "Mys sunucusuna ait ip adresi (orn: 192.168.1.1): " mys_ip
    done
}

function check_req_packages() {
    apt-get update
    print_warn "Gerekli paketler kontrol ediliyor."
    sleep 1
    for REQUIRED_PKG in $REQUIRED_PKGS; do
      PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $REQUIRED_PKG|grep "install ok installed")
      echo "Checking for $REQUIRED_PKG: $PKG_OK"
      if [ "" = "$PKG_OK" ]; then
        echo "No $REQUIRED_PKG. Setting up $REQUIRED_PKG."
        apt-get --yes install $REQUIRED_PKG
      fi
    done
}

function setup_virtualenv() {
    # Clean old files
    rm -rf $virtualenv_path/gdys-web-venv

    print_warn "Virtualenv yapisi oluşturuluyor"
    sleep 1
    virtualenv -p python3 $virtualenv_path/gdys-web-venv

    print_warn "Virtualenv aktiflestiriliyor"
    sleep 1
    source $virtualenv_path/gdys-web-venv/bin/activate

    print_warn "Gerekli python paketleri yükleniyor..."
    sleep 1
    pip install -r requirements.txt

    venv_bin_path="${virtualenv_path}/gdys-web-venv/bin"

    # Fix for flask-user turkish lang
    tr_translation_path="${virtualenv_path}/gdys-web-venv/lib/python3.5/site-packages/flask_user/translations/tr/LC_MESSAGES/"
    $venv_bin_path/pybabel compile -i $tr_translation_path/flask_user.po -o $tr_translation_path/flask_user.mo
}

function setup_paths() {
    print_warn "Gerekli dizinler olusturuluyor..."

    mkdir -p "${workdir_path}"
    mkdir -p "${log_path}"
}

function setup_flask_env() {
    # Clean old files
    rm -rf .env

    print_warn "Flask konfigurasyonu olusturuluyor..."
    echo -n '
    BRANCH_NAME=master
    ADMIN_USERNAME=admin
    ADMIN_MAIL=admin@ahtapot.org
    ADMIN_PASSWORD=LA123
    WORKDIR='${workdir_path}'
    LOGLEVEL=warning
    LOGPATH=/var/log/ahtapot
    HOST='${web_host}'
    HOST_PORT='${web_port}'
    MYS_IP_ADDR='${mys_ip}'
    FLASK_ENV=production
    FLASK_DEBUG=0
    ' >> .env

    if [ "$access_via_ip" ]; then
        sed -i 's/SERVER_NAME =/# SERVER_NAME =/g' config.py
        sed -i 's/SERVER_NAME_EXTRA =/# SERVER_NAME_EXTRA =/g' config.py
        rm -rf /etc/nginx/sites-enabled/default
    fi
}

function init_db() {
    print_warn "Veritabani ayarlaniyor..."

    # Clean old files
    rm -rf migrations/
    rm -rf ${workdir_path}/*.db

    ${venv_bin_path}/flask db init && \
    ${venv_bin_path}/flask db migrate -m "Initial migration" && \
    ${venv_bin_path}/flask db upgrade
}

function fix_perms() {
    print_warn "Dosya izinleri ayarlaniyor..."

    chown -R "${gdys_user}":"${gdys_group}" "${workdir_path}"
    chown -R "${gdys_user}":"${gdys_group}" $virtualenv_path/gdys-web-venv
    chown -R "${gdys_user}":"${gdys_group}" $cwd/
    chown -R "${gdys_user}":"${gdys_group}" "${log_path}"
}

function setup_systemd_service() {
    print_warn "Systemd servis dosyasi olusturuluyor..."
    sleep 1

    # Clean old files
    rm -rf $GDYSWEB_SYSTEMD_SERVICE_FILE

    echo -n '
    [Unit]
    Description=uWSGI instance to serve Gdys Web
    After=network.target

    [Service]
    User='${gdys_user}'
    Group=www-data
    WorkingDirectory='${cwd}'
    Environment="PATH='${venv_bin_path}':'${PATH}'"
    ExecStart='${venv_bin_path}'/uwsgi --ini gdysweb.ini
    Restart=on-failure

    [Install]
    WantedBy=multi-user.target
    ' >> $GDYSWEB_SYSTEMD_SERVICE_FILE

    systemctl enable $GDYSWEB_SYSTEMD_SERVICE_NAME
    systemctl start $GDYSWEB_SYSTEMD_SERVICE_NAME
    systemctl status $GDYSWEB_SYSTEMD_SERVICE_NAME
}

function setup_nginx_conf() {
    print_warn "Nginx konfigurasyonu olusturuluyor..."
    sleep 1

    # Clean old files
    rm -rf /etc/nginx/sites-available/gdysweb
    rm -rf /etc/nginx/sites-enabled/gdysweb

    echo -n '
    server {
        listen '${web_port}';
        server_name '${web_host}' www.'${web_host}';

        location / {
            include uwsgi_params;
            uwsgi_pass unix:'${cwd}'/gdysweb.sock;
        }
    }
    ' >> /etc/nginx/sites-available/gdysweb

    ln -s /etc/nginx/sites-available/gdysweb /etc/nginx/sites-enabled
    systemctl restart nginx
}

while test $# -gt 0; do
    case "$1" in
        -h|--help)
            echo "GDYS kurulum betigi"
            echo " "
            echo "Interaktif kurulum icin: sudo ./install.sh"
            echo "Non-interaktif kurulum icin: sudo ./install.sh [arguments]"
            echo " "
            echo "options:"
            echo "-h,   --help               yardimi goster"
            echo "-ni,  --non-interactive    degerleri parametreler araciligi ile al"
            echo "-gu,  --gdys-user=NAME     Gdys uygulamasinin ait olacagi kullanici (varsayilan: ahtapotops)"
            echo "-gg,  --gdys-group=NAME    Gdys uygulamasinin ait olacagi kullanici grubu (varsayilan: ahtapotops)"
            echo "-f,   --fqdn=FQDN          Uygulamanin yayinlanacagi FQDN"
            echo "-p,   --port=PORT          Uygulamanin yayinlanacagi port bilgisi (varsayilan: 80)"
            echo "-mi,  --mys-ip=IP          MYS sunucusuna ait ip bilgisi"
            echo "-aip, --access-via-ip      GDYS uygulamasini tarayici uzerinden IP ile ulasilabilir yap"
            exit 0
            ;;
        -ni)
            shift
            non_interactive=true
            ;;
        --non-interactive*)
            shift
            non_interactive=true
            ;;
        -gu)
            shift
            if test $# -gt 0; then
                gdys_user=$1
            else
                echo "Kullanici bilgisi eksik"
                exit 1
            fi
            shift
            ;;
        --gdys-user*)
            gdys_user=`echo $1 | sed -e 's/^[^=]*=//g'`
            shift
            ;;
        -gg)
            shift
            if test $# -gt 0; then
                gdys_group=$1
            else
                echo "Grup bilgisi eksik!"
                exit 1
            fi
            shift
            ;;
        --gdys-group*)
            gdys_group=`echo $1 | sed -e 's/^[^=]*=//g'`
            shift
            ;;
        -f)
            shift
            if test $# -gt 0; then
                web_host=$1
            else
                echo "FQDN bilgisi eksik!"
                exit 1
            fi
            shift
            ;;
        --fqdn*)
            web_host=`echo $1 | sed -e 's/^[^=]*=//g'`
            shift
            ;;
        -p)
            shift
            if test $# -gt 0; then
                web_port=$1
            else
                echo "Port bilgisi eksik!"
                exit 1
            fi
            shift
            ;;
        --port*)
            web_port=`echo $1 | sed -e 's/^[^=]*=//g'`
            shift
            ;;
        -mi)
            shift
            if test $# -gt 0; then
                mys_ip=$1
            else
                echo "no output dir specified"
                exit 1
            fi
            shift
            ;;
        --mys-ip*)
            mys_ip=`echo $1 | sed -e 's/^[^=]*=//g'`
            shift
            ;;
        -aip)
            shift
            access_via_ip=true
            ;;
        --access-via-ip*)
            shift
            access_via_ip=true
            ;;
        *)
            break
            ;;
    esac
done

if [ -z $non_interactive ]; then
    get_vars
fi
check_vars && \
check_req_packages && \
setup_virtualenv && \
setup_paths && \
setup_flask_env && \
init_db && \
fix_perms && \
setup_systemd_service && \
setup_nginx_conf

if [ $? -eq 0 ]; then
echo -ne '
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#  ________  ___  ___  _________  ________  ________  ________  _________
# |\   __  \|\  \|\  \|\___   ___\\   __  \|\   __  \|\   __  \|\___   ___\
# \ \  \|\  \ \  \\\  \|___ \  \_\ \  \|\  \ \  \|\  \ \  \|\  \|___ \  \_|
#  \ \   __  \ \   __  \   \ \  \ \ \   __  \ \   ____\ \  \\\  \   \ \  \
#   \ \  \ \  \ \  \ \  \   \ \  \ \ \  \ \  \ \  \___|\ \  \\\  \   \ \  \
#    \ \__\ \__\ \__\ \__\   \ \__\ \ \__\ \__\ \__\    \ \_______\   \ \__\
#     \|__|\|__|\|__|\|__|    \|__|  \|__|\|__|\|__|     \|_______|    \|__|
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#
# '$COLOR_GREEN'Kurulum basariyla tamamlandi!'$COLOR_DEFAULT'
#
#
# '$COLOR_YELLOW'Systemd servis dosyasi:'$COLOR_DEFAULT' '${GDYSWEB_SYSTEMD_SERVICE_FILE}'
# '$COLOR_YELLOW'Nginx konfigurasyon dosyasi:'$COLOR_DEFAULT' /etc/nginx/sites-available/gdysweb | /etc/nginx/sites-enabled/gdysweb
# '$COLOR_YELLOW'Gdys2 konfigurasyon dosyasi:'$COLOR_DEFAULT' '${cwd}'/.env
#
# '$COLOR_YELLOW'Web arayuzune erismek icin:'$COLOR_DEFAULT' http://'${web_host}':'${web_port}'
# '$COLOR_YELLOW'Varsayilan Yonetici kullanici adi      :'$COLOR_DEFAULT' admin
# '$COLOR_YELLOW'Varsayilan Yonetici kullanici parolasi :'$COLOR_DEFAULT' LA123
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
'
else
echo -ne '
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#  ________  ___  ___  _________  ________  ________  ________  _________
# |\   __  \|\  \|\  \|\___   ___\\   __  \|\   __  \|\   __  \|\___   ___\
# \ \  \|\  \ \  \\\  \|___ \  \_\ \  \|\  \ \  \|\  \ \  \|\  \|___ \  \_|
#  \ \   __  \ \   __  \   \ \  \ \ \   __  \ \   ____\ \  \\\  \   \ \  \
#   \ \  \ \  \ \  \ \  \   \ \  \ \ \  \ \  \ \  \___|\ \  \\\  \   \ \  \
#    \ \__\ \__\ \__\ \__\   \ \__\ \ \__\ \__\ \__\    \ \_______\   \ \__\
#     \|__|\|__|\|__|\|__|    \|__|  \|__|\|__|\|__|     \|_______|    \|__|
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#
# '$COLOR_RED'Kurulum tamamlandi fakat bazi hatalar gerceklesti!'$COLOR_DEFAULT'
#
#
# '$COLOR_YELLOW'Systemd servis dosyasi:'$COLOR_DEFAULT' '${GDYSWEB_SYSTEMD_SERVICE_FILE}'
# '$COLOR_YELLOW'Nginx konfigurasyon dosyasi:'$COLOR_DEFAULT' /etc/nginx/sites-available/gdysweb | /etc/nginx/sites-enabled/gdysweb
# '$COLOR_YELLOW'Gdys2 konfigurasyon dosyasi:'$COLOR_DEFAULT' '${cwd}'/.env
#
# '$COLOR_YELLOW'Web arayuzune erismek icin:'$COLOR_DEFAULT' http://'${web_host}':'${web_port}'
# '$COLOR_YELLOW'Varsayilan Yonetici kullanici adi      :'$COLOR_DEFAULT' admin
# '$COLOR_YELLOW'Varsayilan Yonetici kullanici parolasi :'$COLOR_DEFAULT' LA123
#
#+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
'
fi
