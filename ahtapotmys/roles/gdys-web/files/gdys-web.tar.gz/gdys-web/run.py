from app import app
from app.apps.main import logger
from config import * 

if __name__ == "__main__":
	logger.logging.info("Server started...")
	app.run(host=HOST, port=HOST_PORT, debug=True)
