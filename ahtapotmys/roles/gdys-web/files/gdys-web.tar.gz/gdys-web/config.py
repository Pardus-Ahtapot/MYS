import os, sys
import logging
from datetime import timedelta

try:
	from dotenv import load_dotenv
	load_dotenv()
except Exception as e:
	print("Someting went wrong when try to load environments form .env file. Skipping...")

# ----------------- BASIC OPTIONS -----------------

project_name = os.environ.get('PROJECT_NAME', 'web')

# Where we store the fw scripts and the database file
WORKDIR = os.environ.get('WORKDIR', '/etc/fw/gdys')

# Git settings
BRANCH_NAME = os.environ.get('BRANCH_NAME', 'master')

# Admin settings
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
ADMIN_MAIL = os.environ.get('ADMIN_MAIL', 'admin@ahtapot.org')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'LA123')

# Logging options
LOGLEVEL = os.environ.get('LOGLEVEL', 'warning')
LOGPATH = os.environ.get('LOGPATH', '/var/log/ahtapot')
LOGFILE = os.environ.get('LOGFILE', 'gdys-web.log')
ACCESSLOGFILE = os.environ.get('ACCESSLOGFILE', 'gdys-web-access.log')

# should be the hostname of your project
HOST = os.environ.get('HOST', '0.0.0.0') 
# useful for development/testing mode
# necessary if non-standard port is being used
HOST_PORT = os.environ.get('HOST_PORT', '8090')

# MYS Settings
MYS_IP_ADDR = os.environ.get('MYS_IP_ADDR', '192.168.1.1')

# ----------------- ADVANCED OPTIONS -----------------

# If workdir not exist
if not os.path.isdir(WORKDIR):
	msg = 'Girilen calisma alani dizini mevcut degil! Cikiliyor..\n'
	msg += "Su komut ile olusturulabilir: sudo mkdir -p {}".format(WORKDIR)
	sys.exit(msg)

# see http://flask.pocoo.org/docs/1.0/config/#environment-and-debug-features
ENV = os.getenv('FLASK_ENV', 'production') # production / development
DEBUG = os.getenv('FLASK_DEBUG', '0') == '1' # True / False

# use TESTING mode?
TESTING = DEBUG

# we need to append the host port to the server_name if it is non-standard
SERVER_NAME_EXTRA = len(HOST_PORT) and '' or (":" + HOST_PORT)
# SERVER_NAME contains the hostname and port (if non-default)
SERVER_NAME = HOST + SERVER_NAME_EXTRA

# Flask settings
SECRET_KEY = 'fgh7Ax809A8w16cv89as1ygASf7y8ASfg78g234'

# Flask-SQLAlchemy settings
SQLALCHEMY_DATABASE_URI = 'sqlite:///{}/app.db'.format(WORKDIR)    # File-based SQL database
SQLALCHEMY_TRACK_MODIFICATIONS = False    # Avoids SQLAlchemy warning

# Flask-Mail SMTP server settings
MAIL_SERVER = 'mail.ahtapot.local'
MAIL_PORT = 587
MAIL_USE_SSL = False
MAIL_USE_TLS = True
MAIL_USERNAME = 'info@gdys.ahtapot'
MAIL_PASSWORD = 'YOUR_SECRET_PASSWORD'
MAIL_DEFAULT_SENDER = '"GDYS" <noreply@example.com>'

# Flask-User settings
USER_APP_NAME = "GDYS Web Arayüzü"  # Shown in and email templates and page footers
USER_ENABLE_EMAIL = True        # Enable email authentication
USER_ENABLE_USERNAME = True    # Enable username authentication
USER_COPYRIGHT_YEAR = 2016
USER_EMAIL_SENDER_NAME = USER_APP_NAME
USER_APP_VERSION = "v1.12.20-Beta"
USER_EMAIL_SENDER_EMAIL = "noreply@ahtapot.org"
USER_ENABLE_REGISTER = False
USER_REQUIRE_INVENTATION = True
USER_ALLOW_LOGIN_WITHOUT_CONFIRMED_EMAIL = True
USER_SEND_PASSWORD_CHANGED_EMAIL = False
USER_ENABLE_REMEMBER_ME = True
USER_CORPORATION_NAME = 'Ahtapot GDYS'
USER_AFTER_LOGOUT_ENDPOINT = 'user.login'
USER_AFTER_LOGIN_ENDPOINT = 'user_validation'
USER_AFTER_CHANGE_PASSWORD_ENDPOINT = 'user_set_passwd_expire'

# Iptables settings
IPTABLES_PATH = "/sbin/iptables"
IP6TABLES_PATH = "/sbin/ip6tables"