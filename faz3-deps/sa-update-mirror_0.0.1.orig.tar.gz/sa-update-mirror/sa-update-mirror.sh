#!/bin/bash
#Spamassassin sa-update mirror script
#Fatih USTA  / fatihusta@labrisnetworks.com

config=/etc/sa-update-mirror.conf

_rsync=/usr/bin/rsync
_mkdir=/bin/mkdir
_logger=/usr/bin/logger
_grep=/bin/grep
_ls='/bin/ls --color=auto'
_tail=/usr/bin/tail
_cut=/usr/bin/cut
_basename=/usr/bin/basename

if [ -f ${config} ]; then
    source ${config}
else
    echo "Config file not found: ${config}"
    exit 1
fi

if [ ! -f $_rsync ]; then
    echo "Please install rsync package on your system"
    echo "apt install rsync"
    exit 1
fi

if [ -z ${domain} ]; then
    echo "Please set your domain in config file: ${config}"
    exit 1
fi

if [ ! -d ${download_dir} ]; then
    $_mkdir -p ${download_dir}
fi

$_rsync --exclude 'MIRRORED.BY' --exclude 'version' --timeout=280 -T ${tmp_dir} -ta --delete ${main_mirror} ${download_dir} &> /dev/null

if [ $? != 0 ]; then
    echo "Sync failed." | $_logger -t $(basename $0)
else
    last_update_file=$($_ls -1tr ${download_dir}/* | $_grep "tar.gz$" | $_tail -n 1)
    last_update_version=$($_basename ${last_update_file} | $_cut -d"." -f 1)
    echo "${last_update_version}" > ${download_dir}/version
    echo "Sync success." | $_logger -t $(basename $0)
fi

#Update MIRRORED.BY File

if [ -z ${mirror_url} ]; then
    echo "Please set mirror url in config file: ${config}"
else
    echo "$mirror_url" > ${download_dir}/MIRRORED.BY
fi
