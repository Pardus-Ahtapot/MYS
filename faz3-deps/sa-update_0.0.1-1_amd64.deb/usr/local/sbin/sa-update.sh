#!/bin/bash
#sa-update from file or channel
#Fatih USTA <fatihusta@labrisnetworks.com> / Labris Networks
arg1=$1

if [[ ${arg1} == "debug" ]]; then
    SA_DEBUG="-D"
    set -x
fi

config=/etc/sa-update.conf
tmp_dir=/var/tmp/sa-update

_sa_update=/usr/bin/sa-update
_wget=/usr/bin/wget
_mkdir=/bin/mkdir
_logger=/usr/bin/logger
_grep=/bin/grep
_rm=/bin/rm
_systemctl=/bin/systemctl
_mv=/bin/mv
_cat=/bin/cat
_awk=/usr/bin/awk

if [ -f ${config} ]; then
    source ${config}
else
    echo "Config file not found: ${config}"
    exit 1
fi

if [ ! -f $_wget ]; then
    echo "Please install wget package on your system"
    echo "apt install wget"
    exit 1
fi

if [ -z ${url} ]; then
    echo "Please set your url in config file: ${config}"
    exit 1
fi

if [ ! -d ${tmp_dir} ]; then
    $_mkdir -p ${tmp_dir}
fi

check_version() {
    $_wget ${url}/version -O ${tmp_dir}/version.new &> /dev/null
    newVersion=$($_cat ${tmp_dir}/version.new 2>/dev/null)
    oldVersion=$($_cat ${tmp_dir}/version 2>/dev/null)
    if [[ ${newVersion} != ${oldVersion} ]];then
        echo ${newVersion} 
        return 0
    else
        return 1
    fi

}

get_files() {

    $_wget ${url}/${file} -O ${tmp_dir}/${file} &> /dev/null
    $_wget ${url}/${file}.asc -O ${tmp_dir}/${file}.asc &> /dev/null
    $_wget ${url}/${file}.sha1 -O ${tmp_dir}/${file}.sha1 &> /dev/null
    $_wget ${url}/${file}.sha256 -O ${tmp_dir}/${file}.sha256 &> /dev/null

    if [ $? != 0 ]; then
        echo "Download Failed" | $_logger -t $(basename $0)
        return 1
    else
        return 0
    fi
}

update() {
    local method=$1
    if [[ ${method} == "channel" ]];then
        #Cut http/s prefix from url
        url=$(echo $url|$_awk -F "//" '{print $2}')
        $_sa_update ${SA_DEBUG} --channel ${url}
    elif [[ ${method} == "file" ]];then
        if (check_version &>/dev/null); then
            version=$(check_version)
            file=${version}.tar.gz
            if (get_files); then
                $_sa_update ${SA_DEBUG} --install ${tmp_dir}/${file}
            fi
        else
            echo "No Update" | $_logger -t $(basename $0)
            return 0
        fi
    fi
    if [ $? != 0 ] || [ $? != 1 ]; then
        echo "Update Failed" | $_logger -t $(basename $0)
        return $?
    else
        if [[ ${method} == "file" ]];then
            $_mv ${tmp_dir}/version.new ${tmp_dir}/version
            $_rm -f ${tmp_dir}/${file}*
        fi
        echo "Updated" | $_logger -t $(basename $0)
        $_systemctl restart spamassassin
        if [ -f /usr/sbin/amavis-services ]; then
            $_systemctl restart amavis
        fi
    fi

}

if [[ "${method}" == "channel" ]];then
    update channel
elif [[ "${method}" == "file" ]];then
    update file
else
    echo "Method not configured. Using file method."
    update file
fi
