# Impacted versions

* Distribution: Debian / Ubuntu / Centos
* Codename: Jessie / Trusty / Centos 7 / ...
* Arch: 32 Bits / 64 Bits
* Database: PostgreSQL / MySQL

# Steps to reproduce

# Full trace using --debug option or current behaviour

# Expected behavior

# Video/Screenshot link (optional)

